

dv - used screen shot and viso to make a .vsd and .png.
     Then crop and resize to dv.png.
	  To reduce color depth: convert -depth 4 dv.png dv4.png
	  To convert to xpm, kiconedit, save as.
 
