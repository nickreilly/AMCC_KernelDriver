
How to install DV on the IRTF computers:

su - s2
cd src/dv
make clean
make

su root
make install

