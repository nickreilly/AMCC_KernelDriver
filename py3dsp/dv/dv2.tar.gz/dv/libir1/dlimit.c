
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
 
#include "ir1.h"

/*----------------------------------------------------------
** dlimit() - If v is outside the min or max limits, v
**            is set to min or max.
**----------------------------------------------------------
*/
double dlimit( double v, double min, double max)
{
   if( v > max ) v =  max;
   if( v < min ) v =  min;
   return v;
}

