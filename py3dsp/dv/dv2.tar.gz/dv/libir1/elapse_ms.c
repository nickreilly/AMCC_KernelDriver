
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

#include "ir1.h"

/*--------------------------------------------------
** elapse_ms() - uses gettimeofday to query the current
**  time, and return the elapse millisecond since the
**  time in variable "then". Int32_t limits you to about 24.855 days.
**--------------------------------------------------
*/
int32_t elapse_ms( struct timeval *then)
{
   struct timeval now;
   struct timezone tzone;
 
   gettimeofday( &now, &tzone);
   now.tv_usec -= then->tv_usec;
   now.tv_sec -= then->tv_sec;
   if( now.tv_usec < 0 )
   {
      now.tv_usec += 1000000;
      now.tv_sec -= 1;
   }
   return (now.tv_usec/1000) + (1000L*now.tv_sec);
}

