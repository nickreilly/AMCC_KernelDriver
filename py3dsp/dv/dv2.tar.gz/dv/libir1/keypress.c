
#include <stdlib.h>
#include <stdio.h>

#include <termios.h>
#include <string.h>

/*-----------------------------------------------------------------------
**   set_keypress()
** reset_keypress()
**
**   These function allow you to put stdin in a non-blocking mode so you
**   can read 1 charater at a time.
**   Got the code from unix.programmer.faq.
**------------------------------------------------------------------------
*/
static struct termios stored;
 
void set_keypress(void)
{
    struct termios new;
 
    tcgetattr(0,&stored);
 
    memcpy(&new,&stored,sizeof(struct termios));
 
    /* Disable canonical mode, and set buffer size to 1 byte */
    new.c_lflag &= (~ICANON);
    new.c_cc[VTIME] = 0;
    new.c_cc[VMIN] = 1;
 
    tcsetattr(0,TCSANOW,&new);
    return;
}
 
void reset_keypress(void)
{
    tcsetattr(0,TCSANOW,&stored);
    return;
}

