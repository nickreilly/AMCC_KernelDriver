/***************************************************************************
**  my_atof.c
****************************************************************************
*/

#define EXTERN extern

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <sys/time.h>


/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "ir1.h"

/*-------------------------------------------------------------
** my_atof() - convert a string to a double. The string s
**   must consist of  '[white space][+-] [digits.digits] [white spaces]'
**   returns error: 0 = noerror;
**                 -1 = invalid char in string
**-------------------------------------------------------------
*/
 
int my_atof( char *s, double *d_ptr )
{
   char *start;
   char *endptr;
   int  cnt, 
        decimal_point;
   double d;
 
   if( s == NULL)
      return -1;
 
   while( isspace( (int) *s) ) s++;     /* Skip leading spaces */
   start = s;
 
   if( *s=='-' || *s=='+' ) s++; /* First char can be a signed */
 
   cnt = 0;
   decimal_point = 0;
   while( isdigit(*s) || *s=='.' )          /* Only allow decimal digits */
   {
     s++;
     cnt++;
     if( *s=='.' ) decimal_point++;
   }
   if( !cnt )  return -1;
   if( decimal_point > 1 ) return -1;

                                 /* Allow ONLY trailing white spaces */
   while( *s )
      if( isspace( (int)*s ) )
         s++;
      else
         return -1;
 
   d = strtod( start, &endptr );
   if( start == endptr ) return -1; // no conversion, error
   if( isnan(d) ) return -1;
   if( isinf(d) ) return -1;
   if( d == HUGE_VAL  || d == -HUGE_VAL ) return -1;

   *d_ptr = d;
   return 0;
}
 


