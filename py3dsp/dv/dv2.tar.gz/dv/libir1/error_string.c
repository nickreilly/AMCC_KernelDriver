/*************************************************************
** error_string.c
**************************************************************
*/

#define EXTERN extern

/*--------------------------
*  include files
*--------------------------
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>

#include "ir1.h"

static char * Error_string[NUM_ERR_CODES]  /* Declare a string message for each */
   = {
     "no error  ",
     "invalid keyword",
     "invalid range",
     "invalid format or sytax error",
     "socket communication error",
     "socket timeout error",
     "invalid path",
     "memory allocation error",
     "error on creating a file",
     "error while writing to a file",
     "error while reading a file",
     "invalid file format",
     "unable to execute, object is busy",
     "unable to perform on an empty buffer",
     "unable to perform on different size buffers",
     "an invalid buffer was specified",
     "this is an invalid operation",
     "Unknown error",
     "this option is currently restricted",
     "system error using message queues occured",
     "current go was terminated by the stop command",
     "The grating task has detected a hardware failure",
     "unable to open file",
     "error assoiciated with limit switch",
     "Semaphore acquisiton error",
     "Device was not properly initialized",
     "unable to communicate with device",
     "invalid combination specified",
     "timeout error",
     "directory is invalid/inaccessible",
     "An error with the clock DSP has occured",
     "An error with the BCard DSP has occured",
     "This option is not implemented ",
     "Number of subarray not valid",
     "Subarray row should not overlap",
     "Subarray format or placement error",
     "Subarray too big", 
     "Error with the encoder",
     "Thermal Clamp is locked",
     "Reqested action or service is not available",
     "Shift array must be <= 128x128 & enclosed by data array",
     "Execeeding some type of limitation was encountered",
     "Hardware didn't respond as expected",
     "There are no data",
     "The last operation was aborted",
     "not enough space for request",
     "NA",
     "NA",
     "NA",
     "NA",
	  /* 50 */
     "DSP still execute last command function",
     "DSP unknown error",
     "Error communication with DSP device/driver",
     "Invalid input for DSP function",
     "Invalid DSP function",
     "DSP not ready for perform this function",
     "The board isn't working",
     "DSP error related to locking the IXR",
     "Error reading an input file for this DSP function",
     "Invalid format for the sub arrays",
	  /* 60 */
     "NA",
      }
   ;

/*----------------------------------------------------------
**  error_string() - returns a pointer to a char[] description
**     for the return code, rc. 
**----------------------------------------------------------
*/
char * error_string( int rc )
{
   char * cptr;

   rc = abs(rc);
   if( INRANGE( 0, rc, NUM_ERR_CODES-1))
      cptr =  Error_string[rc];
   else
      cptr =  "returned invalid error code";

   //printf("error_string(%d) = %s \n", rc, cptr);
   return cptr;
}
                              
