#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <pwd.h>
#include <sys/time.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

/*----------------------------------------------------------------------------
**  expand_pathname() - Expands a pathname in the form ~username/... or $VAR/...
**----------------------------------------------------------------------------
*/
#if defined(__STDC__)
int expand_pathname( char *pathout, int pathout_size, char *pathin)
#else
int expand_pathname( pathout, pathout_size, pathin )
	char *pathout;
	int  pathout_size;
	char *pathin;
#endif
{
   int  len, 
		  firsttime,
		  endding_slash,
		  rc;
   char *bufin,
        *bufout;
   char *token,
        *cptr;
   struct passwd * pw_entry;

   /* Allocate and initialize memory */
   bufin  = (char*) malloc((unsigned)MAXPATHLEN);
   bufout = (char*) malloc((unsigned)MAXPATHLEN);
   if( bufin==NULL || bufout==NULL)
   {
      if( bufin )  free( bufin );
      if( bufout ) free( bufout );
      return MEM_ALT_ERR;
   }
	bufin[0] = bufout[0] = 0;

   rc = ERR_NONE;

   if( pathin == NULL )
		{ rc = ERR_INV_FORMAT; goto ldone; }

	strxcpy(bufin, pathin, MAXPATHLEN);
   unpad( bufin, ' ');

   if( bufin[0] == 0 )
		{ rc = ERR_INV_FORMAT; goto ldone; }

   /* Does the output string start with a '/' */
	if( pathin[0] == '/' )
	  strcpy( bufout, "/");

   /* do we need to append '/' to end of output string */
   if( pathin[strlen(pathin)-1] == '/')
		endding_slash = TRUE;
   else
		endding_slash = FALSE;

   /*-----------------------------------------------------------------
	** Parse each token, expand if necessary 
	*/
   firsttime = TRUE;
	token = strtok( bufin, "/ ");  /* first token */

	while( token != NULL )
	{
		len = strlen( token );

		if( (firsttime) && (token[0]=='~') && (len==1) )
		{
			/* For ~ on first token. */
			if( NULL != (cptr = getenv("HOME")) )
				token = cptr;
		}
		if( (firsttime) && (token[0]=='~') && (len>1) )
		{
			/* For ~username on first token. */
			if( NULL != ( pw_entry = getpwnam(token+1)) )
				token = (char*)pw_entry->pw_dir;
		}
		else if( (token[0]=='$') && (len > 1) )
		{
			/* expand any $KEYWORD from enviroment variables */
			if( NULL != (cptr = getenv(token+1)) )
				token = cptr;
		}
		
		/* copy bufin to bufout */
		strcat( bufout, token);

      /* get next token */
		if( (token = strtok(NULL, "/ ")) != NULL )
			strcat( bufout, "/");

		firsttime = FALSE;
	}

   if( endding_slash && bufout[strlen(bufout)-1] != '/')
		strcat( bufout, "/");

ldone:
   /* copy back to user */
	strxcpy( pathout, bufout, pathout_size);
	
   free( bufin );
   free( bufout );
   return rc;
}

/************************ eof ************************/
