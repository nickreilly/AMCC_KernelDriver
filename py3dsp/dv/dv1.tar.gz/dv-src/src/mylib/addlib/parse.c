/*******************************************************************
** some function for help parse data type out of strings
** Note, these use the strtok function.
********************************************************************
*/

#define EXTERN

/*--------------------------
*  include files
*--------------------------
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
 
#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"
#include "error_msg.h"

/*----------------------------------------------------------
**  parseInt() - parse & convert to int.
**----------------------------------------------------------
*/
int parseInt( int * ip, char *buf, const char *tok )
{
   char * c;
	long l;
	
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   if( -1 == my_atol( c, &l))
		return ERR_INV_FORMAT;

   *ip = (int)l;
   return ERR_NONE;
}

/*----------------------------------------------------------------
**  parseIntR() - parse & convert to int, with range checking
**---------------------------------------------------------------
*/
int parseIntR( int * ip, char *buf, const char *tok, int min, int max )
{
   int rc;

   if( (rc = parseInt( ip, buf, tok )) != ERR_NONE )
		return rc;

   if( !INRANGE( min, *ip, max ))
		return ERR_INV_RNG;

   return ERR_NONE;
}

/*----------------------------------------------------------
**  parseLong() - parse & convert to long.
**----------------------------------------------------------
*/
int parseLong( long * lp, char *buf, const char *tok )
{
   char * c;
	long l;
	
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   if( -1 == my_atol( c, &l))
		return ERR_INV_FORMAT;

   *lp = l;
   return ERR_NONE;
}

/*----------------------------------------------------------------
**  parseLongR() - parse & convert to long, with range checking
**---------------------------------------------------------------
*/
int parseLongR( long * lp, char *buf, const char *tok, long min, long max )
{
   int rc;

   if( (rc = parseLong( lp, buf, tok )) != ERR_NONE )
		return rc;

   if( !INRANGE( min, *lp, max ))
		return ERR_INV_RNG;

   return ERR_NONE;
}


/*----------------------------------------------------------
**  parseDouble() - parse & convert to double.
**----------------------------------------------------------
*/
int parseDouble( double *dp, char *buf, const char *tok )
{
   char * c;
	double d;
	
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   d = atof( c );

   *dp = d;
   return ERR_NONE;
}


/*--------------------------------------------------------------------
**  parseDouble() - parse & convert to double, with range checking
**--------------------------------------------------------------------
*/
int parseDoubleR( double *dp, char *buf, const char *tok, double min, double max )
{
   int rc;

   if( (rc = parseDouble( dp, buf, tok )) != ERR_NONE )
		return rc;

   if( !INRANGE( min, *dp, max ))
		return ERR_INV_RNG;

   return ERR_NONE;
}

/*----------------------------------------------------------
**  parseFloat() - parse & convert to float.
**----------------------------------------------------------
*/
int parseFloat( float *fp, char *buf, const char *tok )
{
   char * c;
	float f;
	
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   f = atof( c );

   *fp = f;
   return ERR_NONE;
}


/*--------------------------------------------------------------------
**  parseFloatR() - parse & convert to double, with range checking
**--------------------------------------------------------------------
*/
int parseFloatR( float *fp, char *buf, const char *tok, float min, float max )
{
   int rc;

   if( (rc = parseFloat( fp, buf, tok )) != ERR_NONE )
		return rc;

   /* printf("%7.5f %7.5f %7.5f\n", min, *fp, max); */
   if( !INRANGE( min, *fp, max ))
		return ERR_INV_RNG;

   return ERR_NONE;
}

/*--------------------------------------------------------------
**  parseSelection() - search a list for item.
**     Return:  >= 0         =  the index of the matching item.
**              ERR_INV_RNG  =  Item is not in list.
**--------------------------------------------------------------
*/
int parseSelection( 
   char * buf,     /* parameter for item to locate */
	char * tok,     /* token for parsing */
   char ** list    /* This list must be NULL terminaled */
)
{
   int i;
	char *c;
 
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   for( i=0; list[i] != NULL; i++)
   {
     if( !stricmp( c, list[i] ))
       return i;
   }
   return ERR_INV_RNG;
}

/*--------------------------------------------------------------------
**  parseString() - parse & copies a string into buf. 
**--------------------------------------------------------------------
*/
int parseString( char *outb, int outb_size, char *buf, const char *tok  )
{
	char *c;

	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   strxcpy( outb, c, outb_size);
	return ERR_NONE;
}
