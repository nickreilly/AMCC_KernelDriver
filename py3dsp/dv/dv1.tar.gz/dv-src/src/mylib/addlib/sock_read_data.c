/***************************************************************************
 *
 *  socket.c - routine for socket communcation
 *
 ***************************************************************************
 */

#define EXTERN
#define DEBUG    0
#define FUN_NAME 0

/*--------------------------
 *  Standard include files
 *--------------------------
 */
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#endif

#if LYNX
#include <oscalls.h>
#endif


/*-----------------------------
 *  Non-standard include files
 *-----------------------------
 */

#include "addlib.h"
#include "error_msg.h"


/*-----------------------------------------------------------------------
**  sock_read_data() - reads bufsize bytes to buffer buf. This function
**       after it reads the # of bytes requested or a read error occurred.
**       Returns:   <0   error reading socket.
**                  >0   Number of bytes recieved.
**-----------------------------------------------------------------------
*/
long sock_read_data( fd, buf, bufsize, blocking, socket_timeout_cnt )
   int  fd;                 /* Socket's file descriptor   */
   char * buf;              /* Recieve buffer             */
   long bufsize;            /* len of buffer in bytes     */
   int  blocking;           /* specify blocking (TRUE) or non-blocking (FALSE) */
   int socket_timeout_cnt;  /* number of 0.10 sleeps for non-blocking waits */
{
   long  total;
   int   len;
   int   status_flags;
   int   sleep_cnt;

#if( FUN_NAME )
      printf("sock_read_data() bufsize %d blocking %d\n", bufsize, blocking);
#endif

   if( !blocking )                 /* making it non-blocking */
   {
      status_flags = fcntl( fd, F_GETFL, 0);
      if( fcntl(fd, F_SETFL, O_NDELAY) < 0)
         return ERR_SOCKET_ERR;
   }

   sleep_cnt = socket_timeout_cnt;   /* number of 0.10 sleeps for non-blocking waits */
   total = 0;
   while( bufsize > 0 )
   {
      len = ( bufsize > PACKET_SIZE ? PACKET_SIZE : bufsize );
      len = read( fd, (char *) buf, len );
      if( len < 0)
      {
         if( errno == EWOULDBLOCK )
         {
            if( !(sleep_cnt--))
               return ERR_SOCKET_TIMEOUT;
            usleep(100000);        /* sleep for 0.10 seconds */
         }
         else
         {
            /* perror( "sock_read_data() error @1"); */
            return ERR_SOCKET_ERR;
         }
      }
      else
      {
         if( len > 0  )
         {
            bufsize -= len;   /* update counter & pointers */
            buf += len;
            total += len;

				sleep_cnt = socket_timeout_cnt;  /* reset sleep counter when you read data  */
         }
         else                        /* if connection is terminated, read() */
         {
            /* perror("sock_read_data() error@2"); */
            return ERR_SOCKET_ERR;   /* returns 0 with len = 0.             */
         }
      }
   }

   if( !blocking )                   /* restore flages */
   {
      fcntl( fd, F_SETFL, status_flags);
   }

#if( DEBUG )
      printf("Exit #bytes=%d\n", total);
#endif
   return total;
}

