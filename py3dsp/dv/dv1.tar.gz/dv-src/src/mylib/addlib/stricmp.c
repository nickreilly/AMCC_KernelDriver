
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>

#include "addlib.h"

/*----------------------------------------------------------
**  stricmp() - case insentive version of strcmp();
**----------------------------------------------------------
*/
int stricmp( s, t)
   char *s, *t;
{
   register char sc, tc;
   while(1)
   {
      sc = ( islower(*s) ? toupper(*s) : *s);
      tc = ( islower(*t) ? toupper(*t) : *t);
      if( sc != tc )
         break;
      if( sc == '\0' || tc == '\0' )
         break;
      s++;  t++;
   }
   return ( sc  - tc );
}

