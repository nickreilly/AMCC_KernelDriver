/***************************************************************************
 *
 *  socket.c - routine for socket communcation
 *
 ***************************************************************************
 */

#define EXTERN

/*--------------------------
 *  Standard include files
 *--------------------------
 */
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*-----------------------------
 *  Non-standard include files
 *-----------------------------
 */

#include "addlib.h"
#include "error_msg.h"

/*-----------------------------------------------------------------------
**  sock_write_data() - writes bufsize number of bytes at location
**       buf at file description sock.
**       return:  -1   error writing to sock.
**                >0   number of long int written.
**-----------------------------------------------------------------------
*/
long sock_write_data( fd, buf, bufsize, blocking, socket_timeout_cnt )
   int  fd;                 /* Socket's file descriptor   */
   char * buf;              /* Pointer to buffer area */
   long bufsize;            /* number of byte to send */
   int  blocking;           /* specify blocking (TRUE) or non-blocking (FALSE) */
   int socket_timeout_cnt;  /* number of 0.1 sec sleep for non-blocking sockets */
{
   int  len,
        sleep_cnt,
        status_flags;
   long total;

#if( FUN_NAME )
      printf("sock_write_data()\n");
#endif

   if( !blocking )                 /* making it non-blocking */
   {
      status_flags = fcntl( fd, F_GETFL, 0);
      if( fcntl(fd, F_SETFL, O_NDELAY) < 0)
         return ERR_SOCKET_ERR;
   }

   sleep_cnt = socket_timeout_cnt;   /* number of 0.1 sec sleep for non-blocking sockets */
   total = 0;
   while( bufsize > 0 )
   {
      len = ( bufsize > PACKET_SIZE ? PACKET_SIZE : bufsize );
      len = write(fd, (char *) buf, len);

      if( len  < 0 )
      {
         if( errno == EWOULDBLOCK )
         {
            if( !(sleep_cnt--))
               return ERR_SOCKET_TIMEOUT;
            usleep(100000);          /* sleep for 0.1 seconds */
         }
         else
         {
            return ERR_SOCKET_ERR;
         }
      }
      else
      {
         bufsize -= len;   /* update counter & pointer */
         buf += len;
         total += len;

			sleep_cnt = socket_timeout_cnt;  /* reset sleep counter when you write data */
      }
   }

   if( !blocking )                   /* restore flages */
   {
      fcntl( fd, F_SETFL, status_flags);
   }
   return total;
}

