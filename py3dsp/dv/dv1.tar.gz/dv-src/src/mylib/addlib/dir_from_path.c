
 
#define EXTERN
 
/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
 
/*------------------------------
**  Non-standard include files
**------------------------------
*/
 
#include "addlib.h"
 
/*-------------------------------------------------------------------
**   dir_from_path () - extracts the file name portion from a
**           full pathname.
**-------------------------------------------------------------------
*/
#if defined(__STDC__)
void dir_from_path( char *dir, char *pathname, int dir_size )
#else
void file_from_path( dir, pathname, filename_size )
   char * dir;
   char * pathname;
   int  dir_size;     /* size of desintation buffer */
#endif
{
   int  size;
   char * slash;
   char buf[256];
 
   /* initialize to null */
   *dir = 0;
 
   /* find last '/' in path */
   if( NULL == (slash = strrchr( pathname, '/')) )
      return;
 
   size = MIN(slash - pathname+1, dir_size);
   size = MAX( 0, size);
 
   /* copy directory to user. We copy to local variable buf just in case
      the destination filename is the same or overlaps the pathname. */
   strxcpy( buf, pathname, size);
   strcpy( dir, buf);
}
 

