/*****************************************************************
** io.c - function for write to I/O ports
******************************************************************
*/

#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
 
#if SUNOS 
/* For SUNOS & Solaris these are dummy routines */

short inp8( port)
	short port;
{ return 0; }

short outp8(port, data)
	short port, data;
{ return 0; }

short inp16( port )
	short port;
{ return 0; }

short outp16( port,  data)
   short port, data;
{ return 0; }

long outp32( port, data )
   short port;
   long  data;
{ return 0; }

long inp32( port )
   short port;
{ return 0; }

#endif

#if LYNX 
/* For LYNX, you must use the cc compiler */

/*------------------------------------------------------------
**  read/write  a 8-bit word from I/O port
**------------------------------------------------------------
*/
int inp8(port)
	short port;
{
   asm {
      xor   eax, eax
      mov   DX, port[EBP]
      in    AL, DX
   }
}
 
int outp8(port, data)
short port, data;
{
   asm {
      movzx  eax, data[EBP]
      movzx  edx, port[EBP]
      out    DX, AL
   }
}


/*------------------------------------------------------------
**  in16() - read a 16-bit word from I/O port
**------------------------------------------------------------
*/
int inp16( port )
short port;
{
    asm {
        xor    eax, eax
        movzx  edx, port[EBP]
        in     ax, dx
    }
}

/*------------------------------------------------------------
**  out16() - writes 16-bit word to I/O port
**------------------------------------------------------------
*/
int outp16( port,  data)
   short port, data;
{
    asm {
        movzx  eax, data[EBP]
        movzx  edx, port[EBP]
        out    dx, ax
        }
}

/*------------------------------------------------------------
**  outp32() - writes 32-bit word to I/O port.
**            lw->DX, hw->DX+2
**------------------------------------------------------------
*/
long outp32( port, data )
   short port;
   long  data;
{
    asm {
        movzx   edx, port[ebp]
        mov     eax, data[ebp]
        out     dx, eax
        }
}

/*------------------------------------------------------------
**  inp32() - reads a 32-bit word from port, port+2.
**            lw<-DX, hw<-DX+2
**------------------------------------------------------------
*/
long inp32( port )
   short port;
{
    asm {
        movzx    edx,port[ebp]   ; address this port
        in       eax,dx          ; get low word
        }
}

#endif
