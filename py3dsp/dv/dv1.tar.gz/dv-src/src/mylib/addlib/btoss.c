
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "addlib.h"

/*----------------------------------------------------------
** btoss( s ) - Create a string of 0's and 1's based on the
**              bit pattern in s.
**              Note: s should be at least char[40];
**----------------------------------------------------------
*/
#if defined(__STDC__)
char * btoss ( char * s,  unsigned short l )
#else
char * btoss ( s, l )
	char * s;
	unsigned short l;
#endif
{
   int i;
   unsigned short mask;
   char * cptr;
 
   mask = 0x8000;
   cptr = s;
   for( i=0; i<16; i++)
   {
      *cptr++ = ( l & mask ? '1' : '0' );
      if( (i % 4)==3 ) *cptr++ = ' ';
      mask >>= 1;
   }
   *cptr = 0;
	return s;
}

