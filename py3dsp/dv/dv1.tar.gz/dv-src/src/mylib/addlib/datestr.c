
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

/*--------------------------------------------------------------------
**  dateStr2Sec() - convert a string in format "yyyy/mm/dd.d"
**      to unix time -  seconds (as a double).
**--------------------------------------------------------------------
*/
int dateStr2sec(
   double *Rsec,       /* Returns seconds to the caller */
   char   *str         /* string in time format (hh:mm:ss.ss) to convert */
   )
{
   char buf[30];
   int year, month;
   double seconds;
   char * cptr;

   if( str == NULL )
      return ERR_INV_FORMAT;

   strxcpy( buf, str, sizeof(buf));

   if( NULL == (cptr = strtok( buf, " /")) )
      return( ERR_INV_FORMAT );
   year = ( cptr == NULL ? 0 : atoi(cptr) );

   if( NULL == (cptr = strtok( (char*)NULL, " /")) )
      return( ERR_INV_FORMAT );
   month = ( cptr == NULL ? 0 : atoi(cptr) );

   if( NULL == (cptr = strtok( (char*)NULL, " /")) )
      return( ERR_INV_FORMAT );
   seconds = ( cptr == NULL ? 0 : atof(cptr) );

   return ERR_NONE;
}

/*----------------------------------------------------------------------
** sec2TimeStr() convert a double (number of seconds) into a string
**    with the format "hh:mm:ss.ss".
**    Return the the address containing the formatted string.
**----------------------------------------------------------------------
*/
char * sec2timeStr (
   double sec,       /* convert test seconds to a string */
   int decimals      /* number of decmial points for ss.ss */
)
{
   static char buf[30];

   char fmt[30];
   int  hh, mm, sign;

   if( sec < 0 )
   {
      sec = -sec;
      sign = -1;
   }
   else
      sign = 1;

   hh = (int) floor( sec / 3600.0 );
   sec -= 3600.0 * hh;

   mm = (int) floor( sec / 60.0 );
   sec -= 60.0 * mm;

   if( decimals <= 0 )
      sprintf( buf, "%02d:%02d:%2.0f", sign*hh, mm, sec);
   else
   {
      sprintf( fmt, "%%02d:%%02d:%%2.%df", decimals);
      sprintf( buf, fmt, sign*hh, mm, sec);
   }
   return buf;
}

