
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#if LYNOS
#include <oscalls.h>
#endif

#include "addlib.h"

/*--------------------------------------------------
** elapse_ms()
**--------------------------------------------------
*/
#if defined(__STDC__)
long elapse_ms( struct timeval *then)
#else
long elapse_ms( then )
   struct timeval *then;
#endif
{
   struct timeval now;
   struct timezone tzone;
 
   gettimeofday( &now, &tzone);
   now.tv_usec -= then->tv_usec;
   now.tv_sec -= then->tv_sec;
   if( now.tv_usec < 0 )
   {
      now.tv_usec += 1000000;
      now.tv_sec -= 1;
   }
   return (now.tv_usec/1000) + (1000L*now.tv_sec);
}

