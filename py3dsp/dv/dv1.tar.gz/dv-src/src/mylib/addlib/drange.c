
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
 
#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"

/*----------------------------------------------------------
** drange() - Normalizes the value v to be within min & max.
**             Cirular coordinate system are assumed, ie:
**             min = max;  max+1=min+1; min-1 = max-1;
**----------------------------------------------------------
*/
#if defined(__STDC__)
double drange( double v, double min, double max)
#else
double drange( v, min, max)
	double v;     /* value to check */
	double min;   /* minimum value of v */
	double max;   /* maximum value of v */
#endif
{
   if( v < min )
      return fmod ((v-max), max-min) + max;
   if( v >= max )
      return fmod ((v-max), max-min) + min;
   return v;
}

