
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "addlib.h"

/*----------------------------------------------------------
** btosl( s ) - Create a string of 0's and 1's based on the
**              bit pattern in l.
**              Note: s should be at least char[40];
**              returns s.
**----------------------------------------------------------
*/
#if defined(__STDC__)
char * btosl ( char * s,  unsigned long l )
#else
char * btosl ( s, c )
   char *s;
   unsigned long l;
#endif
{
   int i;
   unsigned long mask;
   char * cptr;
 
   mask = 0x80000000;
   cptr = s;
   for( i=0; i<32; i++)
   {
      *cptr++ = ( l & mask ? '1' : '0' );
      if( (i % 4)==3 ) *cptr++ = ' ';
      mask >>= 1;
   }
   *cptr = 0;
	return s;
}

