#define EXTERN
#define MAIN    0

/*--------------------------
 *  Standard include files
 *--------------------------
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#if LYNX
#include <oscalls.h>
#endif
 
#include "addlib.h"

/****************************************************************************
**  Help with shared memory.
*****************************************************************************
**/

/*-------------------------------------------------------------------------
**   shmtran() - translate shared memroy key to segment ID.
**        If create_it is true, it will create a new segment ID.
**        if a 'key' already exist, it is destroy and re-created.
**        returns:
**                  >=0 - segment ID.
**                   -1 - Error.
**-------------------------------------------------------------------------
*/
int shmtran( key, nbytes, create_it )
   int   key;                 /* Shared memory key             */
   int   nbytes;              /* Size of shared memory segment */
   int   create_it;
{
   int segid;

   segid = shmget( (key_t) key, nbytes, 0666);
   if( !create_it )
      return segid;

   /* if segment ID already exist, destroy it.  */
   if( segid != -1)
   {
      if( shmctl(segid, IPC_RMID, NULL) < 0)
      {
         perror("shmtran()-shmctl");
         return -1;
      }
   }

   /* Create segment ID with "name" key  */
   if( (segid = shmget( (key_t) key, nbytes, IPC_CREAT | 0666)) < 0)
      {
         perror("shmtran()-shmget");
         return -1;
      }

   return segid;
}

