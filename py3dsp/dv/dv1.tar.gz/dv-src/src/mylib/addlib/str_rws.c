
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>

#include "addlib.h"

/*---------------------------------------------------------
**  str_rws() - changes white space characters in a string to ' '.
**---------------------------------------------------------
*/
char *str_rws( s, maxlen )
   char * s;
   unsigned int maxlen;
{
   char *cptr = s;
   while( maxlen && *cptr!=0 )
   {
      if( isspace(*cptr) ) *cptr = ' ';
      maxlen--;
      cptr++;
   }
   return s;
}

