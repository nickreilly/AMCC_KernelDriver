/****************************************************************************
 *  ipc_help.c - function to aid you in using ipc facilities.
 ****************************************************************************
 */

#define EXTERN
#define MAIN    0

/*--------------------------
 *  Standard include files
 *--------------------------
 */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"

/* The following is from the linux man page on semctl() */
#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
	/* union semun is defined by including <sys/sem.h> */
#else
	/* according to X/OPEN we have to define it ourselves */
	union semun {
			int val;                    /* value for SETVAL */
			struct semid_ds *buf;       /* buffer for IPC_STAT, IPC_SET */
			unsigned short int *array;  /* array for GETALL, SETALL */
			struct seminfo *__buf;      /* buffer for IPC_INFO */
	};
#endif

/****************************************************************************
**  help with semaphores.
*****************************************************************************
**/

/*-------------------------------------------------------------------------
**   semtran() - translate semaphore key to ID.
**        If create_it is true, it will create a new semaphore.
**        if a 'key' already exist, it is destroy and re-created.
**        returns:
**                  >0 - semaphore ID.
**                  -1 - Error.
**-------------------------------------------------------------------------
*/
int semtran( key, create_it )
   int   key;                      /* 'Name' of message queue */
   int   create_it;
{
   int sid;
   int rc;
#if LINUX
	union semun sem_arg;
#else
   void * sem_arg = NULL;
#endif

   sid = semget( (key_t) key, 1, 0666);
   if( !create_it )
      return sid;

   /* if semaphore already exist, destroy it.  */
   if( sid != -1)
   {
      /*  Destroy semaphore */
		if( (rc=semctl(sid, 0, IPC_RMID, sem_arg)) < 0)
      {
			perror("semctl");
         return -1;
      }
   }

   /* Create semaphore with "name" key  */
   if( (sid = semget( (key_t) key, 1, IPC_CREAT | 0666)) < 0)
         return -1;

   return sid;
}

#if 0

 P() & V() are macro defined in addlib.h. I think lynxOS chokes when
 they are define as functions.

/*-------------------------------------------------------------------------
**  P() - calls semop() to request the semaphore
**-------------------------------------------------------------------------
*/
int P( int sid )
{
   struct sembuf sb;

   sb.sem_num = 0;
   sb.sem_op = -1;
   sb.sem_flg = 0;
   if( semop(sid, &sb, 1) == -1)
	{
      perror("semop");
		return -1;
	}
	return 0;
}

/*-------------------------------------------------------------------------
**  V() - calls semop() to release the semaphore
**-------------------------------------------------------------------------
*/
int V( int sid )
{
   struct sembuf sb;

   sb.sem_num = 0;
   sb.sem_op = 1;
   sb.sem_flg = 0;
   if( semop(sid, &sb, 1) == -1)
	{
      perror("semop");
		return -1;
	}
	return 0;
}

#endif 

/*-------------------------------------------------------------------------
**  sem_op() - calls semop() to increment or decrement by value.
**-------------------------------------------------------------------------
*/
int sem_op( int sid, int value )
{
   struct sembuf sb;

   sb.sem_num = 0;
   sb.sem_op = value;
   sb.sem_flg = 0;
   if( semop(sid, &sb, 1) == -1)
	{
      perror("semop");
		return -1;
	}
	return 0;
}
