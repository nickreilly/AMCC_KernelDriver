#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

/*-------------------------------------------------------------------
**   cat_pathname () - concatenates the path and filename string to
**           pathname. maxlen should be set to sizeof(pathname).
**           returns pathname.
**-------------------------------------------------------------------
*/
#if defined(__STDC__)
char * cat_pathname( char * pathname, char * path, char * filename, int maxlen)
#else
char * cat_pathname( pathname, path, filename, maxlen )
   char * pathname;
   char * path;
   char * filename;
   int  maxlen;
#endif
{
   char tempstr[256];
   char * cptr;
   int l;

   maxlen = MIN( maxlen, sizeof(tempstr));
   strxcpy(tempstr, path, maxlen);
   unpad( tempstr, ' ' );

   l = strlen(tempstr);
   if( l>0 && tempstr[l-1] != '/' && l < maxlen)
      strcat(tempstr, "/");
   for( cptr=filename; (*cptr==' ') && (*cptr != 0) ;) cptr++;
   strncat( tempstr, cptr, maxlen-l );
   strxcpy( pathname, tempstr, maxlen);
   return pathname;
}

/************************ eof ************************/
