
/*--------------------------
 *  Standard include files
 *--------------------------
 */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"

/****************************************************************************
**  help with messages.
*****************************************************************************
**/

/*-------------------------------------------------------------------------
**   msgtran() - Translate message queue key to ID.
**        If create_it is true, it will create a new message queue.
**        if a 'key' already exist, it is destroy and re-created.
**        returns:
**                       >0 - queue ID.
**                       -1 - Error.
**-------------------------------------------------------------------------
*/
int msgtran( key, create_it )
   int key;                      /* 'Name' of message queue */
   int create_it;                /* Create a new message queue */
{
   int msqid;
   struct msqid_ds sbuf;

   msqid = msgget( (key_t) key, 0666);
   if( !create_it )
      return msqid;

   /* if msg queue already exist, destroy it.  */
   if( msqid != -1)
   {
      /*  Destroy Message queue */
      if( msgctl(msqid, IPC_RMID, &sbuf) < 0)
         return -1;
   }

   /* Create message queue with "name" key  */
   if( (msqid = msgget( (key_t) key, IPC_CREAT | 0666)) < 0)
         return -1;

   return msqid;
}


