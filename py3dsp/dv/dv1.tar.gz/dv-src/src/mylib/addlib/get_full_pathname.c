
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <math.h>
#include <pwd.h>
#include <sys/time.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

#define DIRECTORY_MODE  (S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH)
                         /* DIRECTORY_MODE mask give user full privilages and */
                         /* group and others read and execute privilages */


/*----------------------------------------------------------------------------
**  get_full_pathname() - Get a full pathname of an existing dir.
**                        ie: gets the full name of stuff like "../home".
**----------------------------------------------------------------------------
*/
int get_full_pathname( pathout, pathout_size, pathin )
	char *pathout;
	int   pathout_size;
	char *pathin;
{
   int  rc;
   char *workingdir,
        *dirname;
 
   /* Allocate and initialize memory */
   workingdir  = (char*) malloc((unsigned)MAXPATHLEN);
   dirname     = (char*) malloc((unsigned)MAXPATHLEN);
   if( workingdir==NULL || dirname==NULL)
   {
      if( workingdir )  free( workingdir );
      if( dirname ) free( dirname );
      return MEM_ALT_ERR;
   }
 
   rc = ERR_NONE;
 
   /* Get the current working directory */
   getcwd( workingdir, MAXPATHLEN);
 
   strncpy( dirname, pathin, MAXPATHLEN);
   unpad( dirname, ' ');
 
   /* change to dirname & use getcwd() to expand to full name */
   if( chdir( dirname )==0 )
   {
      getcwd( dirname, MAXPATHLEN);
      strncpy( pathout, dirname, pathout_size);
   }
   else
      rc = ERR_INV_PATH;
 
   /* return to original working directory */
   chdir( workingdir );
 
   free( workingdir );
   free( dirname );
   return rc;
}


/************************ eof ************************/
