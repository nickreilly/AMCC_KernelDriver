
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>

#include "addlib.h"

/*-------------------------------------------------------------
** my_atol() - convert a string to a long. The string s
**   must consist of  '[white space][+-] digits [white spaces]'
**   returns error: 0 = noerror;
**                 -1 = invalid char in string
**-------------------------------------------------------------
*/
 
#if defined(__STDC__)
int my_atol( char *s, long *l )
#else
int my_atol( s, l )
   char * s;
   long * l;
#endif
{
   char *start;
   int  cnt;
 
   if( s == NULL)
      return -1;
 
   while( isspace(*s) ) s++;     /* Skip leading spaces */
   start = s;
 
   if( *s=='-' || *s=='+' ) s++; /* First char can be a signed */
 
   cnt = 0;
   while( isdigit(*s) )          /* Only allow decimal digits */
   {
     s++;
     cnt++;
   }
   if( !cnt )  return -1;
                                 /* Allow ONLY trailing white spaces */
   while( *s )
      if( isspace(*s) )
         s++;
      else
         return -1;
 
   *l = strtol( start, (char**) NULL, 10 );
   return 0;
}
 


