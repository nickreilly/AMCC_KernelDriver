#define EXTERN
 
/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
 
/*------------------------------
**  Non-standard include files
**------------------------------
*/
 
#include "addlib.h"
 
/*-------------------------------------------------------------------
**   filename_from_path () - extracts the file name portion from a
**           full pathname.
**-------------------------------------------------------------------
*/
#if defined(__STDC__)
void filename_from_path( char *filename, char *pathname, int filename_size )
#else
void filename_from_path( filename, pathname, filename_size )
   char * filename;
   char * pathname;
   int  filename_size;    /* size of desintation buffer */
#endif
{
   char * slash,
        * start;
   char buf[80];
 
   /* initialize to null */
   *filename = 0;
 
   /* find last '/' in path */
   if( NULL == (slash = strrchr( pathname, '/')) )
      start = pathname;
   else
      start = slash+1;
 
   /* copy filename to user. We copy to local variable buf just in case
      the destination filename is the same or overlaps the pathname. */
   strxcpy( buf, start, filename_size);
   strcpy(  filename, buf);
}

