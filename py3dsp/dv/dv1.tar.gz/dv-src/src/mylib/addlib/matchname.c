
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "addlib.h"

/*----------------------------------------------------------
**  matchname - checks if pattern matches the name. Pattern
**              can contain '*', '?' anywhere.
**  Returns:  1 if name matches pattern, 0 otherwise.
**----------------------------------------------------------
*/
 
#if defined(__STDC__)
int matchname( char *pattern, char *name )
#else
int matchname( pattern, name )
   char * pattern;
   char * name;
#endif
{
   while( *pattern )
   {
     if( (*pattern == *name) || (*pattern=='?' && *name))
     {
       pattern++;
       name++;
     }
     else if( *pattern == '*' )
     {
       for(;;)
       {
         if( matchname( pattern+1, name)) return 1;
         if( *name ) name++;
         else return 0;
       }
     }
     else return 0;
   }
   return *name == '\0';
}

