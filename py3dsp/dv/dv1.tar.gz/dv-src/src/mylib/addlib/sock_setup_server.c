#define EXTERN
#define DEBUG    0
#define FUN_NAME 0

/*--------------------------
 *  Standard include files
 *--------------------------
 */
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*-----------------------------
 *  Non-standard include files
 *-----------------------------
 */

#include "addlib.h"

/*-----------------------------------------------------------------------
**  sock_setup_server() - Sets up a socket connection to accept
**       connection request.
**       Returns:    -1 =  Unable to estalish connection.
**                    otherwise the fd of socket is returned.
**-----------------------------------------------------------------------
*/
int sock_setup_server( port_no )
	int port_no;
{
   int fd;
	int one;
   struct sockaddr_in server;

   /*
   **  Create socket...
   */
   if( (fd = socket( AF_INET, SOCK_STREAM, 0)) < 0 )
      return -1;

   one = 1;
	setsockopt( fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof( one ));
   /*
   **  name socket using <host_addr>, <UI_PORT>.
   */
   server.sin_family = AF_INET;
   server.sin_addr.s_addr = htonl(INADDR_ANY);
   server.sin_port = htons( (unsigned short)port_no);
   if( bind(fd, (struct sockaddr *) &server, sizeof server) < 0 )
      return -1;
   /*
   ** Inquire <address>, <port no> and print it out
   */
#if DEBUG
   {
      char buf[80];
      int len;
      len = sizeof server;
      getsockname( fd, (struct sockaddr *) &server, &len );
      gethostname( buf, sizeof buf);
      printf("Socket server established [%s] port #%d\n",
             buf, ntohs(server.sin_port));
   }
#endif
   /*
   **  Listen for connection request.
   */
#if DEBUG
   printf("Listening\n");
#endif
   listen( fd, 5);
   return fd;
}

