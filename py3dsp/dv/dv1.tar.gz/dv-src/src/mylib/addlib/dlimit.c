
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
 
#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"

/*----------------------------------------------------------
** dlimit() - If v is outside the min or max limits, v
**            is set to min or max.
**----------------------------------------------------------
*/
#if defined(__STDC__)
double dlimit( double v, double min, double max)
#else
double dlimit( v, min, max)
	double v;    /* value to check */
	double min;  /* minimum limit */
	double max;  /* maximum limit */
#endif
{
   if( v > max ) v =  max;
   if( v < min ) v =  min;
   return v;
}

