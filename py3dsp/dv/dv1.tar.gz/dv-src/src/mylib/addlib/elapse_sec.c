#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#if LYNOS
#include <oscalls.h>
#endif

#include "addlib.h"

/*------------------------------------------------------
** elapse_sec() - returns the elapse seconds as a float
**  from start to end (timeval).
**------------------------------------------------------
*/

float elapse_sec( struct timeval *start, struct timeval *end)
{
   long sec, usec;
   float f;

   sec  = end->tv_sec - start->tv_sec;
   usec  = end->tv_usec - start->tv_usec;

   if( (usec < 1000000) && (sec > 1))
   {
      usec += 1000000;
      sec++;
   }
   if( (usec > 1000000) && (sec < 1))
   {
      usec -= 1000000;
      sec--;
   }

   f = usec/1000000.0;
   f += sec;

   return f;
}

