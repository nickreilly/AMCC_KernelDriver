
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

/*-----------------------------------------------------------
**   exist_path() - Test of pathname is a ready a directory.
**         Returns:   0   pathname exist.
**                   -1   pathname is not a directory.
**-----------------------------------------------------------
*/
#if defined(__STDC__)
int exist_path( char * pathname )
#else
int exist_path( pathname )
	char * pathname;
#endif
{
   struct stat sbuf;

   if( -1 == stat( pathname, &sbuf))
      return -1;

   if( sbuf.st_mode & (S_IFDIR | S_IREAD | S_IEXEC ))
      return 0;
   else
      return -1;
}

/************************ eof ************************/
