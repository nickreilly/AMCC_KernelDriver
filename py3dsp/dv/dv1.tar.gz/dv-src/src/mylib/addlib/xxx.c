/*******************************************************************
** some function for help parse data type out of strings
** Note, these use the strtok function.
********************************************************************
*/

#define EXTERN extern

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
 
#if LYNX
#include <oscalls.h>
#endif

#include "error_msg.h"
#include "addlib.h"

/*----------------------------------------------------------
**  parseLong() - parse & convert to long.
**----------------------------------------------------------
*/
int parseLong( long * lp, char *buf, const char *tok )
{
   char * c;
	long l;
	
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   if( -1 == my_atol( c, &l))
		return ERR_INV_FORMAT;

   *lp = l;
   return ERR_NONE;
}

/*----------------------------------------------------------------
**  parseLongR() - parse & convert to long, with range checking
**---------------------------------------------------------------
*/
int parseLongR( long * lp, char *buf, const char *tok, long min, long max )
{
   int rc;

   if( (rc = parseLong( lp, buf, tok )) != ERR_NONE )
		return rc;

   if( !INRANGE( min, *lp, max ))
		return ERR_INV_RNG;

   return ERR_NONE;
}


/*----------------------------------------------------------
**  parseDouble() - parse & convert to double.
**----------------------------------------------------------
*/
int parseDouble( double *dp, char *buf, const char *tok )
{
   char * c;
	double d;
	
	if( (c = strtok( buf, tok) ) == NULL)
		return ERR_INV_FORMAT;

   d = atof( par );

   *fp = d;
   return ERR_NONE;
}


/*--------------------------------------------------------------------
**  parseDouble() - parse & convert to double, with range checking
**--------------------------------------------------------------------
*/
int parseDoubleR( double *dp, char *buf, const char *tok, double min, double max )
{
   int rc;

   if( (rc = parseDouble( dp, buf, tok )) != ERR_NONE )
		return rc;

   if( !INRANGE( min, *dp, max ))
		return ERR_INV_RNG;

   return ERR_NONE;
}

/*--------------------------------------------------------------
**  parseSelection() - search a list for item.
**     Return:  >= 0         =  the index of the matching item.
**              ERR_INV_RNG  =  Item is not in list.
**--------------------------------------------------------------
*/
int parseSelection( 
   char * item,    /* Item to locate in list            */
   char ** list    /* This list must be NULL terminaled */
)
{
   int i;
 
   if( item == NULL )
      return ERR_INV_RNG;
 
   for( i=0; list[i] != NULL; i++)
   {
     if( !stricmp( item, list[i] ))
       return i;
   }
   return ERR_INV_RNG;
}


/*--------------------------------------------------------------------
**  parseString() - copies next string. If not string are available,
**    dest equals "", and rc hold and error value.
**--------------------------------------------------------------------
*/
int parseString( char *dest, char *buf, const char *tok)
{
   int rc = ERR_NONE;

	if( (c = strtok( buf, tok) ) == NULL)
   {
		rc = ERR_INV_FORMAT;
   }



   return ERR_NONE;
}

