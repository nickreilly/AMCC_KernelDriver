
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
 
#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"

/*----------------------------------------------------------
** map() - map a point from one coordinate system to another
**----------------------------------------------------------
*/
double map( double point, double pref1, double pref2, double nref1, double nref2 ) 
{
	return (double) ((point - pref1) / (pref2-pref1)) * (nref2-nref1) + nref1;
}

