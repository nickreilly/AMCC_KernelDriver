/*
** Note: Eariler version of solaris (pre-2.6) didn't have usleep in 
** their standard library. For 2.6 and later, usleep is there.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
 
#if LYNX
#include <oscalls.h>
#endif

#include "addlib.h"

/*----------------------------------------------------------
** usleep() - pause for a fix time
**----------------------------------------------------------
*/

int usleep( unsigned long usec )
{
	do      
	{
		struct timeval      usl_delay;
		usl_delay.tv_sec  = (int) (usec) / 1000000;
		usl_delay.tv_usec = (int) (usec) % 1000000;
		(void) select(0,(fd_set *)0,(fd_set *)0,(fd_set *)0, &usl_delay);
	} while (0);

	return 0;
}

