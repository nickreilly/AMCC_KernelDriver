#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#if SUNOS | LINUX | SOLARIS
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

#define DIRECTORY_MODE  (S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH)
                         /* DIRECTORY_MODE mask give user full privilages and */
                         /* group and others read and execute privilages */

/*--------------------------------------------------------------------------
 * create_path() - creates a new path
 *                return value: -1 : unsucessful
 *                               0 : pathname exist
 *--------------------------------------------------------------------------
 */
int create_path( p )
	char * p;
{
   char * path,
        * newpath,
        * name;
   int slash;

   if( NULL == (path = malloc((u_int) MAXPATHLEN)) )  /* allocate temporary buffers */
      return -1;

   if( NULL == (newpath = malloc((u_int) MAXPATHLEN)) )
      { free( path ); return -1; }

   strxcpy( path, p, MAXPATHLEN );            /* make copies of the data */
   unpad(path, ' ');

   memset( newpath, '\0', MAXPATHLEN);

   slash = (*path == '/' ? TRUE: FALSE);
   if( NULL == (name = strtok( path, "/ ")))
   {
      free(path);
      free(newpath);
      return -1;
   }

   do {                                       /* Process each token      */
      if( slash )
        strcat(newpath, "/");
      else
        slash = TRUE;

      strcat( newpath, name);
      if( exist_path( newpath) < 0 )
      {
         if( mkdir(newpath, DIRECTORY_MODE) < 0 )
         {
            free(path);
            free(newpath);
            return -1;
         }
      }
   }
   while( NULL != (name = strtok( (char*)NULL, "/ ")) );

   free(path);
   free(newpath);
   return 0;
}


/************************ eof ************************/
