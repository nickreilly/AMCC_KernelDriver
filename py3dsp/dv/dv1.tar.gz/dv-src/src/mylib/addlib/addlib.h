
/****************************************************************************
** Prototypes for addlib 
*****************************************************************************
*/

#ifndef __addlib_h
#define __addlib_h

#ifdef   __cplusplus
extern "C" {
#endif

/*-------------------------------------
**  dislist structs & defines
*/
#define DIRLIST_MAX_LIST  20
#define DIRLIST_MAX_PATH  256

struct dirlist_t
{
	char path[DIRLIST_MAX_PATH];
	int  nele;
	char *list[DIRLIST_MAX_LIST];
};

/*-------------------------------------
**  strings...
*/
char * btosl ( char * s,  unsigned long l );
char * btoss ( char * s,  unsigned short l );
int  matchname( char *pattern, char *name);
int  my_atol( char *s, long *l);
int  str_replace_sub( char *src, char *dest, int dest_size, char *pattern, char *val);
char *str_rws( char *s, unsigned int maxlen);
int stricmp( char *s, char *t);
char *strlwr( char * string);
char *strupr( char * string);
char *strxcpy( char *dest, const char *src, int maxlen);
char *unpad( char *s, int c);

int timeStr2sec( double *Rsec, char *str);
char * sec2timeStr ( double sec, int decimals);

/*-------------------------------------
**  files & directories ...
*/
char *cat_pathname( char *pathname, char *path, char *filename, int maxlen);
int create_path( char * p);
void dir_from_path( char *dir, char *pathname, int dir_size );
void dirlist_free( struct dirlist_t *dl );
void dirlist_init( struct dirlist_t *dl );
void dirlist_makelist( struct dirlist_t * dl );
void dirlist_newpath( struct dirlist_t *dl, char *path );
void dirlist_showlist( struct dirlist_t * dl );
int exist_path( char * pathname );
int expand_pathname(  char *pathout, int  pathout_size, char *pathin);
void filename_from_path( char *filename, char *pathname, int filename_size );
int get_full_pathname( char * pathout, int pathout_size, char *pathin);

/*-------------------------------------
**  socket...
*/
int sock_open( char * hostname, int port );
long sock_read_data( int fd, char *buf, long bufsize, int blocking, int socket_timeout_cnt);
int sock_read_msg( int fd, char *msg, int blocking, int socket_timeout_cnt);
int sock_setup_server( int port_no );
long sock_write_data( int fd, char *buf, long bufsize, int blocking, int socket_timeout_cnt);
int sock_write_msg( int fd, char *msg, int blocking, int socket_timeout_cnt);

/*-------------------------------------
**  ipc...
*/
int msgtran( int key, int create_it);
int shmtran( int key, int nbytes, int create_it);
int semtran( int key, int create_it);
int sem_op( int sid, int value );

/*-------------------------------------
**  io...
*/
void set_keypress(void);
void reset_keypress(void);

int inp8( short port );
int outp8( short port, short data);
int inp16( short port );
int outp16( short port, short data);
long outp32( short port, long data );
long inp32( short port);

/*--------------------------------------
** others
*/
double dlimit( double v, double min, double max);
double drange( double v, double min, double max);
double dpoly( double x, double *coeff, int degree );
void get_vector( int * dir, double *mag, double start, double dest, double size );
double map( double point, double pref1, double pref2, double nref1, double nref2 );
long elapse_ms( struct timeval *then);
float elapse_sec( struct timeval *start, struct timeval *end);
long my_timegm( int year, int yday, int hr, int min, int sec);

int parseInt( int * ip, char *buf, const char *tok );
int parseIntR( int * ip, char *buf, const char *tok, int min, int max );
int parseLong( long * lp, char *buf, const char *tok );
int parseLongR( long * lp, char *buf, const char *tok, long min, long max );
int parseDouble( double *dp, char *buf, const char *tok );
int parseDoubleR( double *dp, char *buf, const char *tok, double min, double max);
int parseFloat( float *fp, char *buf, const char *tok );
int parseFloatR( float *fp, char *buf, const char *tok, float min, float max );
int parseSelection( char * buf, char * tok, char ** list);
int parseString( char *outb, int outb_size, char *buf, const char *tok );

/*--------------------------------------------------------------------------
** defines related to socket port number and IPC ID, etc.
**--------------------------------------------------------------------------
*/
#define TCS_MSG_PORT      30010    /* Port ID for TCS communications        */
 
#define IRTF_VIEWER_MSGQ  30120    /* Message Queue name for IRTF vf program */

#define IRTF_VIEWER_PORT      30122    /* Port ID for IRTF Viewer program (vf)   */
#define IRTF_DV_PORT          30123    /* Port ID for IRTF Viewer program (dv)   */
#define IRTF_DV_BIGDOG_PORT   30124    /* Port ID for IRTF Viewer program (dv)   */
#define IRTF_DV_GUIDEDOG_PORT 30125    /* Port ID for IRTF Viewer program (dv)   */
#define IRTF_TEST_PORT        30126    /* Port ID for Application development    */
 
#define ECHELLE_MSG_PORT  30120    /* Port ID for ECHELLE spectrograph      */
#define ECHELLE_DATA_PORT 30121

#define CSHELL_MSG_PORT   30120     /* Cshell II reuses ECHELLE's ports      */
#define CSHELL_DATA_PORT  30121
 
#define NSFCAM_MSG_PORT   30140    /* Port ID for BatCam camera             */
#define NSFCAM_DATA_PORT  30141

#define GUIDER_MSG_PORT   30145    /* Port ID for BatCam camera             */
#define GUIDER_DATA_PORT  30146
 
#define MIRLIN_MSG_PORT   30147    /* Port ID for BatCam camera             */
#define MIRLIN_DATA_PORT  30148

#define SOCKET_MSG_LEN      160    /* Size of message string used in sockets */
#define PACKET_SIZE       32768    /* Max num of bytes to socket write/read  */

/*--------------------------------------
**  Very common definitions.
*/

#ifndef TRUE
#define TRUE    1
#define FALSE   0
#define ON      1
#define OFF     0
#endif
  
#ifndef INRANGE
#define INRANGE(a,x,b)   ((a) <= (x) && (x) <= (b))
#endif
	
#ifndef MAX
#define MAX( a, b )      ((a) < (b) ? (b) : (a))
#define MIN( a, b )      ((a) < (b) ? (a) : (b))
#endif
	 
#ifndef isodd
#define isodd(a)         ((a) % 2)
#define iseven(a)        (!((a) % 2))
#endif

#define P( a ) 			sem_op( a, -1)
#define V( a ) 			sem_op( a,  1)

#ifdef   __cplusplus
}
#endif

#endif /* __addlib_h */
