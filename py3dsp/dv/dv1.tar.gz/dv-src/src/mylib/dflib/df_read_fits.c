
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <math.h>

#if SOLARIS | SUNOS | LINUX
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif 

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

#include "dflib.h"

static int df_read_pixels( int fd, struct df_buf_t *bufp, int is_socket, char * fits_buf,
	double bscale, double bzero );

/*---------------------------------------------------------------------------
**  df_read_fits() - reads a fits file into the struct df_buf_t. This function
**     is for reading 2D Fits files. However, limited 3D Fits support is
**     provide.
**     IF is_3d is true, this function reads the 1st images of the 3D fits
**     files into bufp. the df_3dinfo_t struct is also file with relevant
**     information on the 3D Fits to enable the application to read the 
**     remaining frames.
**  Returns     ERR_NONE  File read OK.
**         ERR_FILE_READ  Error reading file.
**---------------------------------------------------------------------------
*/

int df_read_fits( 
   int  fd,                 /* file description to read.                   */
   char * path,             /* path & filename need for header inforamtion */
   char * filename,
   struct df_buf_t * bufp,  /* Buffer struct to hold the data. */
   int  is_socket,          /* TRUE if it's a socket, otherwise false */
	int  is_3d               /* If true, will read 1st image of 3d file */
)
{
  int loop, error, bread, i, scale_data_flag;
  long lpar;
  float fpar;
  double  bscale, bzero;
  char *fits_buf;
  char buf[85];

  struct df_fheader_t * last_hdr;
  struct df_fheader_t * f_hdr;

#if FUN_NAME
   printf(">df_read_fits()\n");
#endif
   /*
   **  Allocate buffer
   */
   if( NULL == ( fits_buf = (char *) malloc( (u_int)DF_FITS_RECORD_LEN)) )
      return(MEM_ALT_ERR);
   /*
   **  Construct filename, check if over writting old data, open file.
   */

   if( bufp->status != DF_EMPTY ) df_free_fbuffer( bufp ); /* Clear the Buffer structure */
   strxcpy( bufp->directory, path, sizeof(bufp->directory));
   strxcpy( bufp->filename,  filename, sizeof(bufp->filename));
   error = ERR_NONE;
	scale_data_flag = FALSE;
   /*
   **  Read first header block and search for required keyword & values.
   */
   if( NULL == ( bufp->fheader = (struct df_fheader_t*)
                                 malloc(  (u_int)  sizeof(struct df_fheader_t) )) )
   {
      error = MEM_ALT_ERR; goto Lerror;
   }
   bufp->fheader->next = NULL;
   
   /* Read 1st header block */
   if( is_socket )
      bread = sock_read_data( fd, (char*) bufp->fheader->buf, DF_FITS_RECORD_LEN, 
										TRUE, 20);
   else
      bread = read( fd, (char*)bufp->fheader->buf, DF_FITS_RECORD_LEN);
   if( DF_FITS_RECORD_LEN != bread )
   {
      error = ERR_FILE_READ;
      goto Lerror;
   }

   /* SIMPLE  */
   if( df_search_fheader( bufp->fheader, "SIMPLE", buf, sizeof(buf), &f_hdr, &i, FALSE) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( buf[0] != 'T' )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   /* NAXIS   */
   if( df_search_fheader( bufp->fheader, "NAXIS", buf, sizeof(buf), &f_hdr, &i, FALSE) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(2, lpar, 3) )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   /* NAXIS1  */
   if( df_search_fheader( bufp->fheader, "NAXIS1", buf, sizeof(buf), &f_hdr, &i, FALSE) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(1, lpar, 2048))
      { error = ERR_FILE_FORMAT; goto Lerror; }
   bufp->naxis1 = (short) lpar;

   /* NAXIS2  */
   if( df_search_fheader( bufp->fheader, "NAXIS2", buf, sizeof(buf), &f_hdr, &i, FALSE) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(1, lpar, 2048))
      { error = ERR_FILE_FORMAT; goto Lerror; }
   bufp->naxis2 = (short) lpar;

   /* NAXIS3  ( optional, but must be equal to 1 for 2D, ) */
	lpar = 1;
   if( df_search_fheader( bufp->fheader, "NAXIS3", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
	{
      if( -1 == my_atol( buf, &lpar) )
         { error = ERR_FILE_FORMAT; goto Lerror; }
	}
	if( (is_3d == FALSE) && (lpar > 1))
      { error = ERR_FILE_FORMAT; goto Lerror; }
    bufp->nframes = lpar;

   /* BITPIX  */
   if( df_search_fheader( bufp->fheader, "BITPIX", buf, sizeof(buf), &f_hdr, &i, FALSE) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(-32, lpar, 32))
      { error = ERR_FILE_FORMAT; goto Lerror; }
	bufp->bitpix = lpar;
   bufp->size = (short) abs((lpar/8));
   bufp->N    = bufp->naxis1 * bufp->naxis2;

   /* BSCALE */
   if( df_search_fheader( bufp->fheader, "BSCALE", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
   {
      bscale = atof( buf );
   }
	else
		bscale = 1;
   bufp->org_bscale = bscale;

   /* BZERO  */
   if( df_search_fheader( bufp->fheader, "BZERO", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
   {
      bzero = atof( buf );
   }
	else
		bzero = 0;
   bufp->org_bzero = bzero;

   /* END     */
   if( (i=df_search_fheader( bufp->fheader, "END", buf, sizeof(buf), &f_hdr, &i, FALSE)) >= 0 )
      loop = FALSE; else loop = TRUE;
   bufp->Nheader = i+1;
   bufp->sizeof_header = DF_FITS_RECORD_LEN;

   /*
   **  Now read in the rest of the headers blocks.
   */
   last_hdr = bufp->fheader;
   while( loop )
   {
      if( NULL == (last_hdr->next = (struct df_fheader_t*)
                                    malloc( (u_int) sizeof(struct df_fheader_t) )) )
      {
         error = MEM_ALT_ERR;
         goto Lerror;
      }
      last_hdr = last_hdr->next;
      last_hdr->next = NULL;

      if( is_socket )
         bread = sock_read_data(fd, (char*)last_hdr->buf, DF_FITS_RECORD_LEN, 
																     TRUE, 20 );
      else
         bread = read(fd, (char*)last_hdr->buf, DF_FITS_RECORD_LEN);
      if( DF_FITS_RECORD_LEN != bread )
      {
         error = ERR_FILE_READ;
         goto Lerror;
      }
      if( 0 <= (bufp->Nheader=df_search_fheader( bufp->fheader, "END", buf, sizeof(buf), 
			&f_hdr, &i, FALSE) ))
         loop = FALSE; else loop = TRUE;

      bufp->sizeof_header += DF_FITS_RECORD_LEN;
   }
	bufp->Nheader++;   /* This is the count, not an index */

   /*-----------------------------------------------------------------
	** search for other useful keyworks that may not be in 1st block
	*/

   /* DIVISOR */
   bufp->divisor = (short) 1;
   if( df_search_fheader( bufp->fheader, "DIVISOR", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0  )
      if( 0 == my_atol( buf, &lpar) && INRANGE(1, lpar, 32767))
         bufp->divisor = (short) lpar;

   /* ASEC_PIX  or PLATE_SC */
   bufp->arcsec_pixel = 0;
   if( df_search_fheader( bufp->fheader, "PLATE_SC", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
   {
      fpar = atof( buf );
      if( INRANGE(0.0, fpar, 10.0))
         bufp->arcsec_pixel = fpar;
   }
   if( df_search_fheader( bufp->fheader, "ASEC_PIX", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
   {
      fpar = atof( buf );
      if( INRANGE(0.0, fpar, 10.0))
         bufp->arcsec_pixel = fpar;
   }

   /* POSANGLE */
   bufp->pos_angle = 0;
   if( df_search_fheader( bufp->fheader, "POSANGLE", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
   {
      bufp->pos_angle = atof( buf );
		/* adjust angle to be in the range 0..360 */
		if( bufp->pos_angle > 360.0 )
			bufp->pos_angle = fmod( bufp->pos_angle, 360.0 );
		if( bufp->pos_angle < 0.0 )
			bufp->pos_angle = 360.0 - fmod( -bufp->pos_angle, 360.0 );
   }

   /* itime */
   bufp->itime = 1;
   if( df_search_fheader( bufp->fheader, "ITIME", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0  )
		bufp->itime = atof( buf );
   /* filter_zp */
   bufp->filter_zp = 0;
   if( df_search_fheader( bufp->fheader, "FLTZP", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0  )
		bufp->filter_zp = atof( buf );
   /* filter_zp */
   bufp->ext_coff = 0;
   if( df_search_fheader( bufp->fheader, "EXT_COF", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0  )
		bufp->ext_coff = atof( buf );
   /* filter_zp */
   bufp->airmass = 1;
   if( df_search_fheader( bufp->fheader, "AIRMASS", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0  )
		bufp->airmass = atof( buf );

   /*
   **  Allocate memory for data buffer.
	**  Note: The data is stored as floats.
   */
	if( NULL == ( bufp->fdata = (float*) malloc( (u_int)bufp->N*sizeof(float) ) ) )
      { error = MEM_ALT_ERR; goto Lerror; }

   /*
   **  Read in the data.
	*/
	if( ERR_NONE != df_read_pixels( fd, bufp, is_socket, fits_buf, bscale, bzero ))
      { error = ERR_FILE_READ; goto Lerror; }

   /*
	** Save original bitpix, size.
	** change bitpit to DF_BITPIX_FLOAT. All FITS is treated as float by dflib.
	*/
	bufp->org_size = bufp->size;
	bufp->org_bitpix = bufp->bitpix;

	bufp->size = sizeof(float);
	bufp->bitpix = DF_BITPIX_FLOAT;
	df_search_fheader( bufp->fheader, "BITPIX", buf, sizeof(buf), &f_hdr, &i, FALSE);
	df_build_card( f_hdr->buf+(i*80), "BITPIX", "-32", "32 BITS FLOATING POINT");
	/*
	** change bscale=1 & bzero=0.
	*/
	if( df_search_fheader( bufp->fheader, "BSCALE", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0 )
		df_build_card( f_hdr->buf+(i*80), "BSCALE", "1", "Scaling factor for data");
	if( df_search_fheader( bufp->fheader, "BZERO", buf, sizeof(buf), &f_hdr, &i, FALSE) >= 0) 
		df_build_card( f_hdr->buf+(i*80), "BZERO", "0", "Offset factor for data");

   /*
   **  no error.
   */
   bufp->status = DF_SAVED;
   free(fits_buf);
   return error;

   /*
   **  error handler.
   */
Lerror:                               /* on error close, free, and return */
   free(fits_buf);
   df_free_fbuffer( bufp );
   return error;
}


/*---------------------------------------------------------------------
**   df_read_pixels() - sub function to read in pixels.
**---------------------------------------------------------------------
*/

static int df_read_pixels( 
	int fd,                   /* file descriptor for reading data */
	struct df_buf_t * bufp,   /* Buffer struct to hold the data. */
	int is_socket,
	char * fits_buf,
	double bscale,
	double bzero
)
{
   int numrec,            /* number of fits records to read */
	    pixels_per_record, /* number of pixel in each FITS record */
	    pixels_left,       /* counter */
		 loop,
		 bread,
		 i;

	float *dest;

#if FUN_NAME
   printf(">df_read_pixels()\n");
#endif
   numrec = ceil( (float) bufp->N * bufp->size / DF_FITS_RECORD_LEN);
   pixels_per_record = DF_FITS_RECORD_LEN / bufp->size;
   pixels_left = bufp->N;
   dest  = bufp->fdata;
	for(loop=0; loop < numrec; loop++)
	{
		/*  Read Next Record */
		if( is_socket )
			bread = sock_read_data(fd, (char*)fits_buf, DF_FITS_RECORD_LEN, TRUE, 20);
		else
			bread = read(fd, (char*)fits_buf, DF_FITS_RECORD_LEN);
	
		if( DF_FITS_RECORD_LEN != bread )
			return ERR_FILE_READ;
	
		if( bufp->bitpix == DF_BITPIX_CHAR )
		{
			float pixel;
	      unsigned char  *src = (char *)fits_buf;

			/* copy to bufp->fdata */
			for( i=0; i < pixels_per_record && pixels_left; i++)
			{
				pixel = *src++;
				*dest++ = pixel;
				pixels_left--;
			}
		}
		else if( bufp->bitpix == DF_BITPIX_SHORT )
		{
			float pixel;
	      short  *src = (short *)fits_buf;

			/* copy to bufp->fdata */
			for( i=0; i < pixels_per_record && pixels_left; i++)
			{ 
				pixel = (short) ntohs(*src++);
				*dest++ = pixel;
				pixels_left--;
			}
		}
		else if( bufp->bitpix == DF_BITPIX_LONG )
		{
			float pixel;
	      long  *src = (long *)fits_buf;

			/* copy to bufp->fdata */
			for( i=0; i < pixels_per_record && pixels_left; i++)
			{
				pixel = (long) ntohl(*src++); 
				*dest++ = pixel;
				pixels_left--;
			}
		}
		else if( bufp->bitpix == DF_BITPIX_FLOAT )
		{
			union u_df_lf pixel;
	      unsigned long  *src = (unsigned long *)fits_buf;

			/* copy to bufp->fdata */
			for( i=0; i < pixels_per_record && pixels_left; i++)
			{
				pixel.l =  ntohl( *src++); 
				*dest++ = pixel.f;
				pixels_left--;
			}
		}
		else
         return ERR_INV_FORMAT;
	}

   /* Apply bzero / bscale to data */
	if( (bscale != 1.0) || (bzero != 0) )
	{
		/* printf("Applying bscale %f & bzero %f \n", bscale, bzero); */
		dest  = bufp->fdata;
		for( i=0; i < bufp->N; i++ )
		{
			*dest = (*dest * bscale) + bzero;
			dest++;
		}
	}

   /* fill in stats */
   df_stats( bufp );
	/***
	printf("   min=%f max=%f mean=%f stddev=%f\n",
		bufp->min, bufp->max, bufp->mean, bufp->stddev);
	***/

	return ERR_NONE;
}

/************************ eof ************************/
