
/**************************************************************************************
** Include file for fitslib
***************************************************************************************
*/

#ifndef __dflib_h
#define __dflib_h

/* FITS BITPIX values for data types */
#define DF_BITPIX_LONG         32
#define DF_BITPIX_SHORT        16
#define DF_BITPIX_FLOAT       -32
#define DF_BITPIX_DOUBLE       64
#define DF_BITPIX_CHAR          8

#define DF_FITS_RECORD_LEN   2880  /* Fits format has 2880 bytes per record  */
#define DF_FITS_LEN_FILENAME   20
#define DF_FITS_LEN_PATH       80
 
#define DF_MAX_SIGNED_LONG   ((long)0x7FFFFFFFL)
#define DF_MIN_SIGNED_LONG   ((long)0x80000001L)
 
#define DF_EMPTY      0          /* File or Buffer status                  */
#define DF_UNSAVED    1
#define DF_SAVED      2

#define DF_MATH_ADD   0          /* Operation code for df_math() function  */
#define DF_MATH_SUB   1
#define DF_MATH_MUL   2
#define DF_MATH_DIV   3
#define DF_MATH_COPY  4
#define DF_MATH_SQRT  5

#define DF_ROT_M90    0
#define DF_ROT_P90    1
#define DF_ROT_180    2

#define DF_ORIGIN_TL  0 /* (0,0) is at the top left */
#define DF_ORIGIN_BL  1 /* (0,0) is at the bottom left */

/*------------------------------------------------------------------
**  Structures for holding data and sending fits data
**------------------------------------------------------------------
*/
 
union u_df_lf               /* for long/float converstion with ntohl() */
{
   unsigned long l;
   float f;
};

struct df_fheader_t
{
   struct df_fheader_t * next;
   char               buf[DF_FITS_RECORD_LEN];
};

 
struct df_internal_vars
{
   int divbycoadd;   /* should the divisor be applied to the data? */
   int origin;       /* where is the origin */
};


struct df_buf_t
{
   short              status;        /* Buffer status: empty, unsaved,...  */
   short              naxis1;        /* Number of points in NAXIS1         */
   short              naxis2;        /* Number of points in NASIS2         */
   short              size;          /* sizeof data value in bytes         */
   short              bitpix;        /* BITPIX code                        */
   long               N;             /* Number of data points              */
   float              max;           /* max data value                     */
   float              min;           /* min data value                     */
   float              mean;          /* mean data value in frame           */
   float              stddev;        /* STD of data in frame               */
   float              arcsec_pixel;  /* Number of arcseconds per pixel     */
	float              pos_angle;     /* position angle of image            */
   float              divisor;       /* Used by divbycoadds.               */
   float              itime;         /* itime */
	float              filter_zp;     /* filter zero point - default = 0    */
	float              ext_coff;      /* extinction co-efficient. default=0 */
	float              airmass;       /* airmass. default=0                 */
   short              Nheader;       /* Number of lines in the fits hdr.   */

	short              org_size;      /* original sizeof(pixel_data) in bytes */
	short              org_bitpix;    /* original bitpix value */
	float              org_bscale;    /* original bscale */
	float              org_bzero;     /* original bzero */
	long               sizeof_header; /* sizeof header in the file. */
	long               nframes;       /* number of movie frames ie: naxis3 */

   char               directory[DF_FITS_LEN_PATH];
   char               filename[DF_FITS_LEN_FILENAME];
   struct df_fheader_t * fheader;      /* Pointer to header block.           */
   float *            fdata;        /* Pointer to block of data           */
};

/*------------------------------------------------------------------
**  Prototyping of functions.
**------------------------------------------------------------------
*/
int df_init( void );
int df_print_options( void );
int dfset_divbycoadd( int divbycoadd );
int dfget_divbycoadd( void );
int dfset_origin( int origin );
double dfdataxy( struct df_buf_t * bufp, int x, int y );
double dfdatainx( struct df_buf_t * bufp, int i );
double df_data_f( struct df_buf_t * bufp, int i );

int df_write_fits( int fd, char *path, char *filename, struct df_buf_t *bufp );

int df_read_fits( int fd, char *path, char *filename, struct df_buf_t *bufp, 
	int is_socket, int is_3d );

int df_search_fheader( struct df_fheader_t *hdr, char *keyword, char *val_str,
						  int val_str_size, struct df_fheader_t **Rhdr, int *offset, int debug);
int df_free_fbuffer( struct df_buf_t * bufp);

char * df_build_card( char *cptr, char *keyword, char *value, char *comment);
char * df_build_card2( char *cptr, char *keyword, char *value);
char * df_build_card3( char *cptr, char *keyword );

int df_buffer_math( struct df_buf_t * dest, struct df_buf_t * op1, 
						  struct df_buf_t * op2, int operation ); 
int df_constant_math( struct df_buf_t * dest, struct df_buf_t * op1, 
						  float op2, int operation ); 
int df_buffer_rotate( struct df_buf_t * dest, struct df_buf_t * op1, int operation);
int df_copy_subarray( struct df_buf_t * dest, struct df_buf_t * op1, 
							 int op_x, int op_y, int op_wid, int op_hgt);
int df_buffer_userfun( struct df_buf_t * dest, struct df_buf_t * op1,
	int (*userfun) ( struct df_buf_t *dest, struct df_buf_t *op1 ));
int df_math_copyheader( struct df_buf_t * dest, struct df_buf_t * src);
int df_math_fixheader( struct df_buf_t * bufp, char * history);

int df_stats( struct df_buf_t *bufp );
int df_stats_p1( struct df_buf_t *bufp );
int df_stats_p2( struct df_buf_t *bufp, double mean );

#endif /*  _dflib_h */
