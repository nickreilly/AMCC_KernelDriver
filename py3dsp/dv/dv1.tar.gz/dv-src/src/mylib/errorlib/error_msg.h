/**************************************************************************
**
**
***************************************************************************
*/

/*------------------------------------------------------------------
**  Error Message for commands
**------------------------------------------------------------------
*/

#define ERR_NONE            0    /* No error        */
#define ERR_INV_KW         -1    /* Invalid keywork */
#define ERR_INV_RNG        -2    /* Invalid Range   */
#define ERR_INV_FORMAT     -3    /* Invalid Format or syntax error */
#define ERR_SOCKET_ERR     -4    /* Socket communication error     */
#define ERR_SOCKET_TIMEOUT -5    /* Socket communication error     */
#define ERR_INV_PATH       -6    /* This is not a valid path       */
#define MEM_ALT_ERR        -7    /* Memory allocation error        */
#define ERR_FILE_CREATE    -8    /* Error Creating File            */
#define ERR_FILE_WRITE     -9    /* Error writing file             */
#define ERR_FILE_READ     -10    /* Error reading a file           */
#define ERR_FILE_FORMAT   -11    /* Invalid file format            */
#define ERR_NOT_READY     -12    /* Unable to execute, object is busy    */
#define ERR_BUF_EMPTY     -13    /* Unable to perform on an empty buffer */
#define ERR_BUF_DIFF_SIZE -14    /* Unable to perform on different size buffers */
#define ERR_INV_BUF       -15    /* Invalid buffer specified       */
#define ERR_INV_OPERATION -16    /* This is an invalid operation   */
#define ERR_UNKNOWN       -17    /* This shouldn't happen          */
#define ERR_RESTRICTED    -18    /* This option is currently restricted */
#define ERR_MSGQ          -19    /* System error on message queues */
#define ERR_STOP          -20    /* The GO was interrupted by a stop command */
#define ERR_GRATING_FAILURE  -21 /* Grating Task Failure         */
#define ERR_FILE_OPEN        -22 /* Error Opening File            */
#define ERR_LIMIT_FAIL       -23 /* Some limit switch is broken */
#define ERR_SEM_GET          -24 /* Semaphore acquisition error */
#define ERR_NOT_INITIALIZED  -25 /* Device was not properly initialized */
#define ERR_DEVICE_IO        -26 /* Error communication with device     */
#define ERR_INV_COMBINATION  -27 /* Error combination specified     */
#define ERR_TIMEOUT          -28 /* A Timeout error                 */
#define ERR_INVALID_DIR      -29 /* This director is invalid/inaccessible   */
#define ERR_CLOCK_DSP        -30 /* Clock DSP error */
#define ERR_BCARD_DSP        -31 /* Bcard DSP error */
#define ERR_NOT_IMPLEMENTED  -32 /* This option is not implement */
#define ERR_SUBARRAY_CNT     -33 /* Subarray count not valid  */
#define ERR_SUBARRAY_ROW     -34 /* Subarray row error       */
#define ERR_SUBARRAY_FORMAT  -35 /* Error in Format or placement of subarray */
#define ERR_SUBARRAY_TOOBIG  -36 /* Error in Format or placement of subarray */
#define ERR_ENCODER          -37 /* Encoder error       */
#define ERR_TCLAMP_ON        -38 /* Thermal clamp is locked */
#define ERR_NOT_AVAILABLE    -39 /* Reqested action or service is not available */
#define ERR_SHIFT_ARRAY      -40 /* Shift array is wrong */
#define ERR_LIMITATION       -41 /* Some sort of limit was exceeded */
#define ERR_HARDWARE         -42 /* Hardware didn't work as it should */
#define ERR_NO_DATA          -43 /* No data */
#define ERR_ABORT            -44 /* Last operation was aborted */
#define ERR_NA45             -45 /* undefined */
#define ERR_NA46             -46 /* undefined */
#define ERR_NA47             -47 /* undefined */
#define ERR_NA48             -48 /* undefined */
#define ERR_NA49             -49 /* undefined */
#define ERR_DSP_EXECUTE           -50
#define ERR_DSP_UNKNOWN           -51   /* Opps, don't know what happen. */
#define ERR_DSP_DEVICE_IO         -52   /* error communicating with device */
#define ERR_DSP_INV_INPUT         -53   /* Invalid input detected, ie out of range */
#define ERR_DSP_INV_FUN           -54   /* invalid function */
#define ERR_DSP_NOT_READY         -55   /* not ready to perform this function */
#define ERR_DSP_SHARC             -56   /* The board isn't working */
#define ERR_DSP_IXR_LOCK          -57   /* error related to locking the IXR */
#define ERR_DSP_FILE_READ         -58   /* Error reading input file for DSP function */
#define ERR_DSP_SUBARRAY_FORMAT   -59   /* invalid format for subarrays */
#define ERR_NA60             -60 /* undefined */

EXTERN char * Error_string[61]  /* Declare a string message for each */
#ifdef MAIN                   /* error.                            */
   = {
     "no error  ",
     "invalid keyword",
     "invalid range",
     "invalid format or sytax error",
     "socket communication error",
     "socket timeout error",
     "invalid path",
     "memory allocation error",
     "error on creating a file",
     "error while writing to a file",
     "error while reading a file",
     "invalid file format",
     "unable to execute, object is busy",
     "unable to perform on an empty buffer",
     "unable to perform on different size buffers",
     "an invalid buffer was specified",
     "this is an invalid operation",
     "Unknown error",
     "this option is currently restricted",
     "system error using message queues occured",
     "current go was terminated by the stop command",
     "The grating task has detected a hardware failure",
     "unable to open file",
     "error assoiciated with limit switch",
     "Semaphore acquisiton error",
     "Device was not properly initialized",
     "unable to communicate with device",
     "invalid combination specified",
     "timeout error",
     "directory is invalid/inaccessible",
     "An error with the clock DSP has occured",
     "An error with the BCard DSP has occured",
     "This option is not implemented ",
     "Number of subarray not valid",
     "Subarray row should not overlap",
     "Subarray format or placement error",
     "Subarray too big", 
     "Error with the encoder",
     "Thermal Clamp is locked",
     "Reqested action or service is not available",
     "Shift array must be <= 128x128 & enclosed by data array",
     "Execeeding some type of limitation was encountered",
     "Hardware didn't respond as expected",
     "There are no data",
     "The last operation was aborted",
     "NA",
     "NA",
     "NA",
     "NA",
     "NA",
	  /* 50 */
     "DSP still execute last command function",
     "DSP unknown error",
     "Error communication with DSP device/driver",
     "Invalid input for DSP function",
     "Invalid DSP function",
     "DSP not ready for perform this function",
     "The board isn't working",
     "DSP error related to locking the IXR",
     "Error reading an input file for this DSP function",
     "Invalid format for the sub arrays",
	  /* 60 */
     "NA",
      }
#endif
   ;
 
