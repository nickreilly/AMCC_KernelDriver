
/**************************************************************************************
** Include file for fitslib
***************************************************************************************
*/

#ifndef __fitslib_h
#define __fitslib_h

#define FITS_RECORD_LEN   2880  /* Fits format has 2880 bytes per record  */
#define FITS_LEN_FILENAME   20
#define FITS_LEN_PATH       80
 
#define MAX_SIGNED_LONG   ((long)0x7FFFFFFFL)
#define MIN_SIGNED_LONG   ((long)0x80000001L)
 
#define FITS_EMPTY      0          /* File or Buffer status                  */
#define FITS_UNSAVED    1
#define FITS_SAVED      2

/*------------------------------------------------------------------
**  Structures for holding data and sending fits data
**------------------------------------------------------------------
*/
 
struct fheader_t
{
   struct fheader_t * next;
   char               buf[FITS_RECORD_LEN];
};
 
struct FBUFFER
{
   short              status;       /* Buffer status: empty, unsaved,...  */
   short              naxis1;       /* Number of points in NAXIS1         */
   short              naxis2;       /* Number of points in NASIS2         */
   short              size;         /* sizeof data value in bytes         */
   long               N;            /* Number of data points              */
   long               max;          /* max data value                     */
   long               min;          /* min data value                     */
   long               mean;         /* mean data value in frame           */
	float              stddev;       /* STD of data in frame               */
	float              arcsec_pixel; /* Number of arcseconds per pixel     */
	float              itime;        /* itime */
	float              filter_zp;    /* filter zero point - default = 0    */
	float              ext_coff;     /* extinction co-efficient. default=0 */
	float              airmass;      /* airmass. default=0                 */
   short              divisor;      /* Used by divbycoadds.               */
   short              Nheader;      /* Number of lines in the fits hdr.   */
   char               directory[FITS_LEN_PATH];
   char               filename[FITS_LEN_FILENAME];
   struct fheader_t * fheader;      /* Pointer to header block.           */
   long *             fdata;        /* Pointer to block of data           */
};

#if ANSI
   int disk_write_fits( int fd, char *path, char *filename, struct FBUFFER *bufp);
   int disk_read_fits( int fd, char *path, char *filename, struct FBUFFER *bufp, 
	   int is_socket, int sock_timeout_cnt);
   int search_fheader( struct fheader_t *hdr, char *keyword, char *val_str,
                       int val_str_size, struct fheader_t **Rhdr, int *offset);
   int free_fbuffer( struct FBUFFER * bufp);

	int disk_read_mem( int fd, char *path, char *filename, struct FBUFFER *bufp );
	int cbol( unsigned char *c );
	int cbos( unsigned char *c );

	char * build_card( char *cptr, char *keyword, char *value, char *comment);
	char * build_card2( char *cptr, char *keyword, char *value);
#else
   int disk_write_fits( );
   int disk_read_fits( );
   int search_fheader( );
   int free_fbuffer( );

	int disk_read_mem();
	int cbol();
	int cbos();
	char * build_card();
	char * build_card2();
#endif

#endif /*  __fitslib_h */
