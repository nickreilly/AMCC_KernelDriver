
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <math.h>

#if SUNOS | LINUX
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif 

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "addlib.h"
#include "error_msg.h"

#include "fitslib.h"

/*---------------------------------------------------------------------------
**  disk_read_fits() - reads a fits file into the struct FBUFFER.
**         fd     - File description number.
**       bufp     - Pointer to FBUFFER structure.
**  Returns     ERR_NONE  File read OK.
**         ERR_FILE_READ  Error reading file.
**---------------------------------------------------------------------------
*/

int disk_read_fits
(
   int  fd,                    /* file description to read.                   */
   char * path,                /* path & filename need for header inforamtion */
   char * filename,
   struct FBUFFER * bufp,       /* Buffer struct to hold the data. */
   int  is_socket,             /* TRUE if it's a socket, otherwise false */
	int  sock_timeout_cnt       /* parameter for sock_read ... */
)
{
   int loop,
       numrec,
       pixels_per_record,
       pixels_left,
       error,
       bread,
       i;
   short s;
   short * iptr;
   long lpar;
   register long *lptr;
	long * l_ptr;
   float fpar;
	double sum, sdd, mean, n, bscale, bzero;
   char *fits_buf,
        *next_fdata;
   unsigned char *ucptr;
   char buf[85];

   struct fheader_t * last_hdr;
   struct fheader_t * f_hdr;

#if FUN_NAME
   printf(">disk_read_fits()\n");
#endif
   /*
   **  Allocate buffer
   */
   if( NULL == ( fits_buf = (char *) malloc( (u_int)FITS_RECORD_LEN)) )
      return(MEM_ALT_ERR);
   /*
   **  Construct filename, check if over writting old data, open file.
   */

   if( bufp->status != FITS_EMPTY ) free_fbuffer( bufp ); /* Clear the Buffer structure */
   strxcpy( bufp->directory, path, sizeof(bufp->directory));
   strxcpy( bufp->filename,  filename, sizeof(bufp->filename));
   error = ERR_NONE;
   /*
   **  Read first header block and search for required keyword & values.
   */
   if( NULL == ( bufp->fheader = (struct fheader_t*)
                                 malloc(  (u_int)  sizeof(struct fheader_t) )) )
   {
      error = MEM_ALT_ERR; goto Lerror;
   }
   bufp->fheader->next = NULL;
   
   /* Read 1st header block */
   if( is_socket )
      bread = sock_read_data( fd, (char*) bufp->fheader->buf, FITS_RECORD_LEN, 
										TRUE, sock_timeout_cnt);
   else
      bread = read( fd, (char*)bufp->fheader->buf, FITS_RECORD_LEN);
   if( FITS_RECORD_LEN != bread )
   {
      error = ERR_FILE_READ;
      goto Lerror;
   }

   /* SIMPLE  */
   if( search_fheader( bufp->fheader, "SIMPLE", buf, sizeof(buf), &f_hdr, &i) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( buf[0] != 'T' )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   /* NAXIS   */
   if( search_fheader( bufp->fheader, "NAXIS", buf, sizeof(buf), &f_hdr, &i) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(2, lpar, 3) )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   /* NAXIS1  */
   if( search_fheader( bufp->fheader, "NAXIS1", buf, sizeof(buf), &f_hdr, &i) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(1, lpar, 2048))
      { error = ERR_FILE_FORMAT; goto Lerror; }
   bufp->naxis1 = (short) lpar;

   /* NAXIS2  */
   if( search_fheader( bufp->fheader, "NAXIS2", buf, sizeof(buf), &f_hdr, &i) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(1, lpar, 2048))
      { error = ERR_FILE_FORMAT; goto Lerror; }
   bufp->naxis2 = (short) lpar;

   /* NAXIS3  ( optional, but must be equal to 1) */
   if( search_fheader( bufp->fheader, "NAXIS3", buf, sizeof(buf), &f_hdr, &i) >= 0 )
      if( -1 == my_atol( buf, &lpar) || lpar != 1 )
         { error = ERR_FILE_FORMAT; goto Lerror; }

   /* BITPIX  */
   if( search_fheader( bufp->fheader, "BITPIX", buf, sizeof(buf), &f_hdr, &i) < 0 )
      { error = ERR_FILE_FORMAT; goto Lerror; }

   if( -1 == my_atol( buf, &lpar) || !INRANGE(8, lpar, 32))
      { error = ERR_FILE_FORMAT; goto Lerror; }
   bufp->size = (short) (lpar/8);
   bufp->N    = bufp->naxis1 * bufp->naxis2;

   /* DIVISOR */
   bufp->divisor = (short) 1;
   if( search_fheader( bufp->fheader, "DIVISOR", buf, sizeof(buf), &f_hdr, &i) >= 0  )
      if( 0 == my_atol( buf, &lpar) && INRANGE(1, lpar, 32767))
         bufp->divisor = (short) lpar;

   /* ASEC_PIX  or PLATE_SC */
   bufp->arcsec_pixel = 0;
   if( search_fheader( bufp->fheader, "PLATE_SC", buf, sizeof(buf), &f_hdr, &i) >= 0 )
   {
      fpar = atof( buf );
      if( INRANGE(0.0, fpar, 10.0))
         bufp->arcsec_pixel = fpar;
   }
   if( search_fheader( bufp->fheader, "ASEC_PIX", buf, sizeof(buf), &f_hdr, &i) >= 0 )
   {
      fpar = atof( buf );
      if( INRANGE(0.0, fpar, 10.0))
         bufp->arcsec_pixel = fpar;
   }
   if( search_fheader( bufp->fheader, "BSCALE", buf, sizeof(buf), &f_hdr, &i) >= 0 )
   {
      bscale = atof( buf );
   }
	else
		bscale = 1;
   if( search_fheader( bufp->fheader, "BZERO", buf, sizeof(buf), &f_hdr, &i) >= 0 )
   {
      bzero = atof( buf );
   }
	else
		bzero = 0;

   /* END     */
   if( (i=search_fheader( bufp->fheader, "END", buf, sizeof(buf), &f_hdr, &i)) >= 0 )
      loop = FALSE; else loop = TRUE;
   bufp->Nheader = i+1;

   /*
   **  Now read in the rest of the headers blocks.
   */
   last_hdr = bufp->fheader;
   while( loop )
   {
      if( NULL == (last_hdr->next = (struct fheader_t*)
                                    malloc( (u_int) sizeof(struct fheader_t) )) )
      {
         error = MEM_ALT_ERR;
         goto Lerror;
      }
      last_hdr = last_hdr->next;
      last_hdr->next = NULL;

      if( is_socket )
         bread = sock_read_data(fd, (char*)last_hdr->buf, FITS_RECORD_LEN, 
										  TRUE, sock_timeout_cnt);
      else
         bread = read(fd, (char*)last_hdr->buf, FITS_RECORD_LEN);
      if( FITS_RECORD_LEN != bread )
      {
         error = ERR_FILE_READ;
         goto Lerror;
      }
      if( 0 <= (bufp->Nheader=search_fheader( bufp->fheader, "END", buf, sizeof(buf), 
			&f_hdr, &i) ))
         loop = FALSE; else loop = TRUE;
   }
   /*
   **  Read in the data.
	**  Note: The data is converted to 32 bits.
   */
   if( NULL == ( bufp->fdata = (long*) malloc( (u_int)bufp->N*sizeof(long) ) ) )
      { error = MEM_ALT_ERR; goto Lerror; }

   bufp->min = MAX_SIGNED_LONG;
   bufp->max = MIN_SIGNED_LONG;

   numrec = ceil( (double) bufp->N * bufp->size / FITS_RECORD_LEN);
   pixels_per_record = FITS_RECORD_LEN / bufp->size;
   pixels_left = bufp->N;
   next_fdata  = (char *)bufp->fdata;
   for(loop=0; loop < numrec; loop++)
   {
      /*  Read Next Record */
      if( is_socket )
         bread = sock_read_data(fd, (char*)fits_buf, FITS_RECORD_LEN, TRUE,
											sock_timeout_cnt);
      else
         bread = read(fd, (char*)fits_buf, FITS_RECORD_LEN);

      if( FITS_RECORD_LEN != bread )
         { error = ERR_FILE_READ; goto Lerror; }

      /* copy to bufp->fdata */
      if( bufp->size == 4 )           /* Copy longs to buffer  */
      {
         l_ptr = (long *)fits_buf;
         lptr = (long  *)next_fdata;
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
             *lptr++ = (long) ntohl(*l_ptr++);
             pixels_left--;
         }
         next_fdata += FITS_RECORD_LEN;
      }
      if( bufp->size == 2 )           /* Copy shorts to buffer */
      {
         iptr = (short *)fits_buf;
         lptr = (long  *)next_fdata;
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
				 s = ntohs(*iptr++);
             *lptr++ = s;
             pixels_left--;
         }
         next_fdata += FITS_RECORD_LEN * 2;
      }
      else if( bufp->size == 1 )       /* Copy char to buffer */
      {
         ucptr = (unsigned char *)fits_buf;
         lptr = (long *)next_fdata;
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
             *lptr++ = (long) *ucptr++;
             pixels_left--;
         }
         next_fdata += FITS_RECORD_LEN * 4;
      }
   }
	/*
	** Now adjust header information to show it is converted to 32 bits.
	*/
	bufp->size = sizeof(long);
   search_fheader( bufp->fheader, "BITPIX", buf, sizeof(buf), &f_hdr, &i);
   build_card( f_hdr->buf+(i*80), "BITPIX", "32", "32 BITS TWO COMPLEMENT INTS");
   /*
   **  determine min, max, and mean.
   */
   lptr = &bufp->fdata[0];
	sum = sdd = 0;
   for( i=0; i < bufp->N; i++)
   {
      if( bufp->max < *lptr ) bufp->max = *lptr;
      if( bufp->min > *lptr ) bufp->min = *lptr;
		fpar = (*lptr);
		sum += fpar;
		sdd += (fpar*fpar);
      lptr++;
   }
	if( bufp->N > 1 )
	{
		n = bufp->N;
		mean = (sum / n);
		bufp->mean = mean + 0.5;
		sdd -= (mean*mean*n);
		bufp->stddev = sqrt(sdd/(n-1));
	}
	else
	{
		bufp->mean = 0;
		bufp->stddev = 0;
	}
   /*
   ** search for additional fits header information: filter_zp, ext_coff, airmass;
   */
   bufp->itime = 1;
   bufp->filter_zp = 0;
   bufp->ext_coff = 0;
   bufp->airmass = 1;

   if( search_fheader( bufp->fheader, "ITIME", buf, sizeof(buf), &f_hdr, &i) >= 0)
      bufp->itime = atof( buf );
   if( search_fheader( bufp->fheader, "FLTZP", buf, sizeof(buf), &f_hdr, &i) >= 0 )
      bufp->filter_zp = atof( buf );
   if( search_fheader( bufp->fheader, "EXT_COF", buf, sizeof(buf), &f_hdr, &i) >= 0 )
      bufp->ext_coff = atof( buf );
   if( search_fheader( bufp->fheader, "AIRMASS", buf, sizeof(buf), &f_hdr, &i) >= 0 )
      bufp->airmass = atof( buf );

   /*
   **  no error.
   */
   bufp->status = FITS_SAVED;
   free(fits_buf);
   return error;


Lerror:                               /* on error close, free, and return */
   /*
   **  error handler.
   */
   free(fits_buf);
   free_fbuffer( bufp );
   return error;
}

/************************ eof ************************/
