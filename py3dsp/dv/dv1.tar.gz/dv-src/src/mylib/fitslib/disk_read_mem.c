
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <math.h>

#if SUNOS | LINUX
#include <sys/param.h>
#include <malloc.h>
#include <memory.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "fitslib.h"
#include "addlib.h"
#include "error_msg.h"

/*---------------------------------------------------------------------------
**  disk_read_mem() - reads a protocam style mem file into the BUFFER.
**         fd     - File description number.
**       bufp     - Pointer to BUFFER structure.
**  Returns     ERR_NONE  File read OK.
**         ERR_FILE_READ  Error reading file.
**---------------------------------------------------------------------------
*/
int disk_read_mem
(
   int  fd,                    /* file description to read.                   */
   char * path,                /* path & filename need for header inforamtion */
   char * filename,
   struct FBUFFER * bufp        /* Buffer struct to hold the data. */
)
{

   char  vbuf[70];
   int   i,
         error;
   long  l;
   double sum, sdd, mean, n;

   unsigned char polarimetry, filter_type,
                 time_hsec, time_sec, time_min, time_hour,
                 date_day, date_mon, date_year,
                 ra_hh, ra_mm, ra_s1, ra_s2,
                 dec_hh, dec_mm, dec_s1, dec_s2;
   short coadd,
         obscyc;
   long  mindata, maxdata;
   float itime,
         wavelength,
         platescale,
         airmass, epoch,
         vgate;
   char  object[30],
         comment[60];
   char * cptr;
   long * lptr;
   float * fptr;

#define ARRAY_SIZE 3596   /* size of protocam's sbrc array */

#if FUN_NAME
   printf(">disk_read_mem()\n");
#endif
   /*
   **  Initialize  
   */
   if( bufp->status != FITS_EMPTY ) free_fbuffer( bufp ); /* Clear the Buffer structure */
   strxcpy( bufp->directory, path, sizeof(bufp->directory));
   strxcpy( bufp->filename,  filename, sizeof(bufp->filename));
   error = ERR_NONE;
   /*
   **  Allocate memory for header.
   */
   if( NULL == ( bufp->fheader = (struct fheader_t*)
                                 malloc(  (u_int)  sizeof(struct fheader_t) )) )
       { error = MEM_ALT_ERR; goto Lerror; }
   bufp->fheader->next = NULL;
	/*
	**  read in data
	*/
   /* status, directory & filename */
   if( read( fd, vbuf, 54) == -1)
      { error = ERR_FILE_READ; goto Lerror; }

   /* max data */
   if( read( fd, &maxdata, sizeof(maxdata)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&maxdata);

   /* min data */
   if( read( fd, &mindata, sizeof(mindata)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&mindata);

   /* itime */
   if( read( fd, &itime, sizeof(itime)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&itime);

   /* coadd */
   if( read( fd, &coadd, sizeof(coadd)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbos((unsigned char *)&coadd);

   /* obscyc */
   if( read( fd, &obscyc, sizeof(obscyc)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbos((unsigned char *)&obscyc);

   /* polarimetry */
   if( read( fd, &polarimetry, sizeof(polarimetry)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* filter_type */
   if( read( fd, &filter_type, sizeof(filter_type)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* wavelength */
   if( read( fd, &wavelength, sizeof(wavelength)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&wavelength);

   /* platescale */
   if( read( fd, &platescale, sizeof(platescale)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&platescale);

   /* time */
   if( read( fd, &time_hsec, sizeof(time_hsec)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &time_sec, sizeof(time_sec)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &time_min, sizeof(time_min)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &time_hour, sizeof(time_hour)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* date */
   if( read( fd, &date_day, sizeof(date_day)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &date_mon, sizeof(date_mon)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &date_year, sizeof(date_year)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }


   /* ra */
   if( read( fd, &ra_hh, sizeof(ra_hh)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &ra_mm, sizeof(ra_mm)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &ra_s1, sizeof(ra_s1)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &ra_s2, sizeof(ra_s2)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* dec */
   if( read( fd, &dec_hh, sizeof(dec_hh)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &dec_mm, sizeof(dec_mm)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &dec_s1, sizeof(dec_s1)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   if( read( fd, &dec_s2, sizeof(dec_s2)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* 1 bytes padding */
   if( read( fd, &l, 1) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* airmass */
   if( read( fd, &airmass, sizeof(airmass)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&airmass);

   /* epoch */
   if( read( fd, &epoch, sizeof(epoch)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&epoch);

   /* vgate */
   if( read( fd, &vgate, sizeof(vgate)) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   cbol((unsigned char *)&vgate);

   /* object */
   memset( comment, 0, 30);
   if( read( fd, object, 25) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* comment */
   memset( comment, 0, 55);
   if( read( fd, comment, 50) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }

   /* 1 bytes padding */
   if( read( fd, &l, 1) == -1 )
      { error = ERR_FILE_READ; goto Lerror; }
   /*
   **  Allocate memory and read in data.
   */
   if( NULL == ( bufp->fdata = (long*) malloc( (u_int)(ARRAY_SIZE*sizeof(long)) ) ) )
      { error = MEM_ALT_ERR; goto Lerror; }

     /* read array data */
   l = sizeof(long)*ARRAY_SIZE;
   if( read( fd, bufp->fdata, l) != l)
      { error = ERR_FILE_READ; goto Lerror; }

   /*
   **  Update Buffer header
   */
   bufp->naxis1 = 62;
   bufp->naxis2 = 58;
   bufp->size = (short) sizeof(long);
   bufp->N    =  ARRAY_SIZE;
   bufp->arcsec_pixel = platescale;
	bufp->divisor = (short) coadd*obscyc;
   bufp->Nheader = 30;
   /*
   **  Make fits header strings
   */
   cptr = (char*)bufp->fheader->buf;
   cptr = build_card( cptr, "SIMPLE", "T", "DATA IS IN FITS FORMAT");
   cptr = build_card( cptr, "BITPIX", "32", "32 BITS TWOS COMPLEMENT INTEGERS");
   cptr = build_card( cptr, "NAXIS", "2", "NUMBER OF AXIS");
   cptr = build_card( cptr, "NAXIS1", "62", "PIXELS ON 1st MOST VARYING AXIS");
   cptr = build_card( cptr, "NAXIS2", "58", "PIXELS ON 2nd MOST VARYING AXIS");
   cptr = build_card( cptr, "ORIGIN", "''", "INSTITUTION WRITING THE DATA");
   cptr = build_card( cptr, "TELESCOP", "''", "DATA ACQUISITION TELESCOPE");
   cptr = build_card( cptr, "INSTRUME", "''", "DATA ACQUISITION INSTRUMENT");
   cptr = build_card( cptr, "OBSERVER", "''", "OBSERVER NAME/IDENTIFICATION");

   sprintf(vbuf, "%6.3f", itime);
   cptr = build_card( cptr, "ITIME", vbuf, "INTEGRATION TIME IN SECONDS");

   sprintf(vbuf, "'%02d/%02d/%02d'", date_day, date_mon, date_year);
   cptr = build_card( cptr, "DATE_OBS", vbuf, "DATE OF ACQUISITON HST ('dd/mm/yy')");

   sprintf(vbuf, "'%02d:%02d:%02d.%02d'", time_hour, time_min, time_sec,
                 time_hsec);
   cptr = build_card( cptr, "TIME_OBS", vbuf, "DATE OF ACQUISITON HST ('dd/mm/yy')");

   sprintf(vbuf, "%d", coadd);
   cptr = build_card( cptr, "CO_ADDS", vbuf, "NUMBER OF INTEGRATIONS");

   sprintf(vbuf, "%d", obscyc);
   cptr = build_card( cptr, "OBS_CYC", vbuf, "NUMBER OF OBSERVING CYCLES");

   sprintf(vbuf, "%d", polarimetry);
   cptr = build_card( cptr, "POLAR", vbuf, "0=OPEN 1=POLARIMETRY");
   sprintf(vbuf, "%d", filter_type);
   cptr = build_card( cptr, "FILTER", vbuf, "0=BROADBAND 1=CVF");

   sprintf(vbuf, "%5.3f", wavelength);
   cptr = build_card( cptr, "WAVE_LEN", vbuf, "WAVELENGTH IN MICRONS");

   sprintf(vbuf, "%5.3f", platescale);
   cptr = build_card( cptr, "PLATE_SC", vbuf, "PLATESCALE");

   sprintf(vbuf, "'%02d:%02d:%02d.%02d'", ra_hh, ra_mm, ra_s1, ra_s2);
   cptr = build_card( cptr, "RA", vbuf, "RIGHT ASCENSION in degree");

   sprintf(vbuf, "'%02d:%02d:%02d.%d'", dec_hh, dec_mm, dec_s1, dec_s2);
   cptr = build_card( cptr, "DEC", vbuf, "DECLINATION in degree");

   sprintf(vbuf, "%3.1f", epoch);
   cptr = build_card( cptr, "EPOCH", vbuf, "EPOCH");

   sprintf(vbuf, "%5.3f", airmass);
   cptr = build_card( cptr, "AIRMASS", vbuf, "AIRMASS");

   sprintf(vbuf, "'%s'", object);
   cptr = build_card2( cptr, "OBJECT", vbuf);

   sprintf(vbuf, "'%s'", comment);
   cptr = build_card2( cptr, "COMMENT", vbuf);

   sprintf(vbuf, "%ld", maxdata);
   cptr = build_card( cptr, "DATAMAX", vbuf, "MAX DATA VALUE IN FILE");

   sprintf(vbuf, "%ld", mindata);
   cptr = build_card( cptr, "DATAMIN", vbuf, "MIN DATA VALUE IN FILE");

   sprintf(vbuf, "%5.2f", vgate);
   cptr = build_card( cptr, "VGATE", vbuf, "SBRC ARRAY GATE VOLTAGE");

   sprintf(vbuf, "%d", coadd*obscyc);
   cptr = build_card( cptr, "DIVISOR", vbuf, "Total Number of Coadds");

   sprintf(vbuf, "%5.3f", platescale);
   cptr = build_card( cptr, "ASEC_PIX", vbuf, "NUM OF ARCSEC PER PIXEL");

   cptr = build_card( cptr, "END", " ", "That's all folks");
	
   /*
   **  Convert data from intel-float to sun-longs
   */
   maxdata = MIN_SIGNED_LONG;
   mindata = MAX_SIGNED_LONG;
   sdd = sum = 0;

   lptr = (long*)bufp->fdata;
   fptr = (float*)bufp->fdata;
   for( i=0; i < bufp->N; i++)
	{
      cbol((unsigned char *)fptr);  /* convert byte order */
      l = *fptr;          /* convert floating point format to long integer */
      *lptr = l;

      maxdata = MAX(l, maxdata);
      mindata = MIN(l, mindata);
      sum += *fptr;
      sdd += ((*fptr)*(*fptr));

      lptr++;
      fptr++;
	}
   bufp->min = mindata;
   bufp->max = maxdata;
	n = bufp->N;
	mean = sum/n;
	sdd -= (mean*mean*n);
   bufp->mean = mean;
   bufp->stddev = sqrt(sdd/(n-1));

   /*
   **  no error.
   */
   bufp->status = FITS_UNSAVED;
   return error;
   /*
   **  error handler.
   */
Lerror:                               /* on error close, free, and return */
   free_fbuffer( bufp );
   return error;
}

/************************ eof ************************/
