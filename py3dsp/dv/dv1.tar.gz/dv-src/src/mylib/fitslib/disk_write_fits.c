
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <math.h>
#include <netinet/in.h>

#if SUNOS | LINUX
#include <sys/param.h>
#include <memory.h>
#include <malloc.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "fitslib.h"
#include "addlib.h"
#include "error_msg.h"

/*---------------------------------------------------------------------------
**  disk_write_fits() - Outputs a Buffer in the FITS format.
**       fd       - Write fits to this file descriptor.
**       path     - Update the Buffer structure with path & filename.
**       filename -
**       bufp     - Pointer to Buffer.
**  Returns     ERR_NONE  file created OK.
**       ERR_FILE_CREATE  Error creating file.
**        ERR_FILE_WRITE  Error writing file.
**---------------------------------------------------------------------------
*/

int disk_write_fits( int fd, char * path, char * filename, struct FBUFFER * bufp)
{
   int error,
       loop,
       numrec,
       items_per_record,
       inx,
       i;
   short  * iptr;
	long   * lptr;
   char * fits_buf,
        * cptr;
   struct fheader_t * fheader;

#if FUN_NAME
   printf(">disk_write_fits()\n");
#endif
   /*
   **  Allocate buffer
   */
   if( NULL == ( fits_buf = (char *) calloc( FITS_RECORD_LEN, sizeof(char))) )
      return(MEM_ALT_ERR);
   /*
   **  Construct filename, open file.
   */
   error = ERR_NONE;
   strxcpy( bufp->directory, path,     sizeof(bufp->directory));
   strxcpy( bufp->filename,  filename, sizeof(bufp->filename));
   /*
   **  Output the header
   */
   fheader = bufp->fheader;
   while( fheader != NULL )
   {
      if( FITS_RECORD_LEN != write( fd, fheader->buf, FITS_RECORD_LEN))
      {
         error = ERR_FILE_WRITE; goto Lerror;
      }

      fheader = fheader->next;
   }
   /*
   **  Output data...
   */
	numrec = ceil( (double) bufp->N * bufp->size / FITS_RECORD_LEN);
	items_per_record = FITS_RECORD_LEN / bufp->size;
	inx = 0;
	for(loop=0; loop < numrec; loop++)
	{
		cptr = (char*) fits_buf;
		iptr = (short * ) fits_buf;
		lptr = (long  * ) fits_buf;
		memset( fits_buf, 0x00, FITS_RECORD_LEN);
		for( i=0; i< items_per_record && inx < bufp->N; i++)
		{
			if( bufp->size == 1)
				*cptr++ = (char) bufp->fdata[inx];
			else if( bufp->size == 2 )
				*iptr++ = htons((short) bufp->fdata[inx]);
			else 
				*lptr++ = htonl( bufp->fdata[inx]);
			inx++;
		}

		if( FITS_RECORD_LEN != write( fd, (char *)fits_buf, FITS_RECORD_LEN))
		{ error = ERR_FILE_READ; goto Lerror; }
	}
   /*
   **  If everything went OK, set status to saved.
   */
   bufp->status = FITS_SAVED;
Lerror:                               /* on error close and return */
   free( fits_buf );
   return error;
}

/************************ eof ************************/

