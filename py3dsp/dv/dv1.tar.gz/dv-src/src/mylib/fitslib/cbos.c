

#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "fitslib.h"

/*------------------------------------------------------------
** cbos() - changes the byte order of a short from intel to sun
**------------------------------------------------------------
*/
int cbos( unsigned char *c )
{
   unsigned char t;
   t = *c;
   *c = *(c+1);
   *(c+1) = t;
   return 0;
}

/************************ eof ************************/
