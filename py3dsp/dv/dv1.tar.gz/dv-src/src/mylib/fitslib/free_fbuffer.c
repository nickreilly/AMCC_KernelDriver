
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#if SUNOS | LINUX
#include <malloc.h>
#include <memory.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "fitslib.h"
#include "error_msg.h"


/*--------------------------------------------------------------------------
 *  free_fbuffer() - deallocated memory associated with buffer and sets
 *                  status to FITS_EMPTY.
 *--------------------------------------------------------------------------
 */
int free_fbuffer( struct FBUFFER *bufp )
{
   struct fheader_t * nxt_hdr,
                     * tmp_hdr;

#if FUN_NAME
   printf(">free_buffer()\n");
#endif
   nxt_hdr = bufp->fheader;
   while( nxt_hdr )
   {
      tmp_hdr = nxt_hdr;          /* tmp = hdr to be freed  */
      nxt_hdr = nxt_hdr->next;    /* save reference to next */
      free( (char*)tmp_hdr );     /* de-allocate it         */
   }

   if( bufp->fdata )              /* de-allocate data blocks */
      free( (char*) bufp->fdata );

   bufp->status = FITS_EMPTY;     /* Update status           */
   bufp->fheader = NULL;          /* and the pointer         */
   bufp->fdata   = NULL;

   return ERR_NONE;
}

/************************ eof ************************/
