

#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "fitslib.h"

/*------------------------------------------------------------
** cbol() - changes the byte order of a long from intel to sun
**------------------------------------------------------------
*/
int cbol( unsigned char * c )
{
   unsigned char t[4];
   t[3] = *c;
   t[2] = *(c+1);
   t[1] = *(c+2);
   t[0] = *(c+3);
   memcpy( (char*)c, (char*)t, sizeof(long));
   return 0;
}

/************************ eof ************************/
