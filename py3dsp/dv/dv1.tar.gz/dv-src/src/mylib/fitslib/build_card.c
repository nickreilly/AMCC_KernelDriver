
#define EXTERN

/*-------------------------
**  Standard include files
**-------------------------
*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#if SUNOS | LINUX
#include <memory.h>
#endif

#if LYNX
#include <oscalls.h>
#endif

/*------------------------------
**  Non-standard include files
**------------------------------
*/

#include "fitslib.h"

/*--------------------------------------------------------------------
**  build_card with 20 character value with comment.
**  Writes card to file fp and updates remaining_cards.
**--------------------------------------------------------------------
*/
char * build_card( char *cptr, char *keyword, char *value, char *comment)
{
   char outbuf[85];
   int l;
   if( strlen(value) > 18 )
      sprintf(outbuf, "%-8.8s= %30.30s / %-s ", keyword, value, comment);
   else
      sprintf(outbuf, "%-8.8s= %20.20s / %-s ", keyword, value, comment);
   l = strlen(outbuf);
   if( l < 80 )
      memset( &outbuf[l], ' ', 80-l);
   outbuf[80] = '\0';

   strncpy( cptr, outbuf, 80);
   return ( cptr + 80 );
}

/*--------------------------------------------------------------------
**  build_card frame with 50 character value, no comment.
**  Writes card to file fp and updates remaining_cards.
**--------------------------------------------------------------------
*/
char * build_card2( char *cptr, char *keyword, char *value)
{
   char outbuf[85];
   int l;
   sprintf(outbuf, "%-8.8s= %-60.60s ", keyword, value);
   l = strlen(outbuf);
   if( l < 80 )
      memset( &outbuf[l], ' ', 80-l);
   outbuf[80] = '\0';

   strncpy( cptr, outbuf, 80);
   return( cptr + 80 );
}

/************************ eof ************************/
