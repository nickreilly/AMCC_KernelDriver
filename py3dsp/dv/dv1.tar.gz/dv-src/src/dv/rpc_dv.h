
#define ERROR                   0               /* Added for RPC functions. RES 4/5/01 */
#define NOERROR                 1
#define MAXSTRLEN               80
#define DVRPCPROG               0x20000089      /* RPC program number for DV */
#define DVRPCVERS               1               /* RPC version number for DV */
#define DV_COMMAND 1

/* Define it only for Solaris.... */
//typedef unsigned char uint8_t;
//typedef unsigned short uint16_t;
//typedef unsigned int uint32_t;

#include <rpc/rpc.h>
#include <rpc/pmap_clnt.h>


/* Added for RPC functions in DV, Richard Emile Sarkis 4/5/01 */
int * dv_command_1(char **, CLIENT *);
int * dv_command_1_svc(char **, struct svc_req *);
int dvrpcprog_1_freeresult (SVCXPRT *, xdrproc_t, caddr_t);
void dvrpcprog_1(struct svc_req *rqstp, register SVCXPRT *transp);
/* End */


