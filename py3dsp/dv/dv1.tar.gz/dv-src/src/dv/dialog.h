/********************************************************************************/
/*  DIALOG.H - header file for dv dialogs                                       */
/********************************************************************************/


/*******************************************************************
** Browse for Path structures and prototypes
********************************************************************
*/

/*--------------------------
** bfp struct
**--------------------------
*/

struct browseForPath_t
{
   GtkWidget * dialog_window;   /* reference to dialog window */
   GtkWidget * path_option_w;   /* option widget shows path & parents */
   GtkWidget * clist;           /* clist widget showing name of child directories */
   GtkWidget * entry;           /* Shows which directory is selected */
   GtkWidget * ok_button;       /* The ok button */

   struct dirlist_t dirlist;    /* direct string & list of parents */
};

/*--------------------------
** bfp prototypes
**--------------------------
*/
int bfp_create_dialog ( struct browseForPath_t *bfp, char * title );
void bfp_hide_dialog ( struct browseForPath_t *bfp );
void bfp_show_dialog ( struct browseForPath_t *bfp );
void bfp_set_path( struct browseForPath_t *bfp, char * path );
void bfp_set_ok_cb( struct browseForPath_t *bfp, GtkSignalFunc func );

/*******************************************************************
** File Access Dialog structures and prototypes
********************************************************************
*/

/*--------------------------
** fad struct
**--------------------------
*/

struct fileAccessDialog_t
{
   GtkWidget * dialog_window;   /* reference to dialog window */
   GtkWidget * table;           /* container widget for window */
   GtkWidget * path_option_w;   /* option widget shows path & parents */
   GtkWidget * mask_entry;      /* filter for file clist */
   GtkWidget * dir_clist;       /* clist widget showing name of child directories */
   GtkWidget * file_clist;      /* clist widget showing name of files */
   GtkWidget * path_entry;      /* Shows which directory is selected */
   GtkWidget * file_entry;      /* Shows which file is selected */
   GtkWidget * buffer_option_w; /* option widget shows buffer selection */
   GtkWidget * ok_button;       /* The ok button */
   GtkSignalFunc func;          /* user-defined buffer callback. */

   struct dirlist_t dirlist;    /* directory string & list of parents */
   char   filename[60];         /* name of currently selected file */
   char   mask[60];             /* filter for file clist */
   int    bufinx;               /* index of buffer option menu */
   int    clearfilenameflag;    /* flag to decide whether clear filename on path change */
};

/*--------------------------
** fad prototypes
**--------------------------
*/
   /***** User function are: *****/
int  fad_create_dialog ( struct fileAccessDialog_t *fad, char * title,
                         char * selection[], int clearflag );
void fad_hide_dialog ( struct fileAccessDialog_t *fad );
void fad_show_dialog ( struct fileAccessDialog_t *fad );

void fad_set_path( struct fileAccessDialog_t *fad, char * path );
void fad_set_filename( struct fileAccessDialog_t *fad, char * filename );
void fad_set_buffer( struct fileAccessDialog_t *fad, int bufinx );

void fad_set_ok_cb( struct fileAccessDialog_t *fad, GtkSignalFunc func );

void fad_set_buffer_cb( struct fileAccessDialog_t *fad, GtkSignalFunc func );

   /***** Helper function are: *****/
int fad_update_clist( int isDir, char *cdir, char *fmask, GtkWidget *widget );
int fad_qsort_comp_string( char **i, char **j );
GtkWidget * fad_MyCreateMenuFromSelection( char * selection[],
   int tearoff, GtkSignalFunc menuitem_cb, gpointer user_data );

/********************************************************************************/
/********************************************************************************/
