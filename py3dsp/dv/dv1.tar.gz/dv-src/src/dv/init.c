/********************************************************************************/
/*  INIT.C - Functions for initializing application & creating GUI elements      */
/********************************************************************************/

#define EXTERN extern

/*--------------------------
**  Standard include files
**--------------------------
*/
#include <sys/time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <gtk/gtk.h>

/*-----------------------------
**  Non-standard include files
**-----------------------------
*/
#include <error_msg.h>
#include <addlib.h>
#include <dflib.h>

#include "cm.h"           /* include colormap information  */
#include "dialog.h"       /* include misc dialog box */
#include "xpm.h"          /* include x pixmap data */

#include "dv.h"           /* DV MAIN APPLICATION  */

/********************************************************************************/
/*  The following function create / initialize widget, font, etc...             */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  create_base() - create/initialize all GUI objects
**-------------------------------------------------------------------------------
*/
int create_base(
   char * font_name    /* Use this font as default font, if specified */
)
{
   GtkWidget * base_window;
   GtkWidget * base_vbox;
   GtkWidget * widget;

   char buf[40];

   /*----------------------------------
   ** create application's base window
   */
   base_window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
   sprintf( buf, "%s %s (%s)", APP_NAME, APP_VERSION, __DATE__);
   gtk_window_set_title( GTK_WINDOW (base_window), buf );
   gtk_window_set_policy( GTK_WINDOW(base_window), FALSE, FALSE, FALSE );
   gtk_signal_connect( GTK_OBJECT(base_window), "delete_event", GTK_SIGNAL_FUNC(base_delete_event), NULL);
   gtk_signal_connect( GTK_OBJECT(base_window), "destroy",      GTK_SIGNAL_FUNC(base_destroy_cb), NULL);

   /*-----------------------------------------------
   ** Assign a new default font to the base window
   */

   if( font_name )
   {
      GtkStyle *style;
      GdkFont  *font;

      font = gdk_font_load( font_name );
      if( font )
      {
#if DEBUG
         printf("Setting default style's font to %s \n", font_name );
#endif
         style = gtk_widget_get_default_style();
         style->font = font;
      }
   }

   /*---------------------------------------------------------------
   ** Create style with different foreground to color some widgets
   */
   Style_Default = gtk_widget_get_default_style();
   Style_Red   = gtk_style_copy( Style_Default );
   Style_Green = gtk_style_copy( Style_Default );
   Style_Blue  = gtk_style_copy( Style_Default );
   Style_Gray  = gtk_style_copy( Style_Default );

   MyStyleSetItemColor( CM.colors[CM_RED],   'f', Style_Red );
   MyStyleSetItemColor( CM.colors[CM_GREEN], 'f', Style_Green );
   MyStyleSetItemColor( CM.colors[CM_BLUE],  'f', Style_Blue );
   MyStyleSetItemColor( CM.colors[CM_GRAY],  'f', Style_Gray );

   /*-------------------------------------
   ** Create base_vbox on the base_window - this is the main contain on the base window.
   */
   base_vbox = gtk_vbox_new( FALSE, 0);
   gtk_container_add( GTK_CONTAINER (base_window), base_vbox);

   /*----------------------------------
   ** main_menu_bar - (main_menu, colormap_w)
   */
   create_menu_hbox( base_window, &widget );
   gtk_box_pack_start(GTK_BOX(base_vbox), widget, FALSE, TRUE, 0);
   gtk_widget_show( widget );

   /*----------------------------------------------------
   ** Call function to create all data display widgets.
   */
   create_main_dpydata( &widget );
   gtk_box_pack_start(GTK_BOX(base_vbox), widget, FALSE, TRUE, 0);
   gtk_widget_show( widget );

   create_dialog_dpydata( &Dpy_dialog_window );

   /*--------------------------------------
   ** Create main parameter container/widgets (notebook)
   */
   create_notebook_widget( &widget );
   gtk_box_pack_start(GTK_BOX(base_vbox), widget, FALSE, TRUE, 0);
   gtk_widget_show( widget );

   /*------------------------------------------------------------
   ** Add container for CLI (command line interface)  widgets.
   ** (textout, command, feedback)
   */
   create_cli_widgets( &widget );
   gtk_box_pack_start(GTK_BOX(base_vbox), widget, FALSE, TRUE, 0);
   gtk_widget_show( widget );

   /*------------------------------------------------------------
   ** Add container for single line text feedback widgets.
   */
   create_label_widgets( &widget );
   gtk_box_pack_start(GTK_BOX(base_vbox), widget, FALSE, TRUE, 0);
   gtk_widget_show( widget );

   /* show vbox, base_window */
   gtk_widget_show( base_vbox );
   gtk_widget_show( base_window );

   /*--------------------------------------
   ** get/create application GCs & Fonts.
   */
   /* normal gc for all drawings */
   if( (Nor_gc = gdk_gc_new(base_window->window)) == NULL )
      printf("Error unable to obtain new GC: Nor_gc\n");

   /* Xor gc for all stats box */
   if( (Xor_gc = gdk_gc_new(base_window->window)) == NULL )
      printf("Error unable to obtain new GC: Xor_gc\n");
   gdk_gc_set_function( Xor_gc, GDK_XOR);
	gdk_gc_set_line_attributes( Xor_gc, 3, GDK_LINE_SOLID, GDK_CAP_BUTT, GDK_JOIN_MITER);

   /* Used fixed size fonts for all displays */
   if( (Fixed_font = gdk_font_load ("fixed")) == NULL )
      printf("Error unable to font: Fixed_font\n");
   Fixed_font_wid = gdk_char_width( Fixed_font, 'W' );
   Fixed_font_hgt =  Fixed_font->ascent+Fixed_font->descent;
   /* printf("Font size is %dx%d\n", Fixed_font_wid, Fixed_font_hgt); */

   /*--------------------------------------
   ** Create/set application icon.
   */
   {
      GtkStyle *style;
      GdkBitmap *mask;

      style = gtk_widget_get_style( base_window );
      Icon_pixmap = gdk_pixmap_create_from_xpm_d( base_window->window, &mask,
       &style->bg[GTK_STATE_NORMAL], (gchar **)Icon_xpm_data );

      gdk_window_set_icon( base_window->window, NULL, Icon_pixmap, NULL);
      gdk_window_set_icon_name( base_window->window, APP_NAME);
   }

   /*--------------------------------------
   ** get/create About dialog box
   */
   create_about_dialog( &About_dialog_window );

   /***************************************************************
   ** get/create File Open dialog box
   */
   fad_create_dialog( &Fad_open, "Open File", buffer_selection, TRUE );
   /* call function to create fileaccess dialog box */
   fad_set_ok_cb( &Fad_open, open_fad_ok_cb );    /* assign a cb to the OK button */
   fad_set_path( &Fad_open, Lc.path );            /* set the default path in the fileaccess dialog */

   /*-----------------------------------
   ** add MovieRead button to file open
   */
   {
      GtkWidget * button;

      button = gtk_button_new_with_label("MovieRead");
      gtk_table_attach_defaults( GTK_TABLE(Fad_open.table), button, 50, 75, 94, 100 );
      gtk_signal_connect( GTK_OBJECT (button), "clicked",
         GTK_SIGNAL_FUNC ( open_fad_movieread_cb ), (gpointer) &Fad_open );
      gtk_widget_show( button );

      button = gtk_button_new_with_label("MovieShow");
      gtk_table_attach_defaults( GTK_TABLE(Fad_open.table), button, 75, 100, 94, 100 );
      gtk_signal_connect( GTK_OBJECT (button), "clicked",
         GTK_SIGNAL_FUNC ( open_fad_movieshow_cb ), (gpointer) &Fad_open );
      gtk_widget_show( button );
   }

   /*-----------------------------------
   ** Add load button to file open
   ** Opens a file without closing the open dialog.
   ** Richard Emile Sarkis, 4/12/01
   */
   {
   	GtkWidget * load_button;

   	load_button = gtk_button_new_with_label("Load");
   	gtk_table_attach_defaults( GTK_TABLE(Fad_open.table), load_button, 5, 20, 103, 109 );
	gtk_signal_connect( GTK_OBJECT (load_button), "clicked",
		GTK_SIGNAL_FUNC ( open_fad_ok_cb ), (gpointer) &Fad_open );
   	gtk_widget_show(load_button);
   }



   /****************************************************************
   ** get/create Save File As dialog box
   */
   fad_create_dialog( &Fad_save, "Save File", buffer_selection, FALSE );
   /* call function to create fileaccess dialog box */
   fad_set_ok_cb( &Fad_save, save_fad_ok_cb );           /* assign a cb to the OK button */
   fad_set_buffer_cb( &Fad_save, save_fad_buffer_cb );   /* assign a cb to the buffer menu */
   fad_set_path( &Fad_save, Lc.path );             /* set the default path in the fileaccess dialog */

   /****************************************************************
   ** get/create Macro dialog box
   */
   create_macro_dialog( &Macro_dialog_window );

   return 0;
}

/********************************************************************************/
/*  Main Menu hbox - MainMenu + Colormap_w;                                     */
/********************************************************************************/

/*-----------------------------------------------------------------------
**  create_menu_hbox() - Create an hbox with:
**    |--hbox
**        |- button menu     - application's button menu
**        |- frame
**        |   |- Colormap_w  - colormap drawing area.
**        |- cm_file_w       - entry widget to select colormap
**-----------------------------------------------------------------------
*/
void create_menu_hbox( GtkWidget * base_window, GtkWidget ** c )
{
   GtkWidget * container;
   GtkWidget * hbox;
   GtkWidget * widget;
   GtkWidget * frame;
   GtkWidget * menu;

   hbox = gtk_hbox_new( FALSE, 0 );
   gtk_widget_show( hbox );

   container = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(container), GTK_SHADOW_ETCHED_OUT );
   gtk_container_add( GTK_CONTAINER(container), hbox );

   /* button menu */
   create_button_menu( &widget );
   gtk_box_pack_start(GTK_BOX(hbox), widget, TRUE, TRUE, 0);
   gtk_widget_show( widget );

   /* a frame */
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_ETCHED_OUT);
   gtk_box_pack_start(GTK_BOX(hbox), frame, FALSE, TRUE, 0);

   /* Put colormap_w in frame */
   Colormap_w = gtk_drawing_area_new();
   gtk_drawing_area_size( GTK_DRAWING_AREA(Colormap_w), 200, 25);
   gtk_container_add( GTK_CONTAINER(frame), Colormap_w);

   gtk_signal_connect( GTK_OBJECT(Colormap_w), "expose_event",
      (GtkSignalFunc)colormap_expose_event, NULL);
   gtk_signal_connect( GTK_OBJECT(Colormap_w), "configure_event",
      (GtkSignalFunc)colormap_configure_event, NULL);
   gtk_widget_show ( Colormap_w );
   gtk_widget_show ( frame );

   /*-----------------------------------------------
   ** Option menu for selecting colormap definitions
   */
   menu = MyCreateMenuFromSelection( colormap_selection, FALSE, cmap_menuitem_cb, NULL );
   widget = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU (widget), menu);
   gtk_box_pack_start(GTK_BOX(hbox), widget, FALSE, TRUE, 0);
   gtk_widget_show( widget );
   Cmap_option_w = widget;

   /* return the box reference to the user */
   *c = container;
}

/*-----------------------------------------------------------------------
**  create_button_menu() - Creates a menu of buttons.
**-----------------------------------------------------------------------
*/
void create_button_menu( GtkWidget ** c )
{
   GtkWidget * hbox;
   GtkWidget * button;

   hbox = gtk_hbox_new( FALSE, 0);

   /* File Open Button */
   button = gtk_button_new_with_label( "Open" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(Open_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), button, TRUE, TRUE, 0 );
   gtk_widget_show( button );

   /* File Save As Button */
   button = gtk_button_new_with_label( "Save" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(Save_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), button, TRUE, TRUE, 0 );
   gtk_widget_show( button );

   /* Macro Dialog Box Button */
   button = gtk_button_new_with_label( "Macro" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(Macro_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), button, TRUE, TRUE, 0 );
   gtk_widget_show( button );

   /* About Button */
   button = gtk_button_new_with_label( "About" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(About_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), button, TRUE, TRUE, 0 );
   gtk_widget_show( button );

   /* Quit Button */
   button = gtk_button_new_with_label( "Quit" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(Quit_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), button, TRUE, TRUE, 0 );
   gtk_widget_show( button );

   /* return the box reference to the user */
   *c = hbox;
}

/********************************************************************************/
/*  Function to create Displays (DrawingArea) for data Imaging/Graphing.        */
/********************************************************************************/

/*-----------------------------------------------------------------------
**  create_main_dpydata() - create container and fills the contains up
**         with dpydata used for images display.
**    table
**      |--- (insert all display into table).
**-----------------------------------------------------------------------
*/
void create_main_dpydata( GtkWidget ** c )
{
   int i;

   GtkWidget *table;
   GtkWidget *dpy;

   table = gtk_table_new( 1, 1, TRUE );

   /* create (Lc.num_dpy-1), last DPY is assumed to be in a dialog window */
   for( i=0; i < (Lc.num_dpy-1); i++ )
   {
      int row = (isodd(i) ? 1 : 0 );
      int col =  i / 2;

      create_one_dpydata( &dpy, 256, 256, i, FALSE );
      gtk_table_attach(GTK_TABLE(table), dpy, col, col+1, row, row+1, 0, 0, 0, 0);
      gtk_widget_show (dpy);
   }

   /* return the box reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_dialog_dpydata() - create a dpydata used for images display
**    in its own dialog window.
**-----------------------------------------------------------------------
*/
void create_dialog_dpydata ( GtkWidget ** c )
{
   GtkWidget * window;
   GtkWidget * dpy;
   char buf[25];

   window = gtk_window_new( GTK_WINDOW_DIALOG );
   sprintf( buf, "DV Dpy %d", Lc.num_dpy-1);
   gtk_window_set_title( GTK_WINDOW (window), buf);
   gtk_window_set_policy( GTK_WINDOW(window), TRUE, TRUE, TRUE );
   gtk_signal_connect( GTK_OBJECT(window), "delete_event", GTK_SIGNAL_FUNC(dialog_delete_event), NULL );
   gtk_signal_connect( GTK_OBJECT(window), "destroy", GTK_SIGNAL_FUNC(dialog_delete_event), NULL );

   create_one_dpydata( &dpy, 256, 256, Lc.num_dpy-1, TRUE);
   gtk_container_add( GTK_CONTAINER (window), dpy );
   gtk_widget_show( dpy );

   /* return window handle to caller */
   *c = window;
}

/*-----------------------------------------------------------------------
**  create_one_dpydata() - creates one display area using:
**     |-frame
**         |- table
**              |- drawingArea
**              |- drawingArea - vbar
**              |- hbar
**-----------------------------------------------------------------------
*/
void create_one_dpydata( GtkWidget ** c, int wid, int hgt, int dpinx, int resize_it )
{
   int options;

   GtkWidget *frame;
   GtkWidget *table;
   GtkWidget *title;
   GtkWidget *data;
   GtkObject *vadj, *hadj;
   GtkWidget *vsb, *hsb;

   /* printf("create_one_dpydata( %dx%d inx=%d)\n", wid, hgt, dpinx ); */

   /* create frame to surround all widgets */
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_ETCHED_OUT);

   /* create table & attach to frame */
   table = gtk_table_new( 3, 2, FALSE );
   gtk_container_add( GTK_CONTAINER(frame), table);

   /*----- title for canvas -----*/
   title = gtk_drawing_area_new();
   gtk_drawing_area_size( GTK_DRAWING_AREA(title), wid, 15 );
   gtk_table_attach(GTK_TABLE(table), title, 0, 3, 0, 1, GTK_SHRINK|GTK_FILL, 0, 0, 0);
   gtk_object_set_user_data( GTK_OBJECT(title), (gpointer) dpinx );
   gtk_widget_show (title);

   gtk_signal_connect( GTK_OBJECT(title), "expose_event",
      (GtkSignalFunc)dpytitle_expose_event, NULL);
   gtk_signal_connect( GTK_OBJECT(title), "configure_event",
      (GtkSignalFunc)dpytitle_configure_event, NULL);

   gtk_signal_connect( GTK_OBJECT(title), "button_press_event",
      (GtkSignalFunc) dpytitle_button_press_event, (gpointer)dpinx );

   gtk_widget_set_events ( title, GDK_BUTTON_PRESS_MASK );

   /*------------------------------------------
   ** data area for canvas.
   ** drawingArea don't normally accept focus/keypress event, so we
   ** need to add support for focus callback to support key_press events.
   */
   options = ( resize_it ?  GTK_EXPAND | GTK_SHRINK | GTK_FILL : 0 );
   data = gtk_drawing_area_new();
   gtk_drawing_area_size( GTK_DRAWING_AREA(data), wid, hgt );
   gtk_table_attach(GTK_TABLE(table), data, 0, 1, 1, 2, options, options, 0, 0 );
   gtk_object_set_user_data( GTK_OBJECT(data), (gpointer) dpinx );
   gtk_widget_show(data);

   gtk_signal_connect( GTK_OBJECT(data), "expose_event",
      (GtkSignalFunc)dpydata_expose_event, NULL);
   gtk_signal_connect( GTK_OBJECT(data), "configure_event",
      (GtkSignalFunc)dpydata_configure_event, NULL);

   /* IO events to watch for */
   gtk_signal_connect( GTK_OBJECT(data), "button_press_event",
      (GtkSignalFunc) dpydata_button_press_event, (gpointer)dpinx );
   gtk_signal_connect( GTK_OBJECT(data), "motion_notify_event",
      (GtkSignalFunc)dpydata_motion_notify_event, (gpointer)dpinx );

   gtk_signal_connect_after( GTK_OBJECT(data), "key_press_event",
      (GtkSignalFunc) dpydata_key_press_event, (gpointer)dpinx );
   gtk_signal_connect( GTK_OBJECT(data), "focus_in_event",
      (GtkSignalFunc)dpydata_focus_in_event, (gpointer)dpinx );
   gtk_signal_connect( GTK_OBJECT(data), "focus_out_event",
      (GtkSignalFunc)dpydata_focus_out_event, (gpointer)dpinx );

   gtk_widget_set_events ( data, GDK_EXPOSURE_MASK
      | GDK_LEAVE_NOTIFY_MASK
      | GDK_BUTTON_PRESS_MASK
      | GDK_KEY_PRESS_MASK
      | GDK_FOCUS_CHANGE_MASK
      | GDK_POINTER_MOTION_MASK
      | GDK_POINTER_MOTION_HINT_MASK);

   GTK_WIDGET_SET_FLAGS( data, GTK_CAN_FOCUS );

   /*----- Vertical scroll bar -----*/
   vadj = gtk_adjustment_new( 0, 0, 256, 1, 256, 256 );
   vsb  = gtk_vscrollbar_new( GTK_ADJUSTMENT(vadj) );
   gtk_range_set_update_policy( GTK_RANGE(vsb), GTK_UPDATE_DISCONTINUOUS);
   gtk_signal_connect(GTK_OBJECT(vadj), "value_changed", GTK_SIGNAL_FUNC(dpy_vadj_cb), (gpointer)dpinx);
   gtk_table_attach(GTK_TABLE(table), vsb, 1, 2, 1, 2, 0, GTK_SHRINK|GTK_FILL, 0, 0);
   gtk_widget_show ( vsb );

   /*----- horizontial  scroll bar -----*/
   hadj = gtk_adjustment_new( 0, 0, 256, 1, 256, 256 );
   hsb  = gtk_hscrollbar_new( GTK_ADJUSTMENT(hadj) );
   gtk_range_set_update_policy( GTK_RANGE(hsb), GTK_UPDATE_DISCONTINUOUS);
   gtk_signal_connect(GTK_OBJECT(hadj), "value_changed", GTK_SIGNAL_FUNC(dpy_hadj_cb), (gpointer)dpinx);
   gtk_table_attach(GTK_TABLE(table), hsb, 0, 1, 2, 3, GTK_SHRINK|GTK_FILL, 0, 0, 0);
   gtk_widget_show ( hsb );

   /* show table, save reference to title, data, and adjustments. Return frame reference */
   gtk_widget_show (table);
   Dpy[dpinx].title_drawingarea = title;
   Dpy[dpinx].data_drawingarea = data;
   Dpy[dpinx].vadj = GTK_ADJUSTMENT(vadj);
   Dpy[dpinx].hadj = GTK_ADJUSTMENT(hadj);
   *c = frame;
}

/*-----------------------------------------------------------------------
**  create_notebook_widget() - create notebook that contains all parameter widgets.
**  notebook
**   |--'Display Options' (Options for canvases - create_display_widgets)
**   |--'Math'            (math operations/equations - create_math_widgets)
**   |--'Setup'           (setup options - create_setup_widgets)
**   |--'Offset'          (offset options - create_offset_widgets)
**   |--'History'         (text widget to display messages - create_feedback_widgets)
**-----------------------------------------------------------------------
*/
void create_notebook_widget( GtkWidget ** c )
{
   GtkWidget * container;
   GtkWidget * notebook;
   GtkWidget * label;
   GtkWidget * page;
   GtkWidget * frame;

   notebook = gtk_notebook_new( );
   gtk_notebook_set_tab_pos( GTK_NOTEBOOK( notebook ), GTK_POS_TOP );
   gtk_widget_show( notebook );

   container = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(container), GTK_SHADOW_ETCHED_OUT );
   gtk_container_add( GTK_CONTAINER(container), notebook );

   label = gtk_label_new( "Display Options" );
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, label );
   gtk_widget_show( label );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   label = gtk_label_new( "Math" );
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_math_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, label );
   gtk_widget_show( label );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   label = gtk_label_new( "Setup" );
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_setup_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, label );
   gtk_widget_show( label );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   label = gtk_label_new( "TCS Offset" );
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_offset_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, label );
   gtk_widget_show( label );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   label = gtk_label_new( "Feedback" );
   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_feedback_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, label );
   gtk_widget_show( label );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   /* show this page at start up */
   gtk_notebook_set_page( GTK_NOTEBOOK(notebook), 5 );

   /* return the notebook reference to the user */
   *c = container;
}

/*-----------------------------------------------------------------------
**  create_display_widgets() - create widgets for main parameter container.
**  vbox
**   |--hbox  (Dpyactive_w, Dpytype_w, Dpybuf_w).
**   |--hbox
**-----------------------------------------------------------------------
*/
void create_display_widgets( GtkWidget ** c )
{
   GtkWidget * vbox;
   GtkWidget * hbox;
   GtkWidget * widget;
   GtkWidget * table;
   GtkWidget * menu;

   int i;
   char buf[10];

   vbox = gtk_vbox_new( FALSE, 0);

   /*--------------------------------------------
   ** hbox - for Dpyactive_w, Dpytype_w, Dpybuf_w
   */
   hbox = gtk_hbox_new( FALSE, 0);
   gtk_box_pack_start( GTK_BOX(vbox), hbox, FALSE, FALSE, 0);

   /*------------------------------------------------
   ** create dpyactive_w as a set of button in table
   */
   widget = gtk_label_new( "ActiveDpy:" );
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0 );
   gtk_widget_show( widget );

   table = gtk_table_new( 2, 2, TRUE );
   gtk_box_pack_start( GTK_BOX(hbox), table, FALSE, FALSE, 0 );
   for( i = 0; i < Lc.num_dpy; i++ )
   {
      int row = (isodd(i) ? 1 : 0 );
      int col =  i / 2;
      sprintf(buf, " %d ", i);
      widget = gtk_toggle_button_new_with_label( buf );
      gtk_table_attach_defaults( GTK_TABLE(table), widget, col, col+1, row, row+1 );
      gtk_signal_connect( GTK_OBJECT(widget), "released",
         GTK_SIGNAL_FUNC(dpyactive_cb), (gpointer) i );
      gtk_widget_show( widget );
      Dpyactive_w[i] = widget;
   }
   gtk_widget_show( table );

   /*------------------------------------------------
   ** create Dyptype_w as an option menu
   */
   widget = gtk_label_new( " DisplayType:");
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0);
   gtk_widget_show( widget );

   menu = MyCreateMenuFromSelection( dpytype_selection, FALSE, dpytype_menuitem_cb, NULL );
   widget = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU (widget), menu);
   gtk_box_pack_start(GTK_BOX(hbox), widget, FALSE, FALSE, 0);
   gtk_widget_show ( widget );
   Dpytype_w = widget;

   gtk_widget_show( hbox );

   /*------------------------------------------------
   ** create Buffer_w as a set of button in table
   */
   widget = gtk_label_new( " Buffer:");
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0 );
   gtk_widget_show( widget );

   table = gtk_table_new( 2, NUM_BUFFER/2, TRUE );
   gtk_box_pack_start( GTK_BOX(hbox), table, FALSE, FALSE, 0 );
   for( i = 0; i < NUM_BUFFER; i++ )
   {
      int row = (isodd(i) ? 1 : 0 );
      int col =  i / 2;
      sprintf(buf, " %c ", 'A'+i);
      widget = gtk_toggle_button_new_with_label( buf );
      gtk_table_attach_defaults( GTK_TABLE(table), widget, col, col+1, row, row+1 );
      gtk_signal_connect( GTK_OBJECT(widget), "released",
         GTK_SIGNAL_FUNC(buffer_cb), (gpointer) 'A'+i );
      gtk_widget_show( widget );
      Dpybuf_w[i] = widget;
   }
   gtk_widget_show( table );

   /*------------------------------------------------
   ** create a notebook for the display option parameters
   */
   create_display_parameters_notebook( &widget );
   gtk_box_pack_start( GTK_BOX(vbox), widget, TRUE, TRUE, 0 );
   gtk_widget_show( widget );

   /* return the box reference to the user */
   *c = vbox;
}

/*-----------------------------------------------------------------------
**  create_math_widgets() - create math operations/equations widgets on main notebook.
**-----------------------------------------------------------------------
*/
void create_math_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * entry;
   GtkWidget * label;
   GtkWidget * menu;
   GtkWidget * option;
   GtkWidget * button;
   int i, row;
   char * equation[] =
   {
      "c = a - b",
      "c = c - d",
      "a = a * 10",
      NULL,
   };

   table = gtk_table_new( 7, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 500, 125 );

   /*----------------------------------
   ** 3 execute button/entry widgets
   */
   row = 1;
   for ( i = 0; i < NUM_MATH_EQU; i++ )
   {
      row = (i*2)+1;

      /* entry widget */
      entry = gtk_entry_new_with_max_length( 80 );
      gtk_entry_set_text( GTK_ENTRY(entry), equation[i] );
      gtk_table_attach_defaults( GTK_TABLE(table), entry, 3, 7, row, row+1 );
      gtk_widget_show(entry);
      Math_equ_w[i] = entry;

      /* button to execute equation in entry widget */
      button = gtk_button_new_with_label( "Execute"  );
      gtk_table_attach_defaults( GTK_TABLE(table), button, 1, 3, row, row+1 );
      gtk_widget_show( button );
      gtk_signal_connect( GTK_OBJECT(button), "released", GTK_SIGNAL_FUNC(math_equ_cb), (gpointer)entry);
   }

   /*------------------------
   ** copy
   */
   button = gtk_button_new_with_label( "Copy" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 9, 11, 1, 2 );
   gtk_widget_show( button );
   gtk_signal_connect( GTK_OBJECT(button), "released", GTK_SIGNAL_FUNC(math_copy_button_cb), (gpointer)NULL );

   menu = MyCreateMenuFromSelection( buffer_selection, FALSE, math_copy_from_cb, NULL );
   option = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option), menu );
   gtk_table_attach_defaults( GTK_TABLE(table), option, 11, 13, 1, 2 );
   gtk_widget_show( option );

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 13, 14, 1, 2 );
   gtk_widget_show( label );

   menu = MyCreateMenuFromSelection( buffer_selection, FALSE, math_copy_to_cb, NULL );
   option = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option), menu );
   gtk_table_attach_defaults( GTK_TABLE(table), option, 14, 16, 1, 2 );
   gtk_widget_show( option );

   /*------------------------
   ** clear
   */
   button = gtk_button_new_with_label( "Clear" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 9, 11, 3, 4 );
   gtk_widget_show( button );
   gtk_signal_connect( GTK_OBJECT(button), "released", GTK_SIGNAL_FUNC(math_clear_button_cb), (gpointer)NULL );

   menu = MyCreateMenuFromSelection( buffer_selection, FALSE, math_clear_bufinx_cb, NULL );
   option = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option), menu );
   gtk_table_attach_defaults( GTK_TABLE(table), option, 11, 13, 3, 4 );
   gtk_widget_show( option );

   /*------------------------
   ** rotate
   */
   button = gtk_button_new_with_label( "Rotate" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 9, 11, 5, 6 );
   gtk_widget_show( button );
   gtk_signal_connect( GTK_OBJECT(button), "released", GTK_SIGNAL_FUNC(math_rotate_button_cb), (gpointer)NULL );

   menu = MyCreateMenuFromSelection( buffer_selection, FALSE, math_rotate_bufinx_cb, NULL );
   option = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option), menu );
   gtk_table_attach_defaults( GTK_TABLE(table), option, 11, 13, 5, 6 );
   gtk_widget_show( option );

   menu = MyCreateMenuFromSelection( rotate_selection, FALSE, math_rotate_ops_cb, NULL );
   option = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option), menu );
   gtk_table_attach_defaults( GTK_TABLE(table), option, 13, 16, 5, 6 );
   gtk_widget_show( option );

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_setup_widgets() - create the setup options main notebook page.
**-----------------------------------------------------------------------
*/
void create_setup_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * entry;
   GtkWidget * label;
   GtkWidget * checkbutton;
   GtkWidget * menu;
   GtkWidget * option;
   GtkWidget * button;

   table = gtk_table_new( 7, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 500, 125 );

   /*-------------------------------
   **  div by coadd radio buttons
   */
   checkbutton = gtk_check_button_new_with_label("Div By Divisor");
   gtk_signal_connect( GTK_OBJECT(checkbutton), "toggled",
      GTK_SIGNAL_FUNC (checkbutton_offon_cb), (gpointer) "DivByDivisor" );
   gtk_table_attach_defaults (GTK_TABLE(table), checkbutton, 4, 9, 0, 1 );
   gtk_widget_show(checkbutton);
   DivByDivisor_w = checkbutton;

   /*-------------------------------
   **  hostname
   */
   label = gtk_label_new( "TCS Hostname: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
			 GTK_SIGNAL_FUNC(entry_cb), (gpointer) "TCSHostname" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
			 GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "TCSHostname" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 9, 1, 2 );
   gtk_widget_show(entry);
   TCShostname_w = entry;

   /*-------------------------------
   **  printer name
   */
   label = gtk_label_new( "Printer: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 3, 4 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
			 GTK_SIGNAL_FUNC(entry_cb), (gpointer) "Printer" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
			 GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "Printer" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 9, 3, 4 );
   gtk_widget_show(entry);
   Printer_w = entry;

   /*-------------------------------
   **  PrinterType
   */
   label = gtk_label_new( "Printer Type: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 4, 5 );
   gtk_widget_show( label );

   menu = MyCreateMenuFromSelection( printer_selection, FALSE, printertype_cb, NULL );
   option = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option), menu );
   gtk_table_attach_defaults( GTK_TABLE(table), option, 4, 9, 4, 5 );
   gtk_widget_show( option );
   PrinterType_w = option;

   /*-------------------------------
   **  Print To File
   */
   checkbutton = gtk_check_button_new_with_label("Print to File");
   gtk_signal_connect( GTK_OBJECT(checkbutton), "toggled",
      GTK_SIGNAL_FUNC (checkbutton_offon_cb), (gpointer) "PrintToFile" );
   gtk_table_attach_defaults (GTK_TABLE(table), checkbutton, 4, 9, 5, 6 );
   gtk_widget_show(checkbutton);
   PrintToFile_w = checkbutton;

   /*-------------------------------
   **  Default Path
   */
   label = gtk_label_new( "(default) Path: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 6, 7 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 100 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
		GTK_SIGNAL_FUNC(entry_cb), (gpointer) "Path" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
		GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "Path" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 15, 6, 7 );
   gtk_widget_show(entry);
   Path_w = entry;

   /*-----------------------------------
   **  Browse for Path button & dialog
   */
   button = gtk_button_new_with_label("Browse Path...");
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(bfp_show), (gpointer) &Bfp_path );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 15, 19, 6, 7);
   gtk_widget_show(button);

   bfp_create_dialog( &Bfp_path, "Browse for Data Path" ); /* call function to create dialog box */
   bfp_set_ok_cb( &Bfp_path, path_bfp_ok_cb );             /* assign a cb to the OK button */

   /*-------------------------------
   **  cm.inverse button
   */
   button = gtk_button_new_with_label("ColorMap.Inverse");
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb),
      (gpointer) "ColorMap.Inverse" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 12, 18, 0, 1);
   gtk_widget_show( button );

   /*-------------------------------
   **  Show DV Port 
   */
   label = gtk_label_new( "Dv Port Label" );
   gtk_misc_set_alignment( GTK_MISC(label), 0, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 12, 20, 2, 3);
   gtk_widget_show( label );
	Dvport_w = label;

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_offset_widgets() - create the TCS offset notebook page.
**-----------------------------------------------------------------------
*/
void create_offset_widgets( GtkWidget ** c )
{
   int i, x;
   GtkWidget * table;
   GtkWidget * entry;
   GtkWidget * label;
   GtkWidget * button;
   GtkWidget * checkbutton;

   table = gtk_table_new( 7, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 500, 125 );

   /*-------------------------------
   **  Set defaults buttons
   */
   label = gtk_label_new( "Set Defaults: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 0, 1 );
   gtk_widget_show( label );

   /* cshell Button */
   button = gtk_button_new_with_label( "Cshell" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(offset_defaults_cb),
                       (gpointer)1);
   gtk_table_attach_defaults( GTK_TABLE(table), button, 4, 7, 0, 1 );
   gtk_widget_show( button );

   /* nsfcam Button */
   button = gtk_button_new_with_label( "Nsfcam" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(offset_defaults_cb),
                       (gpointer)2);
   gtk_table_attach_defaults( GTK_TABLE(table), button, 7, 10, 0, 1 );
   gtk_widget_show( button );

   /* spex Button */
   button = gtk_button_new_with_label( "Spex" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(offset_defaults_cb),
                       (gpointer)3);
   gtk_table_attach_defaults( GTK_TABLE(table), button, 10, 13, 0, 1 );
   gtk_widget_show( button );

   /*-------------------------------
   **  Use_FITS_Position_Angle
   */
   checkbutton = gtk_check_button_new_with_label("Use FITS Angle&Scale");
   gtk_signal_connect( GTK_OBJECT(checkbutton), "toggled",
      GTK_SIGNAL_FUNC (checkbutton_offon_cb), (gpointer) "UseFITSAngle&Scale" );
   gtk_table_attach_defaults (GTK_TABLE(table), checkbutton, 14, 20, 0, 1);
   gtk_widget_show(checkbutton);
   Use_FITS_Angle_Scale_w = checkbutton;

   /*-------------------------------
   **  angle text entry
   */
   label = gtk_label_new( "Angle: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 4, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 40 );
   gtk_entry_set_text( GTK_ENTRY(entry), "270" );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							 GTK_SIGNAL_FUNC(entry_cb), (gpointer) "Offset.angle" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event", 
							 GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "Offset.angle" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 9, 2, 3 );
   gtk_widget_show(entry);
   Offset_angle_w = entry;

   /*-------------------------------
   **  plate scale text entry
   */
   label = gtk_label_new( "Plate Scale: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 4, 3, 4 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 40 );
   gtk_entry_set_text( GTK_ENTRY(entry), "0.20" );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(entry_cb), (gpointer) "Offset.platescale" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event", 
							 GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "Offset.platescale" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 9, 3, 4 );
   gtk_widget_show(entry);
   Offset_platescale_w = entry;

   /*-------------------------------
   **  beginning coordinates text entry
   */
   label = gtk_label_new( "From (x,y): " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 9, 14, 2, 3);
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 40 );
   gtk_entry_set_text( GTK_ENTRY(entry), "50 125" );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(entry_cb), (gpointer) "Offset.BegXY" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event", 
							 GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "Offset.BegXY" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 14, 18, 2, 3);
   gtk_widget_show(entry);
   Offset_beg_xy_w = entry;

   /*-------------------------------
   **  end coordinates text entry
   */
   label = gtk_label_new( "to (x,y): " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 9, 14, 3, 4 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 40 );
   gtk_entry_set_text( GTK_ENTRY(entry), "50 125" );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(entry_cb), (gpointer) "Offset.EndXY" );
	gtk_signal_connect( GTK_OBJECT (entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "Offset.EndXY" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 14, 18, 3, 4 );
   gtk_widget_show(entry);
   Offset_end_xy_w = entry;

   /*-------------------------------
   **  send offset to TCS button
   */
   button = gtk_button_new_with_label( "Offset Telescope" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb),
      (gpointer) "Offset.TCS" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 0, 6, 4, 5 );
   gtk_widget_show( button );

   /*-------------------------------
   **  send AB.offset to TCS 
	*/
   button = gtk_button_new_with_label( "Send AB Beam Offsets " );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb),
      (gpointer) "OffsetAB.TCS" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 14, 20, 4, 5 );
   gtk_widget_show( button );


   /*-------------------------------
   **  Offset in RA and DEC
   */
   label = gtk_label_new( "Offsets are:" );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 6, 9, 4, 5 );
   gtk_widget_show( label );

   label = gtk_label_new( "0 0" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 9, 14, 4, 5 );
   gtk_widget_show( label );
   Offset_radec_w = label;

   /*------------------------------
   ** Set SubArray from Box buttons:
   */
   label = gtk_label_new( "Set SubArray from Box:" );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 7, 6, 7 );
   gtk_widget_show( label );

   x = 7;
   for( i=0; i < 5; i++ )
   {
      char *button_names[5] = { " 0 ", " 1 ", " 2 ", " Ga ", " Gb "};
      button = gtk_button_new_with_label( button_names[i] );
      gtk_signal_connect( GTK_OBJECT(button), "released",
         GTK_SIGNAL_FUNC(spex_subarray_cb), (gpointer) i );

      gtk_table_attach_defaults( GTK_TABLE(table), button, x, x+1, 6, 7);
      gtk_widget_show( button );
      x += 1;
   }

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_feedback_widgets() - create text feedback widget
**-----------------------------------------------------------------------
*/
void create_feedback_widgets( GtkWidget ** c )
{
   GtkWidget * hbox,
             * vsb;

   /*---------------------
   ** hbox - TextOut_w, Sb
   */
   hbox = gtk_hbox_new( FALSE, 0);

   /* TextOut_w */
   TextOut_w = gtk_text_new (NULL, NULL);
   gtk_text_set_editable( GTK_TEXT (TextOut_w), TRUE);
   gtk_box_pack_start( GTK_BOX(hbox), TextOut_w, TRUE, TRUE, 0);
   gtk_widget_show( TextOut_w );

   /* textOutSb */
   vsb = gtk_vscrollbar_new( GTK_TEXT(TextOut_w)->vadj );
   gtk_box_pack_start( GTK_BOX(hbox), vsb, FALSE, FALSE, 0);
   gtk_widget_show( vsb );

   /* return the box reference to the user */
   *c = hbox;
}

/*-----------------------------------------------------------------------
**  create_display_parameters_notebook() - create a notebook for the display option parameters.
**  vbox
**   |--hbox
**-----------------------------------------------------------------------
*/
void create_display_parameters_notebook( GtkWidget ** c )
{
   GtkWidget * notebook;
   GtkWidget * page;
   GtkWidget * frame;

   notebook = gtk_notebook_new( );
   gtk_notebook_set_tab_pos( GTK_NOTEBOOK( notebook ), GTK_POS_TOP );
   gtk_notebook_set_show_tabs( GTK_NOTEBOOK( notebook ), FALSE );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_image_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_notebook_set_page( GTK_NOTEBOOK(notebook), 0 );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_header_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_histogram_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_linecut_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_xlinecut_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_noise_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_pointer_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   frame = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame), GTK_SHADOW_NONE );
   create_display_stats_widgets( &page );
   gtk_container_add( GTK_CONTAINER(frame), page );
   gtk_notebook_append_page( GTK_NOTEBOOK(notebook), frame, NULL );
   gtk_widget_show( frame );
   gtk_widget_show( page );

   Notebook_dpy_w = notebook;
   /* return the notebook reference to the user */
   *c = notebook;
}

/*-----------------------------------------------------------------------
**  create_display_image_widgets() - create the image parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_image_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * label;
   GtkWidget * entry;
   GtkWidget * hbox;
   GtkWidget * button;
   GtkWidget * hscale;
   GtkObject * adj;

   int x, i;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*------------------------------
   ** Zoom
   */
   label = gtk_label_new( "Zoom: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 2, 0, 1 );
   gtk_widget_show( label );

   adj = gtk_adjustment_new( 1, -7, 20, 1, 1, 0);
   gtk_signal_connect( GTK_OBJECT (adj), "value_changed", GTK_SIGNAL_FUNC(image_zoom_cb), "ImageZoom");

   hscale = gtk_hscale_new( GTK_ADJUSTMENT (adj));
   gtk_range_set_update_policy( GTK_RANGE(hscale), GTK_UPDATE_DISCONTINUOUS);
   gtk_scale_set_digits( GTK_SCALE(hscale), 0);
   gtk_scale_set_value_pos( GTK_SCALE(hscale), GTK_POS_LEFT);
   gtk_scale_set_draw_value( GTK_SCALE(hscale), TRUE);
   gtk_table_attach_defaults( GTK_TABLE(table), hscale, 2, 8, 0, 1);
   gtk_widget_show(hscale);
   ImageZoom_w = adj;

   /*------------------------------------
   ** Full Image
   */
   button = gtk_button_new_with_label( "Full Image" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button2_cb), (gpointer)"FullImage" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 2, 8, 1, 2  );
   gtk_widget_show( button );

   /*------------------------------------
   ** box zoom
   */
   label = gtk_label_new( "Box: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 2, 2, 3 );
   gtk_widget_show( label );

   button = gtk_button_new_with_label( "Zoom" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button2_cb), (gpointer)"BoxZoom" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 2, 5, 2, 3  );
   gtk_widget_show( button );

   /*------------------------------------
   ** BoxScale
   */
   button = gtk_button_new_with_label( "Scale" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 5, 8, 2, 3  );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button2_cb), (gpointer)"BoxScale" );
   gtk_widget_show( button );

   /*------------------------------------
   ** ObjBoxPeak
   */
   button = gtk_button_new_with_label( "Peak" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button2_cb), (gpointer)"BoxPeak" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 2, 5, 3, 4  );
   gtk_widget_show( button );

   /*------------------------------------
   ** ObjBoxCentroid
   */
   button = gtk_button_new_with_label( "Centroid" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button2_cb), (gpointer)"BoxCentroid" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 5, 8, 3, 4  );
   gtk_widget_show( button );

   /*------------------------------
   ** Set SubArray from Box buttons:
   */
   label = gtk_label_new( "Set SubArray from Box:" );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 6, 4, 5 );
   gtk_widget_show( label );

   x = 6;
   for( i=0; i < 5; i++ )
   {
      char *button_names[5] = { " 0 ", " 1 ", " 2 ", " Ga ", " Gb "};
      button = gtk_button_new_with_label( button_names[i] );
      gtk_signal_connect( GTK_OBJECT(button), "released",
         GTK_SIGNAL_FUNC(spex_subarray_cb), (gpointer) i );

      gtk_table_attach_defaults( GTK_TABLE(table), button, x, x+1, 4, 5);
      gtk_widget_show( button );
      x += 1;
   }

   /*------------------------------
   ** AutoScale Label & radio buttons
   */
   label = gtk_label_new( "AutoScale: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 9, 12, 0, 1 );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( imageautoscale_selection, ImageAutoScale_w, TRUE, image_autoscale_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 12, 18, 0, 1 );
   gtk_widget_show( hbox );

   /*------------------------------
   ** ImageScaleRange
   */
   label = gtk_label_new( "Range: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 10, 12, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", GTK_SIGNAL_FUNC(image_range_cb), (gpointer)NULL);
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 15, 1, 2 );
   gtk_widget_show(entry);
   ImageRangeMin_w = entry;

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 15, 16, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", GTK_SIGNAL_FUNC(image_range_cb), (gpointer)NULL);
	gtk_signal_connect( GTK_OBJECT (entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC (image_range_fo_cb), (gpointer) NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 16, 19, 1, 2 );
   gtk_widget_show(entry);
   ImageRangeMax_w = entry;

   /*------------------------------------
   ** 1 to 99% scale
   */
   button = gtk_button_new_with_label( "1-99% Fixed Scale" );
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button2_cb), (gpointer)"ImageScale1P" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 12, 19, 2, 3 );
   gtk_widget_show( button );

   /*------------------------------
   ** print button
   */
   button = gtk_button_new_with_label( "Print" );
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb), (gpointer)"Print" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 15, 19, 4, 5 );
   gtk_widget_show( button );

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_display_header_widgets() - create the header parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_header_widgets( GtkWidget ** c )
{
   GtkWidget * frame;

   frame = gtk_frame_new( NULL );

   /* return the button reference to the user */
   *c = frame;
}

/*-----------------------------------------------------------------------
**  create_display_histogram_widgets() - create the histogram parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_histogram_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * label;
   GtkWidget * entry;
   GtkWidget * hbox;
   GtkWidget * button;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*------------------------------
   ** Histogram Range
   */
   label = gtk_label_new( "Range: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 6, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", GTK_SIGNAL_FUNC(hist_range_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 6, 10, 1, 2 );
   gtk_widget_show(entry);
   HistRangeMin_w = entry;

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 10, 12, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(hist_range_cb), (gpointer)NULL );
	gtk_signal_connect( GTK_OBJECT (entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC (hist_range_fo_cb), (gpointer) NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 16, 1, 2 );
   gtk_widget_show(entry);
   HistRangeMax_w = entry;

   /*------------------------------
   ** Histogram Bin Number
   */
   label = gtk_label_new( "Num of Bins (1-100): " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 6, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(entry_cb), (gpointer) "HistBin" );
	gtk_signal_connect( GTK_OBJECT (entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "HistBin" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 6, 8, 2, 3 );
   gtk_widget_show(entry);
   HistBin_w = entry;

   /*------------------------------
   ** Histogram Area Selection
   */
   label = gtk_label_new( "Area: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 6, 3, 4 );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( allbox_selection, HistArea_w, TRUE, hist_area_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 6, 9, 3, 4 );
   gtk_widget_show( hbox );

   /*------------------------------
   ** print button
   */
   button = gtk_button_new_with_label( "Print" );
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb), (gpointer)"Print" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 17, 19, 4, 5 );
   gtk_widget_show( button );

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_display_linecut_widgets() - create the linecut parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_linecut_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * label;
   GtkWidget * entry;
   GtkWidget * hbox;
   GtkWidget * button;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*------------------------------
   ** Linecut X Axis
   */
   label = gtk_label_new( "X Axis: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 4, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(lcut_xy_cb), (gpointer)NULL );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC(lcut_xy_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 7, 1, 2 );
   gtk_widget_show(entry);
   LcutX_w = entry;

   button = gtk_button_new_with_label( "UP" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(lcut_xarrow), (gpointer) (+1) );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 7, 8, 1, 2 );
   gtk_widget_show( button );

   button = gtk_button_new_with_label( "DN" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(lcut_xarrow), (gpointer) (-1) );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 8, 9, 1, 2 );
   gtk_widget_show( button );

   /*------------------------------
   ** Linecut Area Selection
   */
   label = gtk_label_new( "Area: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 10, 12, 1, 2 );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( allbox_selection, LcutArea_w, TRUE, lcut_area_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 12, 15, 1, 2 );
   gtk_widget_show( hbox );

   /*------------------------------
   ** Linecut Y Axis
   */
   label = gtk_label_new( "Y Axis: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 4, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(lcut_xy_cb), (gpointer)NULL );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC(lcut_xy_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 7, 2, 3 );
   gtk_widget_show(entry);
   LcutY_w = entry;

   button = gtk_button_new_with_label( "UP" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(lcut_yarrow), (gpointer) (+1) );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 7, 8, 2, 3 );
   gtk_widget_show( button );

   button = gtk_button_new_with_label( "DN" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(lcut_yarrow), (gpointer) (-1) );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 8, 9, 2, 3 );
   gtk_widget_show( button );

   /*------------------------------
   ** Linecut Range
   */
   label = gtk_label_new( "Range: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 10, 12, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", GTK_SIGNAL_FUNC(lcut_range_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 15, 2, 3 );
   gtk_widget_show(entry);
   LcutRangeMin_w = entry;

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 15, 16, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(lcut_range_cb), (gpointer)NULL );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC(lcut_range_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 16, 19, 2, 3 );
   gtk_widget_show(entry);
   LcutRangeMax_w = entry;

   /*------------------------------
   ** AutoScale Label & radio buttons
   */
   label = gtk_label_new( "Auto Scale: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 3, 4  );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( imageautoscale_selection, LcutAutoScale_w, TRUE, lcut_autoscale_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 4, 8, 3, 4  );
   gtk_widget_show( hbox );

   /*------------------------------
   ** print button
   */
   button = gtk_button_new_with_label( "Print" );
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb), (gpointer)"Print" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 17, 19, 4, 5 );
   gtk_widget_show( button );

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_display_xlinecut_widgets() - create the xlinecut parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_xlinecut_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * label;
   GtkWidget * entry;
   GtkWidget * hbox;
   GtkWidget * button;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*------------------------------
   ** AutoScale Label & radio buttons
   */
   label = gtk_label_new( "Auto Scale: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 1, 2 );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( imageautoscale_selection, XcutAutoScale_w, TRUE, xcut_autoscale_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 4, 8, 1, 2 );
   gtk_widget_show( hbox );

   /*------------------------------
   ** X Linecut set endpoints
   */
   button = gtk_button_new_with_label( "Set Endpoint from Line" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(xcut_setline_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 2, 9, 2, 3 );
   gtk_widget_show( button );

   /*------------------------------
   ** X Linecut Beg to End of line
   */
   label = gtk_label_new( "Beg " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 11, 12, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(xcut_set_cb), (gpointer)NULL );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC(xcut_set_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 15, 2, 3 );
   gtk_widget_show(entry);
   XcutBeg_w = entry;

   label = gtk_label_new( "End " );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 15, 16, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(xcut_set_cb), (gpointer)NULL );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC(xcut_set_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 16, 19, 2, 3 );
   gtk_widget_show(entry);
   XcutEnd_w = entry;

   /*------------------------------
   ** X Linecut output to XGFIT
   */
   button = gtk_button_new_with_label( "Output Guassian Data" );
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(xcut_xgfit_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 2, 9, 3, 4  );
   gtk_widget_show( button );

   /*------------------------------
   ** X Linecut Range
   */
   label = gtk_label_new( "Range: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 10, 12, 3, 4  );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(xcut_range_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 15, 3, 4  );
   gtk_widget_show(entry);
   XcutRangeMin_w = entry;

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 15, 16, 3, 4  );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(xcut_range_cb), (gpointer)NULL );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event", 
							  GTK_SIGNAL_FUNC(lcut_range_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 16, 19, 3, 4  );
   gtk_widget_show(entry);
   XcutRangeMax_w = entry;

   /*------------------------------
   ** print button
   */
   button = gtk_button_new_with_label( "Print" );
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb), (gpointer)"Print" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 17, 19, 4, 5 );
   gtk_widget_show( button );

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_display_noise_widgets() - create the noise parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_noise_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * label;
   GtkWidget * entry;
   GtkWidget * hbox;
   GtkWidget * button;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*------------------------------
   ** Noise Mod (1-256)
   */
   label = gtk_label_new( "Mod (1-256): " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 1, 2 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate",
		GTK_SIGNAL_FUNC(entry_cb), (gpointer) "NoiseMod" );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
		GTK_SIGNAL_FUNC (entry_fo_cb), (gpointer) "NoiseMod" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 4, 6, 1, 2 );
   gtk_widget_show(entry);
   NoiseMod_w = entry;

   /*------------------------------
   ** Area Label & radio buttons
   */
   label = gtk_label_new( "Area: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 10, 12, 1, 2 );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( allbox_selection, NoiseArea_w, TRUE, noise_area_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 12, 15, 1, 2 );
   gtk_widget_show( hbox );

   /*------------------------------
   ** Graph Type Label & radio buttons
   */
   label = gtk_label_new( "Graph Type: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 4, 2, 3 );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( noisegraphtype_selection, NoiseGraphType_w, TRUE, noise_graphtype_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 4, 8, 2, 3 );
   gtk_widget_show( hbox );

   /*------------------------------
   ** Noise Graph 1 Range
   */
   label = gtk_label_new( "Graph1 Rng: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 8, 12, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
							  GTK_SIGNAL_FUNC(noise_g1range_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 15, 2, 3 );
   gtk_widget_show(entry);
   NoiseG1RangeMin_w = entry;

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 15, 16, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
		GTK_SIGNAL_FUNC(noise_g1range_cb), (gpointer)NULL );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
		GTK_SIGNAL_FUNC(noise_g1range_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 16, 19, 2, 3 );
   gtk_widget_show(entry);
   NoiseG1RangeMax_w = entry;

   /*------------------------------
   ** AutoScale Label & radio buttons
   */
   label = gtk_label_new( "Auto Scale: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 4, 3, 4  );
   gtk_widget_show( label );

   hbox = MyCreateRadioButtons( imageautoscale_selection, NoiseAutoScale_w, TRUE, noise_autoscale_cb );
   gtk_table_attach_defaults( GTK_TABLE(table), hbox, 4, 8, 3, 4  );
   gtk_widget_show( hbox );

   /*------------------------------
   ** Noise Graph 2 Range
   */
   label = gtk_label_new( "Graph2 Rng: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 8, 12, 3, 4  );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
		GTK_SIGNAL_FUNC(noise_g2range_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 12, 15, 3, 4  );
   gtk_widget_show(entry);
   NoiseG2RangeMin_w = entry;

   label = gtk_label_new( "to" );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 15, 16, 3, 4  );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
		GTK_SIGNAL_FUNC(noise_g2range_cb), (gpointer)NULL );
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
		GTK_SIGNAL_FUNC(noise_g1range_fo_cb), (gpointer)NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 16, 19, 3, 4  );
   gtk_widget_show(entry);
   NoiseG2RangeMax_w = entry;

   /*------------------------------
   ** print button
   */
   button = gtk_button_new_with_label( "Print" );
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(button_cb), (gpointer)"Print" );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 17, 19, 4, 5 );
   gtk_widget_show( button );

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_display_pointer_widgets() - create the pointer parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_pointer_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * label;
   GtkWidget * entry;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*------------------------------
   ** Pointer Box Size in Pixels
   */
   label = gtk_label_new( "Image Size (11-31): " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 1, 6, 2, 3 );
   gtk_widget_show( label );

   entry = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
		GTK_SIGNAL_FUNC(entry_cb), (gpointer)"PtImageSize" );
   gtk_signal_connect( GTK_OBJECT(entry), "focus-out-event",
		GTK_SIGNAL_FUNC(entry_fo_cb), (gpointer)"PtImageSize" );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 6, 9, 2, 3 );
   gtk_widget_show(entry);
   PtImageSize_w = entry;

   /* return the table reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_display_stats_widgets() - create the stats parameters widgets.
**-----------------------------------------------------------------------
*/
void create_display_stats_widgets( GtkWidget ** c )
{
   GtkWidget * table;
   GtkWidget * button;
   GtkWidget * entry;

   table = gtk_table_new( 5, 20, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 475, 125 );

   /*---------------------------------------
   ** Set sky button
   */
   button = gtk_button_new_with_label( "Set Sky" );
   gtk_table_attach( GTK_TABLE(table), button, 1, 9, 1, 2, GTK_EXPAND|GTK_FILL, 0, 0, 0);
   gtk_signal_connect(GTK_OBJECT(button), "clicked",
      GTK_SIGNAL_FUNC(stats_setsky_cb), (gpointer) NULL);
   gtk_widget_show( button );

   /*---------------------------------------
   ** Fix WH check button & entry
   */
   button = gtk_check_button_new_with_label( "Fix Wid & Hgt to" );
   gtk_signal_connect( GTK_OBJECT(button), "released",
      GTK_SIGNAL_FUNC(stats_fixedwh_cb), (gpointer) NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), button, 1, 6, 2, 3);
   gtk_widget_show( button );
   StatsFixedWH_w = button;

   entry = gtk_entry_new_with_max_length( 10 );
   gtk_table_attach_defaults( GTK_TABLE(table), entry, 6, 9, 2, 3);
   gtk_signal_connect( GTK_OBJECT(entry), "activate", 
		GTK_SIGNAL_FUNC(stats_wh_entry_cb), (gpointer)NULL);
	gtk_signal_connect (GTK_OBJECT (entry), "focus-out-event",
		GTK_SIGNAL_FUNC (stats_wh_entry_fo_cb), (gpointer)NULL );

   gtk_widget_show(entry);
   StatsWHentry_w = entry;

   /* return the container reference to the user */
   *c = table;
}

/*-----------------------------------------------------------------------
**  create_cli_widgets() - create widgets for cli (command line interface)
**     related functions.
**   container
**    |--hbox - commandLabel, commandEnty
**-----------------------------------------------------------------------
*/
void create_cli_widgets( GtkWidget ** c )
{
   GtkWidget * hbox,
             * container,
             * widget;

   /*---------------------
   ** hbox - label, commandEntry
   */
   hbox = gtk_hbox_new( FALSE, 0 );
   gtk_widget_show( hbox );

   container = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(container), GTK_SHADOW_ETCHED_OUT );
   gtk_container_add( GTK_CONTAINER(container), hbox );

   /* command prompt & entry */
   widget = gtk_label_new( "Command>" );
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0);
   gtk_widget_show(widget);

   widget = gtk_entry_new_with_max_length( 80 );
   gtk_signal_connect( GTK_OBJECT (widget), "activate",
      GTK_SIGNAL_FUNC(command_entry_cb), (gpointer) NULL );
   gtk_box_pack_start( GTK_BOX(hbox), widget, TRUE, TRUE, 0);
   gtk_widget_show( widget );

   /* return the container reference to the user */
   *c = container;
}

/*-----------------------------------------------------------------------
**  create_label_widgets() - create widgets for single line text feedback
**   container
**    |--label - commandLabel
**-----------------------------------------------------------------------
*/
void create_label_widgets( GtkWidget ** c )
{
   GtkWidget * container,
             * label;

   container = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(container), GTK_SHADOW_ETCHED_OUT );

   label = gtk_label_new( "Ready...." );
   gtk_misc_set_alignment( GTK_MISC (label), 0.0, 0.5 );
   gtk_container_add( GTK_CONTAINER(container), label );
   gtk_widget_show(label);
   LineText_w = label;

   /* return the container reference to the user */
   *c = container;
}

/********************************************************************************/
/*  about dialog                                                                */
/********************************************************************************/

/*-----------------------------------------------------------------------
**  create_about_dialog() - create widgets for parameter container.
**-----------------------------------------------------------------------
*/
void create_about_dialog ( GtkWidget ** c )
{
   GtkWidget * window;
   GtkWidget * vbox;
   GtkWidget * widget;
   int i;
   char buf[60];

   char * about_msg[] =
   {
      "DV is a FITS Data Viewer for the IRTF",
      "Developed by the NASA Infared Telescope Facility",
      "http://irtf.ifa.hawaii.edu",
      "Authors: Tony Denault denault@irtf.ifa.hawaii.edu",
      "K.M. Hawarden-Ogata",
      "Additions & Fixes by: Richard Emile Sarkis",
      "<rsarkis@astro.pas.rochester.edu>",
      NULL,
   };

   window = gtk_window_new( GTK_WINDOW_DIALOG );
   gtk_window_set_title( GTK_WINDOW (window), "About DV");
   gtk_window_set_policy( GTK_WINDOW(window), FALSE, FALSE, FALSE );
   gtk_signal_connect( GTK_OBJECT(window), "delete_event", GTK_SIGNAL_FUNC(dialog_delete_event), NULL );
   gtk_signal_connect( GTK_OBJECT(window), "destroy", GTK_SIGNAL_FUNC(dialog_delete_event), NULL );

   vbox = gtk_vbox_new( FALSE, 0);
   gtk_container_add( GTK_CONTAINER (window), vbox);

   /* Create about message as a series of labels */
   for( i=0; about_msg[i] != NULL; i++ )
   {
      widget = gtk_label_new( about_msg[i] );
      gtk_box_pack_start( GTK_BOX (vbox), widget, TRUE, FALSE, 0);
      gtk_widget_show(widget);
   }

   /* let's display the  version of GTK+ */
   sprintf( buf, "Written using Gtk+ v%d.%d.%d", gtk_major_version,
      gtk_minor_version, gtk_micro_version);
   widget = gtk_label_new( buf );
   gtk_box_pack_start( GTK_BOX (vbox), widget, TRUE, FALSE, 0);
   gtk_widget_show(widget);

   /* separator */
   widget = gtk_hseparator_new ();
   gtk_box_pack_start( GTK_BOX (vbox), widget, FALSE, FALSE, 2);
   gtk_widget_show(widget);

   /* OK button to hide dialog */
   widget = gtk_button_new_with_label( "Ok");
   gtk_box_pack_start( GTK_BOX (vbox), widget, TRUE, FALSE, 0);
   gtk_signal_connect( GTK_OBJECT (widget), "clicked",
      GTK_SIGNAL_FUNC (widget_hide_cb), (gpointer) window );
   gtk_widget_show(widget);

   gtk_widget_show( vbox );
   /* gtk_widget_show( window ); */

   /* return window handle to caller */
   *c = window;
}

/********************************************************************************/
/*  Macro dialog                                                                */
/********************************************************************************/

/*-----------------------------------------------------------------------
**  create_macro_dialog() - create dialog box for controlling macro
**    execution.
**
**    window
**      \-- vbox_top
**            |-- frame_top
**            |        \-- table
**            |              \-- f_buttons, stop, cancel, hide.
**            \-- frame_bottom
**                     \-- vbox_bottom
**                             |-- hbox
**                             |     \-- path, filemask.
**                             |-- hbox
**                             |     \-- filelist, text display.
**                             \-- hbox
**                                   \-- edit, execute, refresh, set FunName
**-----------------------------------------------------------------------
*/
void create_macro_dialog( GtkWidget ** c )
{
   int i;
   int row;
   int col;
   char buf[80];

   GtkWidget * window,
             * vbox_top,
             * frame_top,
             * table,
             * vbox_bottom,
             * menu,
             * option_menu,
             * hbox,
             * button,
             * widget;

/*----- Set up the dialog box window -----*/
   window = gtk_window_new( GTK_WINDOW_DIALOG );
   gtk_window_set_title( GTK_WINDOW (window), "Macro Dialog" );
   gtk_window_set_policy( GTK_WINDOW(window), TRUE, TRUE, TRUE );
   gtk_signal_connect( GTK_OBJECT(window), "delete_event", GTK_SIGNAL_FUNC(dialog_delete_event), NULL );
   gtk_signal_connect( GTK_OBJECT(window), "destroy", GTK_SIGNAL_FUNC(dialog_delete_event), NULL );

   vbox_top = gtk_vbox_new( FALSE, 0 );
   gtk_container_add( GTK_CONTAINER (window), vbox_top );
   gtk_widget_show( vbox_top );

   frame_top = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(frame_top), GTK_SHADOW_ETCHED_OUT );
   gtk_box_pack_start( GTK_BOX( vbox_top), frame_top, FALSE, FALSE, 0 );
   gtk_widget_show( frame_top );

   Md.frame_bottom = gtk_frame_new( NULL );
   gtk_frame_set_shadow_type( GTK_FRAME(Md.frame_bottom), GTK_SHADOW_ETCHED_OUT );
   gtk_box_pack_start( GTK_BOX( vbox_top ), Md.frame_bottom, TRUE, TRUE, 0 );
   gtk_widget_show( Md.frame_bottom );

/*----- Top half of macro dialog box -----*/
   table = gtk_table_new( TRUE, 2, 5 );
   gtk_widget_set_usize( GTK_WIDGET(table), 450, 60 );
   gtk_container_add( GTK_CONTAINER( frame_top), table );
   gtk_widget_show( table );

   /*-------------------------------
   ** function shortcut buttons
   */
   for( i=0; i< NUM_FUN_BUT; i++ )
   {
      row = i / (NUM_FUN_BUT/2); /* 2 rows of function buttons */
      col = i % (NUM_FUN_BUT/2); /* fill 1st row, then 2nd row */

      sprintf( buf, "Function %d", i );
      Md.f_buttons[i] = gtk_button_new_with_label( buf );

      gtk_table_attach_defaults( GTK_TABLE(table), Md.f_buttons[i], col, col+1, row, row+1 );
      gtk_signal_connect( GTK_OBJECT(Md.f_buttons[i]), "clicked",
                          GTK_SIGNAL_FUNC(m_fbutton_cb), (gpointer) i );
      gtk_widget_show( Md.f_buttons[i] );
   }
   col++; /* this is next free column */

   /* Stop button to stop macro execution */
   widget = gtk_button_new_with_label( "Stop" );
   gtk_signal_connect( GTK_OBJECT(widget), "clicked", GTK_SIGNAL_FUNC(m_stop_cb), NULL );
   gtk_table_attach_defaults( GTK_TABLE(table), widget, col, col+1, 0, 2 );
   gtk_widget_show( widget );
   gtk_widget_set_style( GTK_WIDGET(GTK_BIN(widget)->child), Style_Red );
   col++; /* this is next free column */

   /* Cancel button to cancel/hide entire dialog box */
   widget = gtk_button_new_with_label( "Cancel" );
   gtk_signal_connect( GTK_OBJECT(widget), "clicked", GTK_SIGNAL_FUNC(widget_hide_cb), (gpointer) window );
   gtk_table_attach_defaults( GTK_TABLE(table), widget, col, col+1, 0, 1 );
   gtk_widget_show( widget );

   /* Expand/Shrink button to toggle hide/unhide of bottom half of window */
   Md.hide_w = gtk_button_new_with_label( "Shrink" );
   gtk_table_attach_defaults( GTK_TABLE(table), Md.hide_w, col, col+1, 1, 2 );
   gtk_signal_connect( GTK_OBJECT(Md.hide_w), "clicked",
                       GTK_SIGNAL_FUNC(m_hide_cb), (gpointer) Md.frame_bottom );
   gtk_widget_show( Md.hide_w );
   Md.bottom_visible = TRUE;

/*----- bottom half of macro dialog box -----*/
   vbox_bottom = gtk_vbox_new( FALSE, 0 );
   gtk_container_add( GTK_CONTAINER(Md.frame_bottom), vbox_bottom );
   gtk_widget_show( vbox_bottom );

   /* hbox for path & mask widgets */
   hbox = gtk_hbox_new( FALSE, 0 );
   gtk_box_pack_start( GTK_BOX (vbox_bottom), hbox, FALSE, FALSE, 0 );
   gtk_widget_show( hbox );

   /*-----------------------------
   ** Path button & text entry
   */
   button = gtk_button_new_with_label("(set) Path:");
   gtk_signal_connect( GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(bfp_show),
      (gpointer)&Bfp_m_path );
   gtk_box_pack_start( GTK_BOX(hbox), button, FALSE, FALSE, 0 );
   gtk_widget_show(button);

   bfp_create_dialog( &Bfp_m_path, "Browse for Macro Path" ); /* create dialog box */
   bfp_set_ok_cb( &Bfp_m_path, m_path_bfp_ok_cb );            /* assign a cb to the OK button */

   Md.path_w = gtk_entry_new_with_max_length( 80 );
   gtk_entry_set_text( GTK_ENTRY(Md.path_w), Md.path );
   gtk_signal_connect( GTK_OBJECT(Md.path_w), "activate", 
		GTK_SIGNAL_FUNC (m_path_cb), (gpointer) NULL );
	gtk_signal_connect (GTK_OBJECT(Md.path_w), "focus-out-event",
		GTK_SIGNAL_FUNC (m_path_fo_cb), (gpointer)NULL );
   gtk_box_pack_start( GTK_BOX(hbox), Md.path_w, TRUE, TRUE, 0 );
   gtk_widget_show( Md.path_w );

   /*-----------------
   ** Filename Mask
   */
   widget = gtk_label_new( " Mask: " );
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0 );
   gtk_widget_show( widget );

   Md.file_mask_w = gtk_entry_new_with_max_length( 80 );
   gtk_widget_set_usize( GTK_WIDGET(Md.file_mask_w), 60, 26 );
   gtk_entry_set_text( GTK_ENTRY(Md.file_mask_w), Md.filemask );
   gtk_signal_connect( GTK_OBJECT(Md.file_mask_w), "activate", 
		GTK_SIGNAL_FUNC (m_filemask_cb), NULL );
	gtk_signal_connect (GTK_OBJECT(Md.file_mask_w), "focus-out-event",
		GTK_SIGNAL_FUNC (m_filemask_fo_cb), (gpointer)NULL );
   gtk_box_pack_start( GTK_BOX(hbox), Md.file_mask_w, FALSE, FALSE, 0 );
   gtk_widget_show( Md.file_mask_w );

   /*---------------------
   ** hbox - for filelist & text
   */
   hbox = gtk_hbox_new( FALSE, 0);
   gtk_box_pack_start(GTK_BOX(vbox_bottom), hbox, TRUE, TRUE, 0);
   gtk_widget_show( hbox );

/*---- Widgets (clist, scrolled_window)  to display the file list ----*/
   Md.file_list_w = gtk_clist_new( 1 );
   gtk_clist_set_shadow_type( GTK_CLIST(Md.file_list_w), GTK_SHADOW_ETCHED_OUT );
   gtk_clist_set_selection_mode( GTK_CLIST(Md.file_list_w), GTK_SELECTION_EXTENDED );
   gtk_clist_column_titles_passive( GTK_CLIST(Md.file_list_w) );
   gtk_widget_set_usize( GTK_WIDGET(Md.file_list_w), 120, 150 );

   gtk_signal_connect( GTK_OBJECT(Md.file_list_w), "select_row", (GtkSignalFunc)m_filelist_cb, NULL );
   gtk_widget_show( Md.file_list_w );

   widget = gtk_scrolled_window_new( NULL, NULL );
   gtk_container_add( GTK_CONTAINER(widget), Md.file_list_w );
   gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(widget), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS );
   gtk_container_set_border_width( GTK_CONTAINER(widget), 5 );
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0 );
   gtk_widget_show( widget );

/*---- Widgets ( text ) to display the file  ----*/
   Md.file_text_w = gtk_text_new( NULL, NULL );
   gtk_text_set_editable( GTK_TEXT(Md.file_text_w), FALSE );
   gtk_text_set_word_wrap( GTK_TEXT(Md.file_text_w), FALSE );
   gtk_box_pack_start( GTK_BOX(hbox), Md.file_text_w, TRUE, TRUE, 0 );
   gtk_widget_set_usize( GTK_WIDGET(Md.file_list_w), 120, 150 );
   gtk_widget_show( Md.file_text_w );

   /* vscrollbar */
   widget = gtk_vscrollbar_new( GTK_TEXT(Md.file_text_w)->vadj );
   gtk_box_pack_start( GTK_BOX(hbox), widget, FALSE, FALSE, 0 );
   gtk_widget_show( widget );

   /*---------------------------------
   ** hbox - execute, edit, setname.
   */
   hbox = gtk_hbox_new( TRUE, 0 );
   gtk_box_pack_start( GTK_BOX(vbox_bottom), hbox, FALSE, FALSE, 0 );
   gtk_widget_show( hbox );

   /* Execute button */
   widget = gtk_button_new_with_label( "Execute" );
   gtk_signal_connect( GTK_OBJECT(widget), "clicked", GTK_SIGNAL_FUNC(m_execute_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), widget, TRUE, TRUE, 0 );
   gtk_widget_set_style( GTK_WIDGET(GTK_BIN(widget)->child), Style_Green );
   gtk_widget_show( widget );

   /* Edit button to launch NEDIT for selected macro file */
   widget = gtk_button_new_with_label( "Edit" );
   gtk_signal_connect( GTK_OBJECT(widget), "clicked", GTK_SIGNAL_FUNC(m_edit_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), widget, TRUE, TRUE, 0 );
   gtk_widget_show( widget );

   /* Refreash button to refresh display of file list */
   widget = gtk_button_new_with_label( "Refresh" );
   gtk_signal_connect( GTK_OBJECT(widget), "clicked", GTK_SIGNAL_FUNC(m_refresh_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), widget, TRUE, TRUE, 0 );
   gtk_widget_show( widget );

   /* Set Name button -  programs the function buttons. */
   widget = gtk_button_new_with_label( "m.setbutton" );
   gtk_signal_connect( GTK_OBJECT(widget), "clicked", GTK_SIGNAL_FUNC(m_setbutton_cb), NULL );
   gtk_box_pack_start( GTK_BOX(hbox), widget, TRUE, TRUE, 0 );
   gtk_widget_show( widget );

   /* Option menu to select which function button is relabeled */
   menu = MyCreateMenuFromSelection( function_button_selection, FALSE, m_option_menu_cb, NULL );
   option_menu = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(option_menu), menu );
   gtk_box_pack_start( GTK_BOX(hbox), option_menu, FALSE, FALSE, 0 );
   gtk_widget_show( option_menu );

   /* return window handle to caller */
   *c = window;
}

/********************************************************************************/
/*  helper function for creating widget.                                        */
/********************************************************************************/

/*-----------------------------------------------------------------------
** MyCreateGtkCombo - this function help create a combo widget, it:
**    create the combo widget
**    add the list items
**    sets some option: IsEntryEditable
**-----------------------------------------------------------------------
*/
GtkWidget *  MyCreateGtkCombo(
   char * selection[],     /* null terminating array for list string entry */
   int IsEntryEditable    /* if false, sets enable flag for entry to false */
)
{
   GList * list = NULL;
   GtkWidget *combo;

   /* create list for combo using GList */
   while( *selection )
   {
      list = g_list_append( list, *selection);
      selection++;
   }

   /* create combo widget */
   combo = gtk_combo_new();

   /* add list to combo & free */
   gtk_combo_set_popdown_strings( GTK_COMBO(combo), list);

   /* set options: */
   if( !IsEntryEditable )
      gtk_entry_set_editable( GTK_ENTRY( GTK_COMBO (combo)->entry), FALSE);

   return combo;
}

/*-----------------------------------------------------------------------
**  MyCreateMenuFromSelection() - Helper function to create menus for selection[] arrays.
**     The call back menuitem_cb will get passwd the index value of the menu.
**     Each menuitem's user data is set to user_data.
**-----------------------------------------------------------------------
*/
GtkWidget *  MyCreateMenuFromSelection(
   char * selection[],        /* null terminating array for list string entry */
   int tearoff,               /* Is this a tearoff menu? */
   GtkSignalFunc menuitem_cb, /* callback on selection of menu items */
   gpointer     user_data     /* user data assigned to each menu_item */
)
{
   int inx;
   GtkWidget *menu;
   GtkWidget *menu_item;

   /* create menu item that holds the pop ups */
   menu = gtk_menu_new();

   /* Pop Up option */
   if( tearoff )
   {
      menu_item = gtk_tearoff_menu_item_new();
      gtk_menu_append( GTK_MENU(menu), menu_item );
      gtk_widget_show( menu_item);
   }

   /* create menu-entries and put them into menu */
   inx = 0;
   while( *selection )
   {
      menu_item = gtk_menu_item_new_with_label( *selection );
      gtk_menu_append( GTK_MENU(menu), menu_item );

      gtk_object_set_user_data( GTK_OBJECT(menu_item), user_data );

      if( menuitem_cb )
         gtk_signal_connect(GTK_OBJECT(menu_item), "activate",
            GTK_SIGNAL_FUNC(menuitem_cb), (gpointer) inx );

      gtk_widget_show( menu_item );

      selection++;
      inx++;
   }
   return menu;
}

/*-----------------------------------------------------------------------
**  MyCreateRadioButtons() - Creates a set of radio buttons with labels
**     packed inside a box (hbox or vbox).
**     Returns the pointer to the container (vbox or hbox).
**-----------------------------------------------------------------------
*/
GtkWidget *  MyCreateRadioButtons(
   char * selection[],               /* selection_list of radio buttons */
   GtkWidget *radio[],               /* created radio_button's reference returned here */
   int is_hbox,                      /* TRUE for hbox, else vbox */
   GtkSignalFunc radiobutton_cb      /* callback on selection of menu items */
)
{
   int inx;
   GtkWidget *box;
   GSList  * group;

   /* make homogeneous box */
   if( is_hbox )
      box = gtk_hbox_new( TRUE, 0 );
   else
      box = gtk_vbox_new( TRUE, 0 );

   group = NULL;
   inx = 0;
   while( *selection )
   {
      /* 1st call is NULL, each additional call extend the grouping */
      if( inx > 0 )
         group = gtk_radio_button_group( GTK_RADIO_BUTTON(radio[inx-1] ));

      radio[inx] = gtk_radio_button_new_with_label( group, *selection );
      gtk_signal_connect( GTK_OBJECT( radio[inx] ), "released",
         GTK_SIGNAL_FUNC(radiobutton_cb), (gpointer) inx );
      gtk_box_pack_start( GTK_BOX(box),  radio[inx] , TRUE, TRUE, 0 );
      gtk_widget_show( radio[inx] );

      selection++;
      inx++;
   }

   return box;
}

/*-----------------------------------------------------------------------
**  MyStyleSetItemColor() - Helper function to change a style.
**-----------------------------------------------------------------------
*/
void MyStyleSetItemColor(
   GdkColor   color,          /* The allocated color to be added to the style */
   char       item,           /* the item to which the color is to be applied */
                              /* 'f' = foreground; 'b' = background;          */
                              /* 'l' = light;      'd' = dark;                */
                              /* 'm' = mid;        't' = text;                */
                              /* 's' = base.                                  */
   GtkStyle * style           /* The old style - changes made to a copy       */
)
{
   int i;
   switch ( item )
   {
      case 'f':
      case 'F':
         for ( i = 0; i < 5; i++ )
            style->fg[i] = color;
         break;
      case 'b':
      case 'B':
         for ( i = 0; i < 5; i++ )
            style->bg[i] = color;
         break;
      case 'l':
      case 'L':
         for ( i = 0; i < 5; i++ )
            style->light[i] = color;
         break;
      case 'd':
      case 'D':
         for ( i = 0; i < 5; i++ )
            style->dark[i] = color;
         break;
      case 'm':
      case 'M':
         for ( i = 0; i < 5; i++ )
            style->mid[i] = color;
         break;
      case 't':
      case 'T':
         for ( i = 0; i < 5; i++ )
            style->text[i] = color;
         break;
      case 's':
      case 'S':
         for ( i = 0; i < 5; i++ )
            style->base[i] = color;
         break;
   }
}

/****************************************************************************/
/****************************************************************************/
