/********************************************************************************/
/*  CB.C - callbacks & other handlers for GUI widget and stuff                    */
/********************************************************************************/

#define EXTERN extern


/*--------------------------------------------------------
**  Non-standard include files added by the U of R NIR Lab
**--------------------------------------------------------
*/
#include "rpc_dv.h"



/*-----------------------------
**  Standard include files
**-----------------------------
*/
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <memory.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/resource.h>


#include <gtk/gtk.h>

/*-----------------------------
**  Non-standard include files
**-----------------------------
*/
#include <error_msg.h>
#include <addlib.h>
#include <dflib.h>

#include "cm.h"           /* include colormap information  */
#include "dialog.h"       /* include path dialog box */

#include "dv.h"           /* DV MAIN APPLICATION  */



/********************************************************************************/
/*  base window/application related call backs.                                   */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  base_delete_event() - base_window cb for "delete_event" signal from window manager.
**-------------------------------------------------------------------------------
*/
int base_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data )
{
   /* Return FALSE - gtk will call base_destroy_cb();
   **         TRUE - gtk will ignore delete event.
   */

   /* pop up 'are you sure you want to quit?' dialog. */
   g_print ("base_delete_event()\n");

   return(FALSE);
}

/*-------------------------------------------------------------------------------
**  base_destroy_cb() - base_window cb for "destroy" signal. Quits the applications.
**-------------------------------------------------------------------------------
*/
void base_destroy_cb( GtkWidget *widget, gpointer data )
{
   g_print ("base_destroy_cb()\n");
   gtk_main_quit();
}

/********************************************************************************/
/*  menu bar /  color map related call backs.                                   */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  Open_cb() - Shows file Open dialog box.
**-------------------------------------------------------------------------------
*/
void Open_cb( GtkWidget *widget, gpointer data )
{
   fad_show_dialog( &Fad_open );
}

/*-------------------------------------------------------------------------------
**  Save_cb() - Shows Save dialog box.
**-------------------------------------------------------------------------------
*/
void Save_cb( GtkWidget *widget, gpointer data )
{
   char path[120];
   int  index;

   if ( !INRANGE(0, Fad_save.bufinx, NUM_BUFFER-1) )
      index = 0;
   else index = Fad_save.bufinx;

   if ( Buffer[index].status == DF_EMPTY || !INRANGE(0, Buffer[index].status, 2) )
   {

      sprintf( path, "%s", Lc.dialog_path );

   }
   else
   {

      sprintf( path, "%s/", Buffer[index].directory );
      sprintf( Lc.dialog_path, "%s", path );

   }

   fad_set_path( &Fad_save, path );
   fad_set_filename( &Fad_save, Buffer[index].filename );
   fad_set_buffer( &Fad_save, index );

   fad_show_dialog( &Fad_save );
}

/*-------------------------------------------------------------------------------
**  Quit_cb() - Quit the application.
**-------------------------------------------------------------------------------
*/
void Quit_cb( GtkWidget *widget, gpointer data )
{
   cmd_execute( "quit", TRUE );
}

/*-------------------------------------------------------------------------------
**  Macro_cb() - Shows Macro dialog box.
**-------------------------------------------------------------------------------
*/
void Macro_cb( GtkWidget *widget, gpointer data )
{
   gtk_widget_show( Macro_dialog_window );
   gdk_window_raise( Macro_dialog_window->window );
}

/*-------------------------------------------------------------------------------
**  Test_cb()
**-------------------------------------------------------------------------------
*/
void Test_cb( GtkWidget *widget, gpointer data )
{
   g_print("Test_cb()\n");
}

/*-------------------------------------------------------------------------------
**  About_cb() - Shows About dialog box.
**-------------------------------------------------------------------------------
*/
void About_cb( GtkWidget *widget, gpointer data )
{
   gtk_widget_show( About_dialog_window );
   gdk_window_raise( About_dialog_window->window );
}

/*-------------------------------------------------------------------------------
**  cmap_menuitem_cb() - signal function for menu entries.
**-------------------------------------------------------------------------------
*/
void cmap_menuitem_cb ( GtkMenuItem * menuitem, gpointer data )
{
   char buf[50];

   sprintf( buf, "colormap %s ", colormap_selection[(int)data] );

   cmd_execute( buf, TRUE );
}

/********************************************************************************/
/*  some standard call backs...                                                  */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  widget_hide_cb() - dialog hide callback.
**-------------------------------------------------------------------------------
*/
void widget_hide_cb( GtkWidget *widget, gpointer data )
{
   gtk_widget_hide( (GtkWidget*)data );
}

/*-------------------------------------------------------------------------------
**  button_cb() - standard button cb. Call cmd_execute( data )
**-------------------------------------------------------------------------------
*/
void button_cb( GtkWidget *widget, gpointer data )
{
   cmd_execute( data, TRUE );
}

/*-------------------------------------------------------------------------------
**  button2_cb() - another generic pushbutton callback, adds Lc.active as parameter
**-------------------------------------------------------------------------------
*/
void button2_cb( GtkWidget *widget, gpointer data )
{
   char buf[60];

   sprintf( buf, "%s %d ", (char*)data, Lc.active);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  adj_cb() - standard adjustment cb.
**-------------------------------------------------------------------------------
*/
void adj_cb( GtkAdjustment *adj, gpointer data )
{
   char buf[50];

   sprintf( buf, "%s %f ", (char*)data, adj->value);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  entry_cb() - standard entry cb. Call cmd_execute( data )
**  entry_fo_cb() - entry focus out cb. Call the entry_cb.
**-------------------------------------------------------------------------------
*/
void entry_cb( GtkEntry *w, gpointer data )
{
   char buf[80];

   sprintf( buf, "%s %s ", (char*)data, (char*)gtk_entry_get_text(w) );

   cmd_execute( buf, TRUE );
}
void entry_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
	entry_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**  toggle_button_cb() - toggle button cb. Call cmd_execute( data ) when
**                       the widget is pressed.
**-------------------------------------------------------------------------------
*/
void toggle_button_cb( GtkToggleButton *widget, gpointer data )
{
   if( widget->active )
      cmd_execute( data, TRUE );
}

/*---------------------------------------------------------------------------
**  checkbutton_offon_cb() - generic call back of check button (using offon)
**---------------------------------------------------------------------------
*/
void checkbutton_offon_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[50];

   char *keyword = (char *) data;
   int  state = gtk_toggle_button_get_active( widget );

   sprintf( buf, "%s %s ", keyword, offon_selection[(int)state] );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  dialog_delete_event() - doen't delete dialog box, just hides it.
**-------------------------------------------------------------------------------
*/
int dialog_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data )
{
   /* Return FALSE - gtk will call base_destroy_cb();
   **         TRUE - gtk will ignore delete event.
   */
   gtk_widget_hide( GTK_WIDGET(widget) );

   return(TRUE);
}

/********************************************************************************/
/*  Main P container callbacks                                                  */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  dpyactive_cb() - catches toggle button ->button pressed event.
**-------------------------------------------------------------------------------
*/
void dpyactive_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];
   int  dpinx = (int)data;
   /* if( widget->active ) */
   {

      sprintf( buf, "Active %d ", dpinx);

      cmd_execute( buf, TRUE );
   }

   if( dpinx == (Lc.num_dpy-1))
   {
      gtk_widget_show( Dpy_dialog_window );
      gdk_window_raise( Dpy_dialog_window->window );
   }

}

/*-------------------------------------------------------------------------------
**  dpytype_menuitem_cb() - signal function for menu entries.
**-------------------------------------------------------------------------------
*/
void dpytype_menuitem_cb( GtkMenuItem * menuitem, gpointer data )
{
   char buf[50];

   sprintf( buf, "DisplayType %s %d ", dpytype_selection[(int)data], Lc.active );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  buffer_cb() - toggle button cb for buffer buttons.
**-------------------------------------------------------------------------------
*/
void buffer_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   if( widget->active )
   {

      sprintf( buf, "Buffer %c %d ", (int)data, Lc.active);

      cmd_execute( buf, TRUE );
   }
}

/*********************** displaytype IMAGE CB callbacks *************************/

/*-------------------------------------------------------------------------------
**  image_autoscale_cb() - radio button cb
**-------------------------------------------------------------------------------
*/
void image_autoscale_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "ImageAutoScale %s %d ", imageautoscale_selection[(int)data], Lc.active);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  image_zoom_cb() - standard adjustment cb.
**-------------------------------------------------------------------------------
*/
void image_zoom_cb( GtkAdjustment *adj, gpointer data )
{
   char buf[50];
   int zoom = rint(adj->value);

   sprintf( buf, "%s %d ", (char*)data, zoom );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  image_range_cb() - entry cb  for image range min & max
**-------------------------------------------------------------------------------
*/
void image_range_cb( GtkEntry *w, gpointer data )
{
   int min, max;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(ImageRangeMin_w) ), sizeof(buf));
   if( parseInt( &min, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(ImageRangeMax_w) ), sizeof(buf));
   if( parseInt( &max, buf, " ") != ERR_NONE )
      return;

   if( min < max )
   {

      sprintf( buf, "ImageRange %d %d ", min, max );

      cmd_execute( buf, TRUE );
   }
}
void image_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   image_range_cb( widget, data );
}


/********************* displaytype HISTOGRAM CB callbacks ***********************/


/*-------------------------------------------------------------------------------
**  hist_area_cb() - radio button cb
**-------------------------------------------------------------------------------
*/
void hist_area_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "HistArea %s %d ", allbox_selection[(int)data], Lc.active );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  hist_range_cb() - entry cb  for histogram range min & max
**-------------------------------------------------------------------------------
*/
void hist_range_cb( GtkEntry *w, gpointer data )
{
   int min, max;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(HistRangeMin_w) ), sizeof(buf));
   if( parseInt( &min, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(HistRangeMax_w) ), sizeof(buf));
   if( parseInt( &max, buf, " ") != ERR_NONE )
      return;

   if( min < max )
   {

      sprintf( buf, "ImageRange %d %d ", min, max );

      cmd_execute( buf, TRUE );
   }
}

void hist_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   hist_range_cb( widget, data );
}

/********************** displaytype LINECUT CB callbacks ************************/

/*-------------------------------------------------------------------------------
**  lcut_area_cb() - radio button cb
**-------------------------------------------------------------------------------
*/
void lcut_area_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "LCutArea %s %d ", allbox_selection[(int)data], Lc.active );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  lcut_autoscale_cb() - radio button cb
**-------------------------------------------------------------------------------
*/
void lcut_autoscale_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "LCutAutoScale %s %d ", imageautoscale_selection[(int)data], Lc.active);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  lcut_range_cb() - entry cb  for image range min & max
**  lcut_range_fo_cb() - entry focus out cb for image range min & max
**-------------------------------------------------------------------------------
*/
void lcut_range_cb( GtkEntry *w, gpointer data )
{
   int min, max;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(LcutRangeMin_w) ), sizeof(buf));
   if( parseInt( &min, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(LcutRangeMax_w) ), sizeof(buf));
   if( parseInt( &max, buf, " ") != ERR_NONE )
      return;

   if( min < max )
   {

      sprintf( buf, "LCutRange %d %d ", min, max );

      cmd_execute( buf, TRUE );
   }
}

void lcut_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   lcut_range_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   lcut_xy_cb()  - entry widget cb for LCutXY command.
**   lcut_xy_fo_cb()  - entry widget focus-out cb.
**-------------------------------------------------------------------------------
*/
void lcut_xy_cb( GtkEntry *w, gpointer data )
{
   int x, y;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(LcutX_w) ), sizeof(buf));
   if( parseInt( &x, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(LcutY_w) ), sizeof(buf));
   if( parseInt( &y, buf, " ") != ERR_NONE )
      return;

   sprintf( buf, "LCutXY %.10d %.10d ", x, y );

   cmd_execute( buf, TRUE );
}

void lcut_xy_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   lcut_xy_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   lcut_xarrow()  - Issues LCutXY command increment/decrement the x axis
**-------------------------------------------------------------------------------
*/
void lcut_xarrow( GtkWidget *w, gpointer data )
{
   char buf[60];

   sprintf( buf, "LCutXY %d %d ", Dpy[Lc.active].lcut_x+(int) data, Dpy[Lc.active].lcut_y);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   lcut_yarrow()  - Issues LCutXY command increment/decrement the y axis
**-------------------------------------------------------------------------------
*/
void lcut_yarrow( GtkWidget *w, gpointer data )
{
   char buf[60];

   sprintf( buf, "LCutXY %d %d ", Dpy[Lc.active].lcut_x, Dpy[Lc.active].lcut_y+(int) data);

   cmd_execute( buf, TRUE );
}

/*********************** displaytype NOISE CB callbacks *************************/

/*-------------------------------------------------------------------------------
**   noise_g1range_cb()  - Issues NoiseG1Range command.
**-------------------------------------------------------------------------------
*/
void noise_g1range_cb( GtkEntry *w, gpointer data )
{
   int min, max;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(NoiseG1RangeMin_w) ), sizeof(buf));
   if( parseInt( &min, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(NoiseG1RangeMax_w) ), sizeof(buf));
   if( parseInt( &max, buf, " ") != ERR_NONE )
      return;

   if( min < max )
   {

      sprintf( buf, "NoiseG1Range %d %d ", min, max );

      cmd_execute( buf, TRUE );
   }
}
void noise_g1range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   noise_g1range_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   noise_g2range_cb()  - Issues NoiseG2Range command.
**-------------------------------------------------------------------------------
*/
void noise_g2range_cb( GtkEntry *w, gpointer data )
{
   int min, max;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(NoiseG2RangeMin_w) ), sizeof(buf));
   if( parseInt( &min, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(NoiseG2RangeMax_w) ), sizeof(buf));
   if( parseInt( &max, buf, " ") != ERR_NONE )
      return;

   if( min < max )
   {

      sprintf( buf, "NoiseG2Range %d %d ", min, max );

      cmd_execute( buf, TRUE );
   }
}
void noise_g2range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   noise_g2range_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   noise_autoscale_cb()  - Issues NoiseAutoScale command.
**-------------------------------------------------------------------------------
*/
void noise_autoscale_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "NoiseAutoScale %s %d ", imageautoscale_selection[(int)data], Lc.active);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   noise_graphtype_cb()  - Issues NoiseGraphType command.
**-------------------------------------------------------------------------------
*/
void noise_graphtype_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "NoiseGraphType %s %d ", noisegraphtype_selection[(int)data], Lc.active );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   noise_area_cb()  - Issues NoiseArea command.
**-------------------------------------------------------------------------------
*/
void noise_area_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "NoiseArea %s %d ", allbox_selection[(int)data], Lc.active );

   cmd_execute( buf, TRUE );
}

/********************** displaytype XLINECUT CB callbacks ***********************/

/*-------------------------------------------------------------------------------
**   xcut_autoscale_cb()  - Issues XcutAutoScale command.
**-------------------------------------------------------------------------------
*/
void xcut_autoscale_cb( GtkToggleButton *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "XCutAutoScale %s %d ", imageautoscale_selection[(int)data], Lc.active);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   xcut_range_cb()  - Issues XCutRange command.
**-------------------------------------------------------------------------------
*/
void xcut_range_cb( GtkEntry *w, gpointer data )
{
   int min, max;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(XcutRangeMin_w) ), sizeof(buf));
   if( parseInt( &min, buf, " ") != ERR_NONE )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(XcutRangeMax_w) ), sizeof(buf));
   if( parseInt( &max, buf, " ") != ERR_NONE )
      return;

   if( min < max )
   {

      sprintf( buf, "XCutRange %d %d ", min, max );

      cmd_execute( buf, TRUE );
   }
}
void xcut_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   lcut_range_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   xcut_set_cb()  - Issues XCutSet command.
**   xcut_set_fo_cb() - focus out entry widget callback.
**-------------------------------------------------------------------------------
*/
void xcut_set_cb( GtkEntry *w, gpointer data )
{
   int xbeg, xend, ybeg, yend;
   char buf[60];

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(XcutBeg_w) ), sizeof(buf));
   if( (parseInt( &xbeg, buf, " ") != ERR_NONE) )
      return;
   if( (parseInt( &ybeg, NULL, " ") != ERR_NONE) )
      return;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(XcutEnd_w) ), sizeof(buf));
   if( (parseInt( &xend, buf, " ") != ERR_NONE) )
      return;
   if( (parseInt( &yend, NULL, " ") != ERR_NONE) )
      return;

   sprintf( buf, "XCutSet %d %d %d %d ", xbeg, ybeg, xend, yend );
 
   cmd_execute( buf, TRUE );
}
void xcut_set_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data )
{
   xcut_set_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   xcut_setline_cb()  - Issues XCutSet command.
**-------------------------------------------------------------------------------
*/
void xcut_setline_cb( GtkWidget *widget, gpointer data )
{
   char buf[60];
   int bufinx;

   bufinx = Dpy[Lc.active].bufinx;

   sprintf( buf, "XCutSet %d %d %d %d ", Stats[bufinx].ln_xbeg, Stats[bufinx].ln_ybeg,
                                         Stats[bufinx].ln_xend, Stats[bufinx].ln_yend);


   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   xcut_guass_cb()  - Issues XCutXGFit command.
**-------------------------------------------------------------------------------
*/
void xcut_xgfit_cb( GtkWidget *widget, gpointer data )
{
   if( Dpy[Lc.active].dpytype == DPYTYPE_XLINECUT )
   {
      Dpy[Lc.active].xcut_gfit = TRUE;
      call_dpydata_redraw( Lc.active );           /* redraw canvas */
   }
}

/********************** displaytype STATS CB callbacks **************************/

/*-------------------------------------------------------------------------------
**  stats_setsky_cb - button callback.
**-------------------------------------------------------------------------------
*/
void stats_setsky_cb( GtkWidget *widget, gpointer data )
{
   char buf[40];
   int bufid;

   bufid = 'A'+Dpy[Lc.active].bufinx;

   sprintf( buf, "StatsSetSky %c ", bufid );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  stats_fixedwh_cb() - check_button_cb
**-------------------------------------------------------------------------------
*/
void stats_fixedwh_cb( GtkWidget *widget, gpointer data )
{
   int bufid, offon;
   char buf[60];

   bufid = 'A'+Dpy[Lc.active].bufinx;

   offon = gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(widget) );

   sprintf( buf, "StatsFixedWH %c %s ", bufid, offon_selection[offon]);

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  stats_wh_entry_cb() - entry cb for fixed WH entry.
**-------------------------------------------------------------------------------
*/
void stats_wh_entry_cb( GtkWidget *widget, gpointer data )
{
   int offon,
       bufid;
   char buf[60];

   bufid = 'A'+Dpy[Lc.active].bufinx;

   offon = gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(StatsFixedWH_w) );

   sprintf( buf, "StatsFixedWH %c %s %s ", bufid, offon_selection[offon],

       gtk_entry_get_text(GTK_ENTRY(widget)) );
   cmd_execute( buf, TRUE );
}
void stats_wh_entry_fo_cb( GtkWidget *widget, GdkEventFocus * event, gpointer data )
{
	stats_wh_entry_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**  spex_subarray_cb() - set subarray command to spex.
**-------------------------------------------------------------------------------
*/
void spex_subarray_cb( GtkWidget *widget, gpointer data )
{
   int bufinx,
       ainx,
       x, y, wid, hgt;
   char buf[80];

   bufinx = Dpy[Lc.active].bufinx;
   x   = Stats[bufinx].objx;
   y   = Stats[bufinx].objy;
   wid = Stats[bufinx].objwid;
   hgt = Stats[bufinx].objhgt;
   ainx = (int)data;

   if( INRANGE(0, ainx, 2))
   {
      /* Set the Data Array  */
      spex_fix_subarray_dim( &x, &y, &wid, &hgt);

		sprintf( buf, "SpexCom Array %d %d %d %d %d ", ainx, x, y, wid, hgt);

		cmd_execute( buf, TRUE );
   }
	else
	{
      /* Set the Guide Array  */

		sprintf( buf, "SpexCom GuideBox %c %d %d %d %d ", 

		   (ainx==3?'A':'B'), 
			x, y, wid, hgt);
		cmd_execute( buf, TRUE );
	}

}

/********************************************************************************/
/*  Macro Dialog window callbacks                                               */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**   m_edit_cb() - opens the selected file in nedit.
**-------------------------------------------------------------------------------
*/
void m_edit_cb( GtkWidget *widget, gpointer data )
{
   char buf[80];

   if ( Md.filename == NULL )
   { printTextOut( CM_RED, "No file selected!\n" ); return; }

   sprintf( buf, "m.edit %s/%s", Md.path, Md.filename );


   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   m_execute_cb() - Call back for the execute button.
**        run file in buffer.
**-------------------------------------------------------------------------------
*/
void m_execute_cb( GtkWidget *widget, gpointer data )
{
   char buf[100];

   if ( Md.filename == NULL )
   { printTextOut( CM_RED, "No file selected!\n" ); return; }

   strcpy( buf, "m.execute       ");
   cat_pathname( buf+10, Md.path, Md.filename, sizeof(buf)-10 );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   m_fbutton_cb() - Callback for function buttons.
**-------------------------------------------------------------------------------
*/
void m_fbutton_cb( GtkWidget *widget, gpointer data )
{
   int inx;
   char buf[130];

   inx = (int) data;
   if( Md.fb_ok[inx] )
   {
      strcpy( buf, "m.Execute       " );
      cat_pathname( buf+10, Md.fb_path[inx], Md.fb_fname[inx], sizeof(buf)-10 );

      cmd_execute( buf, TRUE );
   }
   else
      printTextOut( CM_RED, "No macro associated with this button!\n" );
}

/*-------------------------------------------------------------------------------
**   m_filelist_cb() - User select a filename.
**-------------------------------------------------------------------------------
*/
void m_filelist_cb( GtkWidget *widget, gint row, gint col, gpointer data )
{
   char * choice[1];
   char buf[80];

   gtk_clist_get_text( GTK_CLIST(widget), row, 0, (char**) &choice );
   Md.filename = choice[0];

   sprintf( buf, "m.load %.60s ", Md.filename );


/*   printf("selected item %s (%d) \n", Md.filename, row );*/

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   m_filemask_cb() - applies the mask to the file list display.
**   m_filemask_fo_cb() - focus out call backup.
**-------------------------------------------------------------------------------
*/
void m_filemask_cb( GtkWidget *widget, gpointer data )
{
   char buf[40];

   sprintf( buf, "m.filemask %-.25s ", gtk_entry_get_text( GTK_ENTRY(Md.file_mask_w) ) );

   cmd_execute( buf, TRUE );
}
void m_filemask_fo_cb( GtkWidget *widget, GdkEventFocus * event, gpointer data )
{
	m_filemask_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**  m_hide_cb() - toggles the hiding /showing bottom macro dialog box.
**-------------------------------------------------------------------------------
*/
void m_hide_cb( GtkWidget *widget, gpointer data )
{
   if( Md.bottom_visible )
   {
      gtk_widget_hide( Md.frame_bottom );
      gtk_label_set_text( GTK_LABEL(GTK_BIN(Md.hide_w)->child), "Expand" );
      Md.bottom_visible = FALSE;
   }
   else
   {
      gtk_widget_show( Md.frame_bottom);
      gtk_label_set_text( GTK_LABEL(GTK_BIN(Md.hide_w)->child), "Shrink" );
      Md.bottom_visible = TRUE;
   }
}

/*-------------------------------------------------------------------------------
**   m_path_cb() - applies the path to the file list display.
**   m_path_fo_cb() - focus out call backup.
**-------------------------------------------------------------------------------
*/
void m_path_cb( GtkWidget *widget, gpointer data )
{
   char buf[80];

   sprintf( buf, "m.path %-.65s ", gtk_entry_get_text( GTK_ENTRY(Md.path_w) ) );

   cmd_execute( buf, TRUE );
}
void m_path_fo_cb( GtkWidget *widget, GdkEventFocus * event, gpointer data )
{
	m_path_cb( widget, data );
}

/*-------------------------------------------------------------------------------
**   m_refresh_cb() - refreshes the file list display, clears the selection, and
**                 clears the file display text area.
**-------------------------------------------------------------------------------
*/
void m_refresh_cb( GtkWidget *widget, gpointer data )
{
   cmd_execute( "m.refresh", TRUE );
}

/*-------------------------------------------------------------------------------
**  m_option_menu_cb() - we need to remember which item was selected.
**-------------------------------------------------------------------------------
*/
void m_option_menu_cb( GtkMenuItem * menuitem, gpointer data )
{
   Md.fbutton_index = (int) data;
}

/*-------------------------------------------------------------------------------
**  m_setbutton_cb() - create a shortcut button for the selected macro file.
**-------------------------------------------------------------------------------
*/
void m_setbutton_cb( GtkWidget *widget, gpointer data )
{
   char buf[130];

   if ( Md.filename == NULL )
   { printTextOut( CM_RED, "No file selected!\n" ); return; }

   sprintf( buf, "m.setButton %d %.60s %.30s ", Md.fbutton_index, Md.path, Md.filename );

   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**   m_stop_cb() - stop an executing macro.
**-------------------------------------------------------------------------------
*/
void m_stop_cb( GtkWidget *widget, gpointer data )
{
   cmd_execute( "m.stop", TRUE );
}

/*-------------------------------------------------------------------------------
**   m_clear_file() - Clear the file display.
**-------------------------------------------------------------------------------
*/
void m_clear_file( )
{
   int length;
   length = gtk_text_get_length( GTK_TEXT(Md.file_text_w) );
   gtk_text_set_point( GTK_TEXT(Md.file_text_w), length );         /* set the cursor to the end of the text */
   gtk_text_backward_delete( GTK_TEXT(Md.file_text_w), length );   /* clear the text already there */
   Md.filename = NULL;      /* De-select the file */
}

/*-------------------------------------------------------------------------------
**   m_exe_timer_func() - Reads/executes the next command.
**-------------------------------------------------------------------------------
*/
gint m_exe_timer_func( )
{
   int rc;
   static int  read_next = TRUE;
   static char command_buffer[80];

   if( Md.fp == NULL )
      return 1;
   /*
   ** Read Next command.
   */
   if( read_next )
   {
      if( NULL == fgets( command_buffer, sizeof(command_buffer)-1, Md.fp) )
      {
         /* EOF */
         fclose( Md.fp );
         Md.fp = NULL;
         printTextOut( CM_BLUE, "Macro execution Finished!\n" );
         return 0;
      }
      unpad( command_buffer, '\n' );
   }

   /*
   ** execute command in buffer
   */
   if( ERR_NONE == ( rc = cmd_execute( command_buffer, TRUE )) )
   {
      /* install another timer */
      unsigned long time_interval = ( read_next ? 200 : 500 );
      Md.exe_timerid = gtk_timeout_add( time_interval, m_exe_timer_func, NULL );
   }
   else
   {
      printTextOut( CM_RED, "Aborting Macro execute due to error!\n");
      cmd_execute( "M.Stop", TRUE );
   }

   read_next = TRUE;   /* read next instruction */
   return FALSE;      /* This is FALSE because we need to adjust the time intervals */

}

/********************************************************************************/
/*  Math widgets callbacks.                                                     */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  math_equ_cb - issue equation command.
**-------------------------------------------------------------------------------
*/
void math_equ_cb( GtkWidget *widget, gpointer data )
{
   char buf[40];
   GtkWidget * entry = (GtkWidget *)data;

   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(entry) ), sizeof(buf));
   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  math_copy_from_cb()
**  math_copy_to_cb()   - we need to remember which item was selected.
**  math_copy_button_cb - issues copy command.
**-------------------------------------------------------------------------------
*/
void math_copy_from_cb( GtkMenuItem * menuitem, gpointer data )    /* option menu item call back */
{
   Math_copy_from_bufinx = (int) data;
}
void math_copy_to_cb( GtkMenuItem * menuitem, gpointer data )     /* option menu item call back */
{
   Math_copy_to_bufinx = (int) data;
}
void math_copy_button_cb( GtkWidget *widget, gpointer data )
{
   char buf[60];
   sprintf( buf, "copy %c to %c ", 'A'+Math_copy_from_bufinx, 'A'+Math_copy_to_bufinx);
   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
** math_clear_bufinx_cb()
** math_clear_button_cb()
**-------------------------------------------------------------------------------
*/
void math_clear_bufinx_cb( GtkMenuItem * menuitem, gpointer data )
{
   Math_clear_bufinx = (int) data;
}
void math_clear_button_cb( GtkWidget *widget, gpointer data )
{
   char buf[60];
   sprintf( buf, "Clear %c  ", 'A'+Math_clear_bufinx );
   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  math_rotate_option_menu_cb() - we need to remember which item was selected.
**-------------------------------------------------------------------------------
*/
void math_rotate_bufinx_cb( GtkMenuItem * menuitem, gpointer data )
{
   Math_rotate_bufinx = (int) data;
}
void math_rotate_ops_cb( GtkMenuItem * menuitem, gpointer data )
{
   Math_rotate_ops = (int) data;
}
void math_rotate_button_cb( GtkWidget *widget, gpointer data )
{
   char buf[60];
   sprintf( buf, "Rotate %c %s ", 'A'+Math_rotate_bufinx, rotate_selection[Math_rotate_ops]);
   cmd_execute( buf, TRUE );
}

/********************************************************************************/
/*  Setup widgets callbacks.                                                    */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  printertype_cb() - call back for for menu entries.
**-------------------------------------------------------------------------------
*/
void printertype_cb ( GtkMenuItem * menuitem, gpointer data )
{
   char buf[50];
   sprintf( buf, "PrinterType %s ", printer_selection[(int)data] );
   cmd_execute( buf, TRUE );
}

/********************************************************************************/
/*  TCS Offset widgets callbacks.                                               */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  offset_defaults_cb() - set the angle and plate scale to the selected default.
**-------------------------------------------------------------------------------
*/
void offset_defaults_cb( GtkWidget *widget, gpointer data )
{
   switch ( (int) data )
   {
      case 1:
         /*set defaults for cshell */
         Lc.offset_angle      = COORD_CSHELL_ANGLE;
         Lc.offset_platescale = COORD_CSHELL_PSCALE;
         Lc.usefitsanglescale = FALSE;
         break;

      case 2:
         /*set defaults for nsfcam */
         Lc.offset_angle      = COORD_NSFCAM_ANGLE;
         Lc.offset_platescale = COORD_NSFCAM_PSCALE;
         Lc.usefitsanglescale = FALSE;
         break;

      case 3:
      default:
         /*set defaults for spex */
         Lc.offset_angle      = COORD_SPEX_ANGLE;
         Lc.offset_platescale = COORD_SPEX_PSCALE;
         Lc.usefitsanglescale = TRUE;
         break;
   }

   cal_offset_radec( );
   update_offset_widgets( );
}

/********************************************************************************/
/*  Cli widgets callbacks.                                                      */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  command_entry_cb() - Feeds text input to cmd_exeute.
**-------------------------------------------------------------------------------
*/
void command_entry_cb( GtkWidget *widget, gpointer data )
{
   char buf[128];

   /* copy command and execute */
   strxcpy( buf, gtk_entry_get_text( GTK_ENTRY(widget)), sizeof(buf));
   cmd_execute( buf, TRUE );

   /* clear the entry widget */
   gtk_entry_set_text( GTK_ENTRY(widget), "");
}

/*-------------------------------------------------------------------------------
**  printTextOut() - display a formated string to the drawing area.
**    style - specifies the foreground color. Lets use:
**        CM_BLACK      - commands.
**        CM_BLUE       - application messages.
**        CM_RED        - application warning/error messages.
**        CM_GRAY       - Very minor messages printed during execution.
**-------------------------------------------------------------------------------
*/
void printTextOut( int fg, char *fmt, ...)
{
   int n;
   char buf[256];
   char tex[256];
   va_list argptr;

   va_start( argptr, fmt);
   vsprintf( buf, fmt, argptr);
   va_end( argptr );

   /* remove some text if buffer is > 5120 */
   if( (n = gtk_text_get_length( GTK_TEXT(TextOut_w))) > 5120 )
   {
      gtk_text_freeze( GTK_TEXT(TextOut_w));

      gtk_text_set_point(GTK_TEXT(TextOut_w), 0);          /* set cursor to beginning of file */
      gtk_text_forward_delete(GTK_TEXT(TextOut_w), 1024);  /* delete some text */
      gtk_text_set_point(GTK_TEXT(TextOut_w), n-1024);     /* reposition cursor to end of text */

      gtk_text_thaw( GTK_TEXT(TextOut_w));
   }

   /* insert text outside of thaw() will also repostion scrollbar to display text */
   gtk_text_insert( GTK_TEXT(TextOut_w), NULL, &CM.colors[fg], NULL, buf, -1); /* insert text */

   /* update single line feedback widget on main screen */
   n = strlen( buf );
   strxcpy( tex, buf, n );
   /* gtk_widget_set_style( GTK_WIDGET(LineText_w), style ); */
   gtk_label_set_text( GTK_LABEL(LineText_w), tex );
}

/********************************************************************************/
/*         Call Backs related to IO events                                      */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  socket_accept_connection() - This routine services request
**     for connections on a socket. It accept the connection,
**     reads and executes commands from the connection.
**-------------------------------------------------------------------------------
*/
void socket_accept_connection( gpointer data, int fd, GdkInputCondition ic )
{
   int  rc;
   char buf[SOCKET_MSG_LEN];
   /*
   **  accept connection
   */
   if( -1 == (Lc.connect_fd = accept( fd, (struct sockaddr*) 0, (int *) 0)) )
      return;
   /*
   **  Read and process data.
   */
   while( sock_read_data( Lc.connect_fd, buf, (long)SOCKET_MSG_LEN, FALSE, 10) > 0 )
   {
      rc = cmd_execute( buf, TRUE );
   }
   /*
   **  Close connection.
   */
   close( Lc.connect_fd );

   /*
   ** execute stack instructions
   */
   while( Lc.stack_inx > 0 )
   {
      char *cptr;

      Lc.stack_inx--;
      cptr = Lc.cmd_stack[Lc.stack_inx];

      rc = cmd_execute( cptr, TRUE );
      free( cptr );
   }
}

/*--------------------------------------------------------------------
**  dv_command_1_svc() - This routine services request for connections 
**  from RPC. 
**
**  Richard Emile Sarkis, 4/6/2001
*/

int * dv_command_1_svc(char **dv_command_string, struct svc_req *rqstp)
{
        static int  result;

	if (dv_command_string != NULL) {
         	result = cmd_execute( *dv_command_string, TRUE );
        }

        return &result;
}

/* End U of R NIR Code*/

/*---------------------------------------------------------------
**  handle_rpc() - This routine services pending requests to RPC.
**  It is called by gtk_timeout_add.
**
**  Richard Emile Sarkis, 4/6/2001
*/

int handle_rpc(gpointer data)
{
     int ret;
     struct rlimit lim;
     struct timeval tv;
     fd_set tmp_rd_set = svc_fdset;

     tv.tv_usec = 0; tv.tv_sec = 0; /* we are polling, don't wait */
     getrlimit (RLIMIT_NOFILE, &lim);
     ret = select(lim.rlim_cur, &tmp_rd_set, NULL, NULL, &tv);
     if (ret>0)
         svc_getreqset(&tmp_rd_set); /* process pending RPCs */
     return 1; /* always active */
}

/* End U of R NIR Code*/

/********************************************************************************/
/*         Update Functions                                                     */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  update_display_widgets () - update all user visible application widgets
**-------------------------------------------------------------------------------
*/
void update_display_widgets( void )
{
   /* Update Cmap_option_w */
   /* gtk_option_menu_set_history( Cmap_option_w, Lc.view );  */

   /* we need to figure out which page is displayed on the notebook */
   /* and call the approipriate function. For now we just call: */

   update_displayOptions_widgets( );
   update_setup_widgets( );
   update_offset_widgets( );
}

/*-------------------------------------------------------------------------------
**  update_displayOptions_widgets () - update all widgets related to
**     display configurations.
**-------------------------------------------------------------------------------
*/
void update_displayOptions_widgets( void )
{
   int  i;
   struct dpy_t * dp;

   dp = &Dpy[Lc.active];

   /* Dpyactive_w[] */
   for( i=0; i<Lc.num_dpy; i++ )
   {
     if (Lc.active == i)
        gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(Dpyactive_w[i]), TRUE);
     else
        gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(Dpyactive_w[i]), FALSE);
   }

   /* Dpytype_w */
   gtk_option_menu_set_history( GTK_OPTION_MENU(Dpytype_w), dp->dpytype );

   /* Dpybuf_w[] */
   for( i=0; i<NUM_BUFFER; i++ )
     gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(Dpybuf_w[i]),
        (i==dp->bufinx?TRUE:FALSE));

   /* Set display parameters notebook */
   gtk_notebook_set_page( GTK_NOTEBOOK(Notebook_dpy_w), Dpy[Lc.active].dpytype );

   /* update the display parameters widget for the curretn dpytype */
   switch( Dpy[Lc.active].dpytype )
   {
      case DPYTYPE_IMAGE:
         update_dpytype_image_widgets( &Dpy[Lc.active] );
         break;
      case DPYTYPE_HISTOGRAM:
         update_dpytype_histogram_widgets( &Dpy[Lc.active] );
         break;
      case DPYTYPE_LINECUT:
         update_dpytype_linecut_widgets( &Dpy[Lc.active] );
         break;
      case DPYTYPE_NOISE:
         update_dpytype_noise_widgets( &Dpy[Lc.active] );
         break;
      case DPYTYPE_XLINECUT:
         update_dpytype_xlinecut_widgets( &Dpy[Lc.active] );
         break;
      case DPYTYPE_POINTER:
         update_dpytype_pointer_widgets( &Dpy[Lc.active] );
         break;
      case DPYTYPE_STATS:
         update_dpytype_stats_widgets( &Dpy[Lc.active] );
         break;
   }
}

/*-------------------------------------------------------------------------------
**  update_dpytype_image_widgets () - update all widgets related to
**     DisplayType DPYTYPE_IMAGE
**-------------------------------------------------------------------------------
*/
void update_dpytype_image_widgets( struct dpy_t *dp )
{
   char buf[60];

   /* Image AutoScale */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(ImageAutoScale_w[dp->image_autoscale]), TRUE);

   /* Image Zoom */
   gtk_adjustment_set_value( GTK_ADJUSTMENT(ImageZoom_w), dp->image_zoom );

   /* Image Range: Min & Max  */
   sprintf( buf, "%2.0f", dp->image_min );
   gtk_entry_set_text( GTK_ENTRY(ImageRangeMin_w), buf );

   sprintf( buf, "%2.0f", dp->image_max );
   gtk_entry_set_text( GTK_ENTRY(ImageRangeMax_w), buf );
}

/*-------------------------------------------------------------------------------
**  update_dpytype_histogram_widgets () - update all widgets related to
**     DisplayType DPYTYPE_HISTOGRAM
**-------------------------------------------------------------------------------
*/
void update_dpytype_histogram_widgets( struct dpy_t *dp )
{
   char buf[60];

   /* Histogram Range: Min & Max  */
   sprintf( buf, "%2.0f", dp->image_min );
   gtk_entry_set_text( GTK_ENTRY(HistRangeMin_w), buf );

   sprintf( buf, "%2.0f", dp->image_max );
   gtk_entry_set_text( GTK_ENTRY(HistRangeMax_w), buf );

   /* Histogram Bins  */
   sprintf( buf, "%2.0d", dp->hist_bin );
   gtk_entry_set_text( GTK_ENTRY(HistBin_w), buf );

   /* Histogram Area */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(HistArea_w[dp->hist_area]), TRUE);
}

/*-------------------------------------------------------------------------------
**  update_dpytype_linecut_widgets () - update all widgets related to
**     DisplayType DPYTYPE_LINECUT
**-------------------------------------------------------------------------------
*/
void update_dpytype_linecut_widgets( struct dpy_t *dp )
{
   char buf[60];

   /* Linecut AutoScale */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(LcutAutoScale_w[dp->lcut_autoscale]), TRUE);

   /* Linecut Range: Min & Max  */
   sprintf( buf, "%2.0f", dp->lcut_min );
   gtk_entry_set_text( GTK_ENTRY(LcutRangeMin_w), buf );

   sprintf( buf, "%2.0f", dp->lcut_max );
   gtk_entry_set_text( GTK_ENTRY(LcutRangeMax_w), buf );

   /* Linecut Axes: X & Y  */
   sprintf( buf, "%d", dp->lcut_x );
   gtk_entry_set_text( GTK_ENTRY(LcutX_w), buf );

   sprintf( buf, "%d", dp->lcut_y );
   gtk_entry_set_text( GTK_ENTRY(LcutY_w), buf );

   /* Linecut Area */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(LcutArea_w[dp->lcut_area]), TRUE);
}

/*-------------------------------------------------------------------------------
**  update_dpytype_noise_widgets () - update all widgets related to
**     DisplayType DPYTYPE_NOISE
**-------------------------------------------------------------------------------
*/
void update_dpytype_noise_widgets( struct dpy_t *dp )
{
   char buf[60];

    /* Noise Mod  */
   sprintf( buf, "%d", dp->noise_mod );
   gtk_entry_set_text( GTK_ENTRY(NoiseMod_w), buf );

   /* Noise GraphType */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(NoiseGraphType_w[dp->noise_graph_type]), TRUE);

   /* Noise AutoScale */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(NoiseAutoScale_w[dp->noise_autoscale]), TRUE);

   /* Noise Area */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(NoiseArea_w[dp->noise_area]), TRUE);

   /* Noise Graph 1 Range: Min & Max  */
   sprintf( buf, "%2.0f", dp->noise_g1_min );
   gtk_entry_set_text( GTK_ENTRY(NoiseG1RangeMin_w), buf );

   sprintf( buf, "%2.0f", dp->noise_g1_max );
   gtk_entry_set_text( GTK_ENTRY(NoiseG1RangeMax_w), buf );

    /* Noise Graph 2 Range: Min & Max  */
   sprintf( buf, "%2.0f", dp->noise_g2_min );
   gtk_entry_set_text( GTK_ENTRY(NoiseG2RangeMin_w), buf );

   sprintf( buf, "%2.0f", dp->noise_g2_max );
   gtk_entry_set_text( GTK_ENTRY(NoiseG2RangeMax_w), buf );
}

/*-------------------------------------------------------------------------------
**  update_dpytype_pointer_widgets () - update all widgets related to
**     DisplayType DPYTYPE_POINTER
**-------------------------------------------------------------------------------
*/
void update_dpytype_pointer_widgets( struct dpy_t *dp )
{
   char buf[60];

   /* Pointer Image Size  */
   sprintf( buf, "%d", dp->pt_image_size );
   gtk_entry_set_text( GTK_ENTRY(PtImageSize_w), buf );
}

/*-------------------------------------------------------------------------------
**  update_dpytype_xlinecut_widgets () - update all widgets related to
**     DisplayType DPYTYPE_XLINECUT
**-------------------------------------------------------------------------------
*/
void update_dpytype_xlinecut_widgets( struct dpy_t *dp )
{
   char buf[60];

   /* XLinecut AutoScale */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(XcutAutoScale_w[dp->xcut_autoscale]), TRUE);

   /* XLinecut Range: Min & Max  */
   sprintf( buf, "%2.0f", dp->xcut_min );
   gtk_entry_set_text( GTK_ENTRY(XcutRangeMin_w), buf );

   sprintf( buf, "%2.0f", dp->xcut_max );
   gtk_entry_set_text( GTK_ENTRY(XcutRangeMax_w), buf );

   /* XLinecut Line beginning and end points  */
   sprintf( buf, "%d %d", dp->xcut_xbeg, dp->xcut_ybeg );
   gtk_entry_set_text( GTK_ENTRY(XcutBeg_w), buf );

   sprintf( buf, "%d %d", dp->xcut_xend, dp->xcut_yend );
   gtk_entry_set_text( GTK_ENTRY(XcutEnd_w), buf );
}

/*----------------------------------------------------------------
**  update_dpytype_stats_widgets () - update all widgets related to
**     DisplayType DPYTYPE_STATS
**----------------------------------------------------------------
*/
void update_dpytype_stats_widgets( struct dpy_t *dp )
{
   char buf[60];

   /* FixedWH toggle */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(StatsFixedWH_w), Stats[dp->bufinx].fixedWH );

   /* FixedWH entry */
   sprintf( buf, "%d %d", Stats[dp->bufinx].objwid, Stats[dp->bufinx].objhgt);
   gtk_entry_set_text( GTK_ENTRY(StatsWHentry_w), buf );
}

/*-------------------------------------------------------------------------------
**  update_setup_widgets () - update all widgets related to setup notebook.
**-------------------------------------------------------------------------------
*/
void update_setup_widgets ( void )
{
   char buf[80];

   /* DivByDivisor */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(DivByDivisor_w), Lc.divbydivisor);

   /* TSC Hostname */
   gtk_entry_set_text( GTK_ENTRY(TCShostname_w), Lc.tcshostname );

   /* Printer */
   gtk_entry_set_text( GTK_ENTRY(Printer_w), Lc.printer );

   /* PrinterType */
   gtk_option_menu_set_history( GTK_OPTION_MENU(PrinterType_w), Lc.printertype );

   /* PrintToFile */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(PrintToFile_w), Lc.printtofile);

   /* Path */
   gtk_entry_set_text( GTK_ENTRY(Path_w), Lc.path );

   if( Lc.dvport )
		sprintf( buf, "Dv socket port is %d ", Lc.dvport);
	else
		strcpy( buf, "Dv socket was not initialized.");
   gtk_label_set_text( GTK_LABEL(Dvport_w), buf );

}

/*-------------------------------------------------------------------------------
**  void update_offset_widgets() - refresh tcs offset widgets
**-------------------------------------------------------------------------------
*/
void update_offset_widgets( void )
{
   char  buf[40];

   /* Use_FITS_Angle&Scale */
   gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(Use_FITS_Angle_Scale_w), Lc.usefitsanglescale);

   /* Position Angle */
   sprintf( buf, " %6.2f ", Lc.offset_angle);
   gtk_entry_set_text( GTK_ENTRY(Offset_angle_w), buf );

   /* Plate Scale  */
   sprintf( buf, " %3.2f ", Lc.offset_platescale);
   gtk_entry_set_text( GTK_ENTRY(Offset_platescale_w), buf );

   /* Update Beg X,Y */
   sprintf( buf, " %2.0f %2.0f ", Lc.offset_beg_x, Lc.offset_beg_y);
   gtk_entry_set_text( GTK_ENTRY(Offset_beg_xy_w), buf );

   /* Update End X,Y */
   sprintf( buf, " %2.0f %2.0f ", Lc.offset_end_x, Lc.offset_end_y);
   gtk_entry_set_text( GTK_ENTRY(Offset_end_xy_w), buf );

   /* Update RA & DEC coordinates */
   sprintf( buf, " %2.2f, %2.2f ", Lc.offset_ra, Lc.offset_dec);
   gtk_label_set_text( GTK_LABEL(Offset_radec_w), buf );
}

/****************************************************************************/
/*  File Access Dialog related                                              */
/****************************************************************************/

/*----------------------------------------------------------------------------
**  fad_show() - button cb to show a fileAccessDialog dialog
**               Pass the fad struct address for the user_data.
**----------------------------------------------------------------------------
*/
void fad_show( GtkWidget *widget, gpointer data )
{
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   gtk_widget_show( fad->dialog_window );
   gdk_window_raise( fad->dialog_window->window );
}

/*-------------------------------------------------------------------------------
**  open_fad_ok_cb() - opens the selected file in the chosen buffer.
**-------------------------------------------------------------------------------
*/
void open_fad_ok_cb( GtkWidget *widget, gpointer data )
{
   char buf[200];
   char path[150];
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   cat_pathname( path, fad->dirlist.path, fad->filename, sizeof(path) );
   sprintf( buf, "Read  %s %s ", path, buffer_selection[fad->bufinx] );
   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  open_fad_movieread_cb() - opens the selected file in the chosen buffer.
**-------------------------------------------------------------------------------
*/
void open_fad_movieread_cb( GtkWidget *widget, gpointer data )
{
   char buf[200];
   char path[150];
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   cat_pathname( path, fad->dirlist.path, fad->filename, sizeof(path) );
   sprintf( buf, "ReadMovie  %s %s ", path, buffer_selection[fad->bufinx] );
   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  open_fad_movieshow_cb() - opens the selected file in the chosen buffer.
**-------------------------------------------------------------------------------
*/
void open_fad_movieshow_cb( GtkWidget *widget, gpointer data )
{
   char buf[200];
   char path[150];
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   cat_pathname( path, fad->dirlist.path, fad->filename, sizeof(path) );
   sprintf( buf, "ShowMovie  %s %s ", path, buffer_selection[fad->bufinx] );
   cmd_execute( buf, TRUE );
}

/*-------------------------------------------------------------------------------
**  save_fad_ok_cb() - saves the selected buffer as the chosen file.
**-------------------------------------------------------------------------------
*/
void save_fad_ok_cb( GtkWidget *widget, gpointer data )
{
   char buf[200];
   char path[150];
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   cat_pathname( path, fad->dirlist.path, gtk_entry_get_text( GTK_ENTRY(fad->file_entry) ), sizeof(path) );
   sprintf( buf, "Save  %s %s ", path, buffer_selection[fad->bufinx] );
   /*   printf("save_fad_ok_cb: [%s]\n", buf); */
   if( cmd_execute( buf, TRUE ) == ERR_NONE )
      fad_hide_dialog( fad );
}

/*-------------------------------------------------------------------------------
**  save_fad_buffer_cb() - Stores the buffer index for FileSave Dialog Box.
**-------------------------------------------------------------------------------
*/
void save_fad_buffer_cb( GtkMenuItem * menuitem, gpointer data )
{

   char path[120];
   int index = (int) data;

   if ( !Buffer[index].status || !INRANGE(0, Buffer[index].status, 2) )
   {
      sprintf( path, "%s", Lc.dialog_path );
   }
   else
   {
      sprintf( path, "%s/", Buffer[index].directory );
      sprintf( Lc.dialog_path, "%s", path );
   }

   fad_set_path( &Fad_save, path );
   fad_set_filename( &Fad_save, Buffer[index].filename );
   fad_set_buffer( &Fad_save, index );
}

/*-------------------------------------------------------------------------------
**  save_update_dialog() - updates the buffer information in the save dialog box.
**-------------------------------------------------------------------------------
*/
void save_update_dialog( int bufinx )
{
   if ( bufinx != Fad_save.bufinx )
      return;

   if ( Buffer[bufinx].status == DF_EMPTY )
   {
      fad_set_path( &Fad_save, Lc.path );
      fad_set_filename( &Fad_save, "" );
   }
   else
   {
      fad_set_path( &Fad_save, Buffer[bufinx].directory );
      fad_set_filename( &Fad_save, Buffer[bufinx].filename );
   }
}

/****************************************************************************/
/*  Browse for Path related                                                 */
/****************************************************************************/

/*----------------------------------------------------------------------------
**  bfp_show() - button cb to show a browseForPath dialog
**               Pass the bfp struct address for the user_data.
**----------------------------------------------------------------------------
*/
void bfp_show( GtkWidget *widget, gpointer data )
{
   struct browseForPath_t *bfp = (struct browseForPath_t *)data;

   gtk_widget_show( bfp->dialog_window );
   gdk_window_raise( bfp->dialog_window->window );
}

/*-----------------------------------------------------------------------
**  path_bfp_ok_cb() - callback for (data) path's OK button from bfp dialog.
**                     execute the path command with new path.
**-----------------------------------------------------------------------
*/
void path_bfp_ok_cb( GtkWidget *widget, gpointer data )
{
   char buf[256];
   struct browseForPath_t *bfp = (struct browseForPath_t *)data;

   strcpy( buf, "Path   ");
   strxcpy( &buf[5], bfp->dirlist.path, sizeof(buf)-5);
   if( cmd_execute( buf, TRUE ) == ERR_NONE )
      bfp_hide_dialog( bfp );
}

/*-----------------------------------------------------------------------
**  m_path_bfp_ok_cb() - callback for (data) path's OK button from bfp dialog.
**                     execute the path command with new path.
**-----------------------------------------------------------------------
*/
void m_path_bfp_ok_cb( GtkWidget *widget, gpointer data )
{
   char buf[256];
   struct browseForPath_t *bfp = (struct browseForPath_t *)data;

   strcpy( buf, "m.path   ");
   strxcpy( &buf[7], bfp->dirlist.path, sizeof(buf)-7);
   if( cmd_execute( buf, TRUE ) == ERR_NONE )
      bfp_hide_dialog( bfp );
}

/********************************************************************************/
/*                   helper function for updating widgets                       */
/********************************************************************************/

/*-------------------------------------------------------------------------------
**  MyUpdateComboWidget() - Helper funtion to update a combo widget's
**     text entry field.
**-------------------------------------------------------------------------------
*/
void MyUpdateComboWidget( GtkWidget *widget, int handler_id, char * text )
{
   gtk_signal_handler_block( GTK_OBJECT(GTK_COMBO(widget)->entry), handler_id );
   gtk_entry_set_text( GTK_ENTRY(GTK_COMBO(widget)->entry), text );
   gtk_signal_handler_unblock( GTK_OBJECT(GTK_COMBO(widget)->entry), handler_id );
}

/*-------------------------------------------------------------------------------
**  update_file_list( ) - Updates the file list.
**-------------------------------------------------------------------------------
*/
int update_file_list( int isDir, char *cdir, char *fmask, GtkWidget *widget )
{
#define MAX_FILE_LIST 500

   int l, rc, nfile;

   DIR * dirp;
   struct dirent * dp;
   struct stat sbuf;
   char **avlist;

   char workingdir[100];
   char listdir[100];
   char pathname[140];

   avlist = (char **) malloc( MAX_FILE_LIST * sizeof (char *));
   nfile = 0;
   rc = ERR_NONE;

   /*  read current directory and save in workingdir[] */
   getcwd( workingdir, sizeof(workingdir) );

   /* change to cdir */
   if( strlen( cdir ) >= sizeof(listdir)-1 )
      { rc = ERR_INVALID_DIR; goto done; }
   strxcpy( listdir, cdir, sizeof(listdir));
   unpad( listdir, ' ');
   if( chdir( listdir ) < 0 )
      { rc = ERR_INVALID_DIR; goto done; }

   getcwd( listdir, sizeof(listdir));
   /*
   **  Read directory and update list
   */
   if( NULL != (dirp = opendir(listdir)) )
   {
      for( dp = readdir(dirp); dp != NULL; dp = readdir(dirp))
      {
         if( matchname( fmask, dp->d_name))
         {
            cat_pathname( pathname, listdir, dp->d_name, sizeof(pathname));
            if( stat(pathname, &sbuf) >= 0 )
            {
               if( ( isDir ? S_ISDIR(sbuf.st_mode) :  S_ISREG(sbuf.st_mode))
                   && (nfile < MAX_FILE_LIST)
                   && (dp->d_name[0] != '.'))
               {
                  l = strlen(dp->d_name);
                  avlist[nfile] = malloc( (unsigned) l+1);
                  memcpy( avlist[nfile], dp->d_name, l+1);
                  nfile++;
                }
             }
         }
      }
      closedir( dirp );
   }

   /* Sort the list */
   if( nfile > 0 )
      qsort( (char *) avlist, nfile, sizeof(char*), (__const void *) qsort_comp_string );

   /* Delete current contents of list */
   gtk_clist_freeze( GTK_CLIST(widget) );
   gtk_clist_clear( GTK_CLIST(widget) );

   /* Add All items to list */
   {
      for( l=0; l<nfile; l++ )
      {
         char *entry[1];

         entry[0] = avlist[l];
         gtk_clist_append( GTK_CLIST(widget), entry );
         gtk_clist_set_selectable( GTK_CLIST(widget), l, TRUE );
      }
   }
   gtk_clist_thaw( GTK_CLIST(widget) );

done:
   for( l=0; l<nfile; l++)
      free( (char*) avlist[l]);
   free( (char*) avlist);

   /* change back to original working directory */
   chdir( workingdir );
   return rc;
}

/****************************************************************************/
/****************************************************************************/
