/********************************************************************************/
/*  COMMAND.C - Command processer for application.                              */
/********************************************************************************/

#define EXTERN extern

/*--------------------------------------------------------
**  Non-standard include files added by the U of R NIR Lab
**--------------------------------------------------------
*/
#include "rpc_dv.h"


/*-------------------------
**  Standard include files
**-------------------------
*/
#include <sys/stat.h>
#include <time.h>
#include <sys/types.h>
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <rpc/pmap_clnt.h>
#include <rpc/rpc.h>

#include <gtk/gtk.h>

/*------------------------------
**  Non-standard include files
**------------------------------
*/
#include <error_msg.h>
#include <addlib.h>
#include <dflib.h>

#include "cm.h"           /* include colormap information  */
#include "dialog.h"       /* include misc dialog box */

#include "dv.h"           /* DV MAIN APPLICATION  */

/*--------------------------------------------------------------------------------
**  Table of commands & ID numbers.
*/
struct PARSE_TABLE
{
  char * kw;          /* The opcode string  */
  int (* pfi)();      /* pfi is pointer to function returning an integer */
};

struct PARSE_TABLE parse_table[] =
{
   { "Active",                do_active                  },
   { "BoxCentroid",           do_boxcentroid             },
   { "BoxCopy",               do_boxcopy                 },
   { "BoxPeak",               do_boxpeak                 },
   { "BoxScale",              do_boxscale                },
   { "BoxZoom",               do_boxzoom                 },
   { "Buffer",                do_buffer                  },
   { "BufInfo",               do_bufinfo                 },
   { "Clear",                 do_clear                   },
   { "CM.center",             do_cmCenter                },
   { "CM.width",              do_cmWidth                 },
   { "Colormap",              do_colormap                },
   { "Colormap.Inverse",      do_colormap_inverse        },
   { "Copy",                  do_copy                    },
   { "DisplayType",           do_displaytype             },
   { "DivByDivisor",          do_divbydivisor            },
   { "DrawBox",               do_drawbox                 },
   { "DrawLine",              do_drawline                },
   { "Echo",                  do_echo                    },
   { "Filter1",               do_filter1,                },
   { "Filter2",               do_filter2,                },
   { "FullImage",             do_fullimage               },
   { "HistArea",              do_histarea                },
   { "HistBin",               do_histbin                 },
   { "ImageAutoScale",        do_imageautoscale          },
   { "ImageRange",            do_imagerange              },
   { "ImageScale1P",          do_imagescale1p            },
   { "ImageZoom",             do_imagezoom               },
   { "LCutArea",              do_lcutarea                },
   { "LCutAutoScale",         do_lcutautoscale           },
   { "LCutRange",             do_lcutrange               },
   { "LCutXY",                do_lcutxy                  },
   { "M.Edit",                do_m_edit                  },
   { "M.Execute",             do_m_execute               },
   { "M.FileMask",            do_m_filemask              },
   { "M.Load",                do_m_load                  },
   { "M.Path",                do_m_path                  },
   { "M.Refresh",             do_m_refresh               },
   { "M.SetButton",           do_m_setbutton             },
   { "M.Stop",                do_m_stop                  },
   { "NoiseArea",             do_noisearea               },
   { "NoiseAutoScale",        do_noiseautoscale          },
   { "NoiseG1Range",          do_noiseg1range            },
   { "NoiseG2Range",          do_noiseg2range            },
   { "NoiseGraphType",        do_noisegraphtype          },
   { "NoiseMod",              do_noisemod                },
   { "Offset.Angle",          do_offset_angle            },
   { "Offset.BegXY",          do_offset_begxy            },
   { "Offset.EndXY",          do_offset_endxy            },
   { "Offset.Platescale",     do_offset_platescale       },
   { "Offset.TCS",            do_offset_tcs,             },
   { "OffsetAB.TCS",          do_offset_tcsab,           },
   { "Path",                  do_path                    },
   { "Print",                 do_print                   },
   { "Printer",               do_printer                 },
   { "PrinterType",           do_printertype             },
   { "PrintToFile",           do_printtofile             },
   { "PtImageSize",           do_ptimagesize             },
   { "Push",                  do_push                    },
   { "Quit",                  do_quit                    },
   { "Read",                  do_read                    },
   { "ReadFile",              do_readfile                },
   { "ReadMovie",             do_readmovie               },
   { "ReadSock",              do_readsock                },
   { "Rotate",                do_rotate                  },
   { "Save",                  do_save                    },
   { "SaveFile",              do_savefile                },
   { "ShowMovie",             do_showmovie               },
   { "Smooth",                do_smooth                  },
   { "SpexCom",               do_spexcom                 },
   { "Sqrt",                  do_sqrt                    },
   { "StatsFixedWH",          do_statsfixedwh            },
   { "StatsObjBox",           do_statsobjbox             },
   { "StatsSetSky",           do_statssetsky             },
   { "StatsXORLine",          do_statsxorline            },
   { "TCSHostname",           do_tcshostname             },
   { "UseFitsAngle&Scale",    do_usefitsanglescale       },
   { "usehex",                do_usehex                  },
   { "XCutAutoScale",         do_xcutautoscale           },
   { "XCutRange",             do_xcutrange               },
   { "XCutSet",               do_xcutset                 },
};

int num_parse_item = { sizeof(parse_table) / sizeof(struct PARSE_TABLE) };

/*--------------------------------------------------------------------------------
** cmd_execute() - Executes a command line instruction
**--------------------------------------------------------------------------------
*/

int cmd_execute ( char * cmd_buf, int  verbose )
{
   char copy_buf[80];
   int error,
      found,
      i;

   char * kw,
     * par;

   /*
   **  Search table for keyword
   */
   strxcpy( copy_buf, cmd_buf, sizeof(copy_buf));
   kw  = strtok(copy_buf, " ");
   par = strtok((char*)NULL, "");
   unpad( par, ' ' );

   if( kw == NULL )          /* NULL are blank line, just ignore them */
      return( ERR_NONE );
   if( *kw == '#' )          /* line starting with # are comments */
      return( ERR_NONE );
   /*
   **  Search table for keyword. If found call function.
   */
   error = ERR_INV_KW;
   for(i=0, found = FALSE; i<num_parse_item && found == FALSE; )
   {
     if( !stricmp( kw, parse_table[i].kw ) )
     {
        found = TRUE;
        error = (parse_table[i].pfi)(i, par);  /* Call function(i, par) */
     }
     else
       i++;
   }

   /*
   **  if( !found ), try math routines
   */
   if( !found )
   {
      strxcpy( copy_buf, cmd_buf, sizeof(copy_buf));
      math_fixstring( copy_buf, sizeof(copy_buf));
      error = do_math( 1, copy_buf );
   }

   /* Update widget display */
   update_display_widgets();

   /*
   **  Provide user feedback.
   */
   if( error )
      printTextOut( CM_RED, "ERROR [%s] %s\n", cmd_buf, Error_string[abs(error)]);
   else if( verbose )
      printTextOut( CM_BLACK, "%s\n", cmd_buf);

   return( error );
}

/********************************************************************************/
/*  APPLICATION COMMANDS                                                        */
/********************************************************************************/

/*--------------------------------------------------------------------------------
** do_KEYWORK - The following routines performs the processing of
**              the command KEYWORD.
**--------------------------------------------------------------------------------
*/

/*--------------------------------------------------------------------------------
**  do_active() - Set the Active display.
**     Syntax: active dpinx
**--------------------------------------------------------------------------------
*/
int do_active( int index, char * par )
{
   int  dpinx,
        old,
        rc;

   if( (rc = parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      return rc;

   if( Lc.active != dpinx )
   {
      old = Lc.active;
      Lc.active = dpinx;
      call_dpytitle_redraw( old );         /* redraw old (normal background) */
      call_dpytitle_redraw( Lc.active );   /* redraw active (highlighted) */
   }

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_boxcentroid() - Finds and Identifies the a centroid pixel in the objbox.
**     Syntax: ObjBoxCentroid dpinx
**--------------------------------------------------------------------------------
*/
int do_boxcentroid( int index, char * par )
{
   int  dpinx,
        x, y, wid, hgt,
        px, py;
   float cx, cy,
         pixel_wid;
   double sum_dx,
          sum_dy,
          sum_d,
          d;

   struct dpy_t *dp;
   struct df_buf_t *bp;

   /* get display index */
   if( parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1) != ERR_NONE)
      dpinx = Lc.active;
   dp = &Dpy[dpinx];
   bp = &Buffer[dp->bufinx];

   /* check status */
   if( bp->status == DF_EMPTY )
      return ERR_BUF_EMPTY;

   /* get dimension of array and ckeck it is inside data array */
   x   = Stats[dp->bufinx].objx;
   y   = Stats[dp->bufinx].objy;
   wid = Stats[dp->bufinx].objwid;
   hgt = Stats[dp->bufinx].objhgt;
   if( ((x+wid-1) > bp->naxis1) || ((y+hgt-1) > bp->naxis2) )
      return ERR_INV_RNG;

   /*-------------------------------
   ** loop to find centroid
   */
   sum_dx = sum_dy = sum_d = 0;

   for( py = 0; py < hgt; py++ )
      for( px = 0; px < wid; px++ )
      {
         d = dfdataxy( bp, x+px, y+py);
         sum_d += d;
         sum_dx += d * (px+1);
         sum_dy += d * (py+1);
      }

   cx = x + (sum_dx / sum_d) - 1.0;
   cy = y + (sum_dy / sum_d) - 1.0;

   /* print results to feedback */
   printTextOut( CM_BLUE, "BoxCentroid is at (%3.1f,%3.1f)\n", cx, cy);

   /*-----------------------------------------------------------------
   ** ID pixel on image display by drawing a box around the peak pixel
   */
   pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));

   px = ((cx - dp->image_offx) * pixel_wid) + (0.5*pixel_wid);
   py = ((cy - dp->image_offy) * pixel_wid) + (0.5*pixel_wid);

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLUE] );
   gdk_draw_line( dp->data_drawingarea->window, Nor_gc,  px-pixel_wid, py, px+pixel_wid, py);
   gdk_draw_line( dp->data_drawingarea->window, Nor_gc,  px, py-pixel_wid, px, py+pixel_wid);

   gdk_draw_text( dp->data_drawingarea->window,  Fixed_font, Nor_gc,
      px+pixel_wid+2, py+pixel_wid, "C", 1);

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_boxcopy() - Object Box Copy - copies the object box
**       subarray into another buffer. The destination objbox
**       is adjust to include all the pixels.
**     Syntax: BoxCopy src to dest
**--------------------------------------------------------------------------------
*/
int do_boxcopy( int index, char * par )
{
   int  dest, src, rc;

   /* src */
   if( (src = parseSelection( par, " ", buffer_selection )) < 0 )
      return src;

   /* to */
   if( (rc = parseSelection( NULL, " ", to_selection )) < 0 )
      return rc;

   /* dest */
   if( (dest = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return dest;
#if DEBUG
   printf("boxcopy (%d,%d) %dx%d from %d to %d\n", Stats[src].objx, Stats[src].objy, Stats[src].objwid, Stats[src].objhgt, src, dest );
#endif
   rc = df_copy_subarray( &Buffer[dest], &Buffer[src],
      Stats[src].objx, Stats[src].objy, Stats[src].objwid, Stats[src].objhgt);

   /* redimension objbox so that it include all pixels */
   if( rc == ERR_NONE )
   {
      Stats[dest].objx = 0;
      Stats[dest].objy = 0;
      Stats[dest].objwid = Stats[src].objwid;
      Stats[dest].objhgt = Stats[src].objhgt;
   }

   /* redraw destination frame */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_boxpeak() - Finds and Identifies the peak.
**     Syntax: ObjBoxPeak [dpinx]
**--------------------------------------------------------------------------------
*/
int do_boxpeak( int index, char * par )
{
   int  dpinx,
        x, y, wid, hgt,
        px, py,
        peakx, peaky;
   double max, d;
   float pixel_wid;
   struct dpy_t *dp;
   struct df_buf_t *bp;

   /* get display index */
   if( parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1) != ERR_NONE)
      dpinx = Lc.active;
   dp = &Dpy[dpinx];
   bp = &Buffer[dp->bufinx];

   /* check status */
   if( bp->status == DF_EMPTY )
      return ERR_BUF_EMPTY;

   /* get dimension of array and ckeck it is inside data array */
   x   = Stats[dp->bufinx].objx;
   y   = Stats[dp->bufinx].objy;
   wid = Stats[dp->bufinx].objwid;
   hgt = Stats[dp->bufinx].objhgt;
   if( ((x+wid-1) > bp->naxis1) || ((y+hgt-1) > bp->naxis2) )
      return ERR_INV_RNG;

   /*-------------------------------
   ** loop to find peak
   */
   peakx = x;
   peaky = y;
   max   = dfdataxy( bp, x, y);
   for( py = y; py < (y+hgt); py++ )
      for( px = x; px < (x+wid); px++ )
      {
         d = dfdataxy( bp, px, py);
         if( d > max )
         {
            peakx = px;
            peaky = py;
            max   = d;
         }
      }

   /* print results to feedback */
   printTextOut( CM_BLUE, "BoxPeak is at (%d,%d) value=%3.1f\n", peakx, peaky, max);

   /*-----------------------------------------------------------------
   ** ID pixel on image display by drawing a box around the peak pixel
   */
   pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));

   px = ((peakx - dp->image_offx) * pixel_wid) + 0.5;
   py = ((peaky - dp->image_offy) * pixel_wid) + 0.5;
   if( pixel_wid < 1 )
      pixel_wid = 1;  /* can't ID subpixels, so just use wid & hgt of 1 */

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN] );
   gdk_draw_rectangle( dp->data_drawingarea->window, Nor_gc, FALSE, px, py, pixel_wid, pixel_wid);
   gdk_draw_text( dp->data_drawingarea->window,  Fixed_font, Nor_gc,
      px+pixel_wid+2, py+pixel_wid, "P", 1);
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_boxscale() - Sets autoscale to  Fixed and Scales the range to the pixels in the box.
**     Syntax: boxscale [dpinx]
**--------------------------------------------------------------------------------
*/
int do_boxscale( index, par )
   int index;
   char * par;
{
   int dpinx,
       bufinx;
   float min, max;

   struct stats_t *sp;

   /* get display index */
   if( parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1) != ERR_NONE)
      dpinx = Lc.active;
   bufinx = Dpy[dpinx].bufinx;

   if( Buffer[bufinx].status == DF_EMPTY )
      return ERR_BUF_EMPTY;
   sp = &Stats[bufinx];

   /*--------------------------------------------------------
   ** Set image range based on box statitics.
   */

   /* do simple autoscale */
   min = sp->objmean - 3*sp->objstd;
   max = sp->objmean + 3*sp->objstd;

   /* Narrow min/max based on data's Min & Max values */
   if( min < sp->objmin )
      min = sp->objmin;
   if( max > sp->objmax )
      max = sp->objmax;

   if( (max - min) < 1 )
      max = min + 1;

   Dpy[dpinx].image_min = min;
   Dpy[dpinx].image_max = max;
   Dpy[dpinx].image_autoscale = FALSE;

   /*-----------------------------------------------
   ** Redraw the canvas
   */

   if( Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
      call_dpydata_redraw( dpinx );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_boxzoom() - Zooms the active canvas on its object box.
**     Syntax: boxzoom [dpinx]
**--------------------------------------------------------------------------------
*/
int do_boxzoom( index, par )
   int index;
   char * par;
{
   int dpinx,
       bufinx,
       boxwid, boxhgt,
       fat,
       zoom,
       zoom1, zoom2,
       da_wid, da_hgt;

   float pixel_wid;

   /* get display index */
   if( parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1) != ERR_NONE)
      dpinx = Lc.active;
   bufinx = Dpy[dpinx].bufinx;

   if( Buffer[bufinx].status == DF_EMPTY )
      return ERR_BUF_EMPTY;

   /* get size of the drawing area */
   if( Dpy[dpinx].data_drawingarea->window == NULL )
      return ERR_NONE;
   gdk_window_get_size( Dpy[dpinx].data_drawingarea->window, &da_wid, &da_hgt);

   /*--------------------------------------------------------
   ** Find biggest zoom to fit the inside box inside the canvas
   */
   boxwid = Stats[bufinx].objwid + 2;
   boxhgt = Stats[bufinx].objhgt + 2;

   if ( da_wid > boxwid )
      zoom1 = da_wid / boxwid;
   else
      zoom1 = -(boxwid / da_wid);

   if ( da_hgt > boxhgt )
      zoom2 = da_hgt / boxhgt;
   else
      zoom2 = -(boxhgt / da_hgt);

   zoom = MIN( zoom1, zoom2 );
   zoom = (zoom > 20 ? 20 : zoom);
   zoom = (zoom < -5 ? -5 : zoom);
   Dpy[dpinx].image_zoom = zoom;

   /*-----------------------------------------------
   ** Try to center the box in the frame
   */
   pixel_wid = zoom > 0 ? zoom : 1.0/(1.0+abs(zoom));

   if( (fat = ( da_wid - Stats[bufinx].objwid * pixel_wid)) > 0 )
      Dpy[dpinx].image_offx = Stats[bufinx].objx - (fat/2)/pixel_wid;
   else
      Dpy[dpinx].image_offx = Stats[bufinx].objx;

   if( (fat = ( da_hgt - Stats[bufinx].objhgt * pixel_wid)) > 0 )
      Dpy[dpinx].image_offy = Stats[bufinx].objy - (fat/2)/pixel_wid;
   else
      Dpy[dpinx].image_offy = Stats[bufinx].objy;

   /* Redraw the canvas */
   if( Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
      call_dpydata_redraw( dpinx );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_buffer() - Set the buffer in a display.
**     Syntax: buffer bufid dpinx
**--------------------------------------------------------------------------------
*/
int do_buffer( int index, char * par )
{
   int  bufinx,
        dpinx,
        rc;

   if( (bufinx = parseSelection( par, " ", buffer_selection )) < 0 )
      return bufinx;
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   if( Dpy[dpinx].bufinx != bufinx )
   {
      Dpy[dpinx].bufinx = bufinx;
      call_dpydata_redraw( dpinx );
   }

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_bufinfo - display some information about a buffer to stdout.
**  Syntax: BufInfo bufid verbose_flag
**--------------------------------------------------------------------------------
*/
int do_bufinfo( int index, char * par )
{
   int bufinx, x, y,
       verbose,
       rc;
   float mean;
   struct df_buf_t *df;
   struct stats_t  *sp;

   if( (bufinx = parseSelection( par, " ", buffer_selection )) < 0 )
      return bufinx;
   if( (rc = parseInt( &verbose, NULL, " " )) != ERR_NONE)
      verbose = 0;

   df = &Buffer[bufinx];
   sp = &Stats[bufinx];

   if( df->status == DF_EMPTY )
   {
#if DEBUG
      printf("buffer is empty!\n");
#endif
      return ERR_NONE;
   }

   x = df->naxis1/4;
   y = df->naxis2/4;
   mean = (sp->objN>0 ? sp->objsum/sp->objN : 0);

   if( verbose )
   {
      printf("    Status %d \n", df->status );
      printf("    naxis1 %d \n", df->naxis1 );
      printf("    naxis2 %d \n", df->naxis2 );
      printf("      size %d \n", df->size );
      printf("    bitpix %d \n", df->bitpix );
      printf("         N %ld \n", df->N );
      printf("       max %f \n", df->max );
      printf("       mix %f \n", df->min );
      printf("      mean %f \n", df->mean );
      printf("    stddev %f \n", df->stddev );
      printf("      as/p %f \n", df->arcsec_pixel );
      printf("   divisor %f \n", df->divisor );
      printf(" directory %s \n", df->directory );
      printf("  filename %s \n", df->filename );
      printf("     Min     Max   Mean    STD   data[%d,%d]   x  y  wid hgt  "
             "objMin  objMax objMean objSTD\n", x, y);
   }

   printf(" %6.1f %6.1f %6.1f %7.2f  %10.2f   %3d %3d  %3d %3d %6.1f %6.1f %6.1f %7.2f\n",
      df->min, df->max, df->mean, df->stddev, dfdataxy( df, x, y),
      sp->objx, sp->objy, sp->objwid, sp->objhgt, sp->objmin, sp->objmax,
      mean, sp->objstd);

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
** do_clear - delete the data in a buffer.
**     Syntax: Clear bufid
**--------------------------------------------------------------------------------
*/
int do_clear( int index, char *par )
{
   int dest;

   /* dest */
   if( (dest = parseSelection( par, " ", buffer_selection )) < 0 )
      return dest;

   /* delete data */
   df_free_fbuffer( &Buffer[dest] );

   /* refresh display */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_cmCenter() - Adjusts the center of the colormap. The center point
**    values ranges from 0 to 1, 0.5 being the middle.
**     Syntax: cm.Center value
**--------------------------------------------------------------------------------
*/
int do_cmCenter( int index, char * par )
{
   float f;
   int rc;

   if( (rc = parseFloatR( &f, par, " ", 0.0, 1.0)) )
      return rc;

   CM.center = f;
   cm_set_colormap(&CM);
   if( CM.visual->type == GDK_VISUAL_TRUE_COLOR )
      call_colormap_redraw( );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_cmWidth() - Adjusts the width of the colormap. The width
**    values ranges from 0 to 1, 0.5 being the normalize value.
**     Syntax: cm.Width value
**--------------------------------------------------------------------------------
*/
int do_cmWidth( int index, char * par )
{
   float f;
   int rc;

   if( (rc = parseFloatR( &f, par, " ", 0.0, 1.0)) )
      return rc;

   CM.width = f;
   cm_set_colormap(&CM);
   if( CM.visual->type == GDK_VISUAL_TRUE_COLOR )
      call_colormap_redraw( );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
** do_colormap - Reads in a color map from a file.
**     Syntax: colormap filename
**--------------------------------------------------------------------------------
*/

int do_colormap( int index, char *par )
{
   FILE *fp;
   int colorid = 0;
   float value, position;
   char buf[160], *cptr;

   /* Open file for reading */
   cat_pathname( buf, Lc.app_home, par, sizeof(buf));
   if( NULL == (fp = fopen( buf, "rt")) )   /* Open color map file */
      return ERR_FILE_READ;

   /* Get the file type indicator...should be "IRTF CMF" */
   if( NULL == fgets( buf, sizeof buf, fp))
      return ERR_FILE_READ;
   strupr( buf );
   if( NULL==strstr(buf, "IRTF CMF"))
      return ERR_FILE_READ;

   /* Read colormap description from file */
   colorid = 0;
   CM.cgraph_num_ele[CM_RED_INX] = CM.cgraph_num_ele[CM_GREEN_INX] = CM.cgraph_num_ele[CM_BLUE_INX] = 0;
   while( NULL != fgets( buf, sizeof buf, fp) )
   {
      strupr( buf );
      if( strstr(buf, "RED") )        /* Get color index to CM */
         colorid = CM_RED_INX;
      else if( strstr(buf, "GREEN") )
         colorid = CM_GREEN_INX;
      else if(strstr(buf, "BLUE") )
         colorid = CM_BLUE_INX;
      else
      {
         if( NULL == (cptr = strtok(buf, " ,")) )
            break;
         position = atof( cptr );
         if( NULL == (cptr = strtok((char*)NULL, " ,")) )
            break;
         value = atof( cptr );
         if( INRANGE(0.0, position, 1.0) && INRANGE(0.0, value, 1.0) && colorid < CM_NUM_ELE )
         {
#if DEBUG
            printf("Position is %f and Intensity is %f\n",position,value);
#endif
            CM.cgraph[colorid][0][CM.cgraph_num_ele[colorid]] = position;
            CM.cgraph[colorid][1][CM.cgraph_num_ele[colorid]] = value;
            CM.cgraph_num_ele[colorid]++;
         }
      }
   }

   CM.center = 0.5;
   CM.width = 0.5;
   cm_set_colormap(&CM);
   if( CM.visual->type == GDK_VISUAL_TRUE_COLOR )
      call_colormap_redraw( );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_colormap_inverse() - Inverses the current colormap.
**     Syntax: Colormap.Inverse
**--------------------------------------------------------------------------------
*/
int do_colormap_inverse( int index, char * par )
{
   int   c, i, n;
   float cmdef[2][CM_NUM_ELE];

   for( c=0; c<3; c++)  /* loop for R, G, B */
   {
      /* copy color map definition */
      n = CM.cgraph_num_ele[c];
      for(i=0; i<n; i++)
      {
         cmdef[0][i] = CM.cgraph[c][0][i];
         cmdef[1][i] = CM.cgraph[c][1][i];
      }

      /* write back definition in reverse order & adjust index variable */
      for(i=0; i<n; i++)
      {
         CM.cgraph[c][0][i] = fabs(cmdef[0][n-i-1] - 1 );
         CM.cgraph[c][1][i] = cmdef[1][n-i-1];
      }
   }

   Lc.cminverse = !Lc.cminverse;
   cm_set_colormap(&CM);
   if( CM.visual->type == GDK_VISUAL_TRUE_COLOR )
      call_colormap_redraw( );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_copy() - copy data from a src buffer to a dest buffer.
**     Syntax: COPY src TO dest
**--------------------------------------------------------------------------------
*/
int do_copy( int index, char * par )
{
   int  dest, src, rc;

   /* src */
   if( (src = parseSelection( par, " ", buffer_selection )) < 0 )
      return src;

   /* to */
   if( (rc = parseSelection( NULL, " ", to_selection )) < 0 )
      return rc;

   /* dest */
   if( (dest = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return dest;

   rc = df_buffer_math( &Buffer[dest], &Buffer[src], &Buffer[src], DF_MATH_COPY);

   /* redraw destination frame */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_displaytype() - Select a display format for drawing area.
**     Syntax: displaytype {Image|Histogram|...} [dpinx]
**--------------------------------------------------------------------------------
*/
int do_displaytype( int index, char * par )
{
   int dpytype, dpinx;

   if( (dpytype = parseSelection( par, " ", dpytype_selection )) < 0 )
      return dpytype;
   if( parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].dpytype != dpytype )
   {
      Dpy[dpinx].dpytype = dpytype;
      call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_divbydivisor() - Enables/disable the divide by divisor option. Representation
**     of the data can be divided by the DIVISOR keywork value in the FITS header.
**     Syntax:  DivByDivisor { off | on }
**--------------------------------------------------------------------------------
*/
int do_divbydivisor( index, par )
   int index;
   char * par;
{
   int ipar, bufinx;

   /* get buf_id */
   if( ( ipar = parseSelection( par, " ", offon_selection)) < 0 )
      return ipar;

   /* apply parameters */
   if( Lc.divbydivisor != ipar )
   {
      Lc.divbydivisor = ipar;
      dfset_divbycoadd( ipar );  /* update the dflib to handle the divbycoadd */

      /* recalculate all stats & redisplay all canvases */
      for( bufinx=0; bufinx < NUM_BUFFER; bufinx++ )
      {
         if( Buffer[bufinx].status != DF_EMPTY )
         {
            df_stats( &Buffer[bufinx] );
            cal_box_stats( bufinx );
            redraw_dpydata_for_bufinx( bufinx );
            save_update_dialog( bufinx );
         }
      }
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_drawbox - Draws a Box on the image.
**     Syntax: DrawBox bufid x y wid hgt
**--------------------------------------------------------------------------------
*/
int do_drawbox( int index, char * par )
{
   int  bufinx,
        dpinx,
        x, y, wid, hgt,
        px, py, pwid, phgt,
        rc;
   float pixel_wid;
   struct dpy_t *dp;
   struct df_buf_t *bp;

   /*-------------------
   ** parse arguments.
   */
   if( (bufinx = parseSelection( par, " ", buffer_selection )) < 0 )
      return bufinx;
   bp = &Buffer[bufinx];

   if( (rc = parseIntR( &x, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &y, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &wid, NULL, " ", 0, NUM_PIXEL-x)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &hgt, NULL, " ", 0, NUM_PIXEL-y)) != ERR_NONE)
      return rc;

   /* check status */
   if( bp->status == DF_EMPTY )
      return ERR_NONE;

   /*----------------------------------------------------
   ** Draw on  each display showing an image from bufinx.
   */
   for( dpinx=0; dpinx < Lc.num_dpy; dpinx++ )
   {
      dp = &Dpy[dpinx];
      if( (dp->bufinx == bufinx) && (dp->dpytype == DPYTYPE_IMAGE))
      {
         pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));

         /* convert x,y,wid,hgt to pixel location for draw command */
         px = ((x - dp->image_offx) * pixel_wid) + 0.5;
         py = ((y - dp->image_offy) * pixel_wid) + 0.5;
         pwid = (wid*pixel_wid)+0.5;
         if( pwid < 1 ) pwid = 1;
         phgt = (hgt*pixel_wid)+0.5;
         if( phgt < 1 ) phgt = 1;

         gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN] );
         gdk_draw_rectangle( dp->data_drawingarea->window, Nor_gc, FALSE, px, py, pwid, phgt);
      }

   }

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_drawline - Draws a line from x1,y1 to x2,y2 on the image.
**     Syntax: DrawLine bufid x1 y1 x2 y2
**--------------------------------------------------------------------------------
*/
int do_drawline( int index, char * par )
{
   int  bufinx,
        dpinx,
        x1, y1, x2, y2,
        px1, py1, px2, py2,
        rc;
   float pixel_wid;
   struct dpy_t *dp;
   struct df_buf_t *bp;

   /*-------------------
   ** parse arguments.
   */
   if( (bufinx = parseSelection( par, " ", buffer_selection )) < 0 )
      return bufinx;
   bp = &Buffer[bufinx];

   if( (rc = parseIntR( &x1, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &y1, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &x2, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &y2, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;

   /* check status */
   if( bp->status == DF_EMPTY )
      return ERR_NONE;

   /*----------------------------------------------------
   ** Draw on  each display showing an image from bufinx.
   */
   for( dpinx=0; dpinx < Lc.num_dpy; dpinx++ )
   {
      dp = &Dpy[dpinx];
      if( (dp->bufinx == bufinx) && (dp->dpytype == DPYTYPE_IMAGE))
      {
         pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));

         /* convert x,y,wid,hgt to pixel location for draw command */
         px1 = ((x1 - dp->image_offx) * pixel_wid) + (pixel_wid/2);
         py1 = ((y1 - dp->image_offy) * pixel_wid) + (pixel_wid/2);
         px2 = ((x2 - dp->image_offx) * pixel_wid) + (pixel_wid/2);
         py2 = ((y2 - dp->image_offy) * pixel_wid) + (pixel_wid/2);

         gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN] );
         gdk_draw_line( dp->data_drawingarea->window, Nor_gc, px1, py1, px2, py2);
      }

   }

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_echo - Prints text on the TextOut_w.
**--------------------------------------------------------------------------------
*/
int do_echo( int index, char * par )
{
   char buf[128];

   if( par )
   {
      strxcpy( buf, par, sizeof(buf));
      printTextOut( CM_BLUE, "%s\n", buf );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_filter1() - changes data in buffer so:
**   a. rescale data so [mean-std, mean+std] maps to -25 to +25
**   b. reset negative values to 0.
**  The filter could be useful when applied to data before using the centroid
**  algorithm.
**     Syntax: Filter1 bufinx
**--------------------------------------------------------------------------------
*/
int do_filter1( int index, char * par )
{
   int  dest, src, rc;

   /* src */
   if( (src = parseSelection( par, " ", buffer_selection )) < 0 )
      return src;

   /* to */
   if( (rc = parseSelection( NULL, " ", to_selection )) < 0 )
      return rc;

   /* dest */
   if( (dest = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return dest;

   rc = df_buffer_userfun( &Buffer[dest], &Buffer[src], my_filter1_fun);

   /* redraw destination frame */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

int my_filter1_fun(  struct df_buf_t *dest, struct df_buf_t *op1 )
{
   int inx, N;
   double low,
          high,
          data;

   low  = op1->mean - op1->stddev;
   high = op1->mean + op1->stddev;
   if( (high-low) < 1.0 ) high = low + 1;

   N = op1->naxis1 * op1->naxis2;
   for( inx=0; inx < N; inx++ )
   {
      data = dfdatainx( op1, inx );
      data = map( data, low, high, -25, 25 );
      if( data < 0 ) data = 0;

      dest->fdata[inx] = data;
   }

   return 0;
}

/*--------------------------------------------------------------------------------
**  do_filter2() - changes data in buffer so:
**    a. reset mean to 0.
**    b. divide data by std
**    c. then zero value that are <= 1.
**  The filter could be useful when applied to data before using the centroid
**  algorithm.
**     Syntax: Filter2 bufinx
**--------------------------------------------------------------------------------
*/
int do_filter2( int index, char * par )
{
   int  dest, src, rc;

   /* src */
   if( (src = parseSelection( par, " ", buffer_selection )) < 0 )
      return src;

   /* to */
   if( (rc = parseSelection( NULL, " ", to_selection )) < 0 )
      return rc;

   /* dest */
   if( (dest = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return dest;

   rc = df_buffer_userfun( &Buffer[dest], &Buffer[src], my_filter2_fun);

   /* redraw destination frame */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

int my_filter2_fun(  struct df_buf_t *dest, struct df_buf_t *op1 )
{
   int inx, N;
   double mean,
          std,
          data;

   mean  = op1->mean;
   std   = op1->stddev;
   N = op1->naxis1 * op1->naxis2;

   for( inx=0; inx < N; inx++ )
   {
      data = dfdatainx( op1, inx );
      data = ( data - mean )  / std;
      if( data < 0 ) data = 0;

      dest->fdata[inx] = data;
   }

   return 0;
}

/*--------------------------------------------------------------------------------
**  do_fullimage() - Zooms the dpyinx canvas so the entire image is visible.
**                   Defaults to the active canvase if dpyinx not specified.
**     Syntax: fullimage [dpinx]
**--------------------------------------------------------------------------------
*/
int do_fullimage( index, par )
   int index;
   char * par;
{
   int dpinx,
       zoom1, zoom2, zoom;
   int da_wid, da_hgt;
   struct df_buf_t *bp;            /* buffer pointer */

   if( parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1) != ERR_NONE)
      dpinx = Lc.active;
   bp = &Buffer[Dpy[dpinx].bufinx];

   if( bp->status == DF_EMPTY )
      return ERR_BUF_EMPTY;

   /* get size of the drawing area */
   if( Dpy[dpinx].data_drawingarea->window == NULL )
      return ERR_NONE;
   gdk_window_get_size( Dpy[dpinx].data_drawingarea->window, &da_wid, &da_hgt);

   if( da_wid >= bp->naxis1 )
      zoom1 = da_wid / bp->naxis1;
   else
      zoom1 = -((bp->naxis1-1) / da_wid);

   if( da_hgt >= bp->naxis2 )
      zoom2 = da_hgt / bp->naxis2;
   else
      zoom2 = -((bp->naxis2-1) / da_hgt );

#if DEBUG
   printf("dpy=%d  x: %d %d=%d  y:%d %d=%d\n",
      dpinx, bp->naxis1, da_wid, zoom1 , bp->naxis2, da_wid, zoom2 );
#endif

   zoom = MIN( zoom1, zoom2 );
   zoom = (zoom > 20 ? 20 : zoom);
   zoom = (zoom < -5 ? -5 : zoom);
   zoom = (zoom == 0 ? 1 : zoom);

   /* update */
   if( Dpy[dpinx].image_zoom != zoom )
   {
      Dpy[dpinx].image_zoom = zoom;

      /* Redraw the canvas */
      if( Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_histarea() - Set the range of pixel to be included in the histogram.
**     Syntax: HistArea { All | Box } [dpinx]
**--------------------------------------------------------------------------------
*/
int do_histarea( int index, char * par )
{
   int rc, area, dpinx;

   /* Get area */
   if( par == NULL )
      return ERR_INV_FORMAT;

   if( (area = parseSelection( par, " ", allbox_selection )) < 0 )
      return area;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].hist_area != area )
   {
      Dpy[dpinx].hist_area = area;

      if( Dpy[dpinx].dpytype == DPYTYPE_HISTOGRAM )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_histbin() - Sets the number of bins for a histogram display.
**     Syntax: HistBin num [dpinx]
**--------------------------------------------------------------------------------
*/
int do_histbin( int index, char * par )
{
   int rc, dpinx, bin;

   /* Get bin */
   if( (rc = parseIntR( &bin, par, " ", 1, HIST_NUM_BIN)) != ERR_NONE )
      return rc;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE )
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].hist_bin != bin )
   {
      Dpy[dpinx].hist_bin = bin;
      if( Dpy[dpinx].dpytype == DPYTYPE_HISTOGRAM )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_imageautoscale() - Set the zoom level for a image display.
**     Syntax: ImageAutoScale { Fixed | Auto } [dpinx]
**--------------------------------------------------------------------------------
*/
int do_imageautoscale( int index, char * par )
{
   int scale,
       dpinx,
       rc;

   /* Get scale */
   if( (scale = parseSelection( par, " ", imageautoscale_selection )) < 0 )
      return scale;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].image_autoscale != scale )
   {
      Dpy[dpinx].image_autoscale = scale;

      if( Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_imagerange() - Sets the image display range for the Active_canvas.
**     Syntax:  ImageRange  min max [dpinx]
**--------------------------------------------------------------------------------
*/
int do_imagerange( index, par )
   int index;
   char * par;
{
   int dpinx,
       rc;
   long min, max;

   /* Get max & min */
   if( (rc = parseLong( &min, par, " ")) != ERR_NONE)
      return rc;
   if( (rc = parseLong( &max, NULL, " ")) != ERR_NONE)
      return rc;

   if( max <= min )
      return ERR_INV_FORMAT;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   Dpy[dpinx].image_autoscale = FALSE;
   if( Dpy[dpinx].image_min != min || Dpy[dpinx].image_max != max )
   {
      Dpy[dpinx].image_min = min;
      Dpy[dpinx].image_max = max;
      if( (Dpy[dpinx].dpytype==DPYTYPE_IMAGE) || (Dpy[dpinx].dpytype==DPYTYPE_HISTOGRAM) )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_imagescale1p() - Set the fixed scale to include all the pixel values
**     except for the top or bottom 1 percent.
**     Syntax: ImageScale1P [dpinx]
**--------------------------------------------------------------------------------
*/
int do_imagescale1p( int index, char * par )
{
   int  bufinx,
        dpinx,
        rc;
   long min, max;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* check status */
   bufinx =  Dpy[dpinx].bufinx;
   if( Buffer[bufinx].status == DF_EMPTY )
      return ERR_BUF_EMPTY;

   {
      struct timeval  tval;
      struct timezone tzone;
      long ems;
      gettimeofday( &tval, &tzone);

      cal_1per( &Buffer[bufinx], &min, &max );
      ems = elapse_ms( &tval );
      printTextOut( CM_GRAY, " cal_1per(): [%ld...%ld] ems=%ld\n", min, max, ems);
   }

   /* update */
   Dpy[dpinx].image_autoscale = FALSE;
   if( Dpy[dpinx].image_min != min || Dpy[dpinx].image_max != max )
   {
      Dpy[dpinx].image_min = min;
      Dpy[dpinx].image_max = max;
      if( (Dpy[dpinx].dpytype==DPYTYPE_IMAGE) || (Dpy[dpinx].dpytype==DPYTYPE_HISTOGRAM) )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  cal_1per() - function to find min & max of data set to include 99% of
**    the data. Excluding the top/bottom 1 percent value. Just an approximation
**    using a histogram algorithm.
**--------------------------------------------------------------------------------
*/
int cal_1per( struct df_buf_t *bp, long * Rmin, long * Rmax )
{
   int  num_bins,
        pixel_low,
        pixel_high,
        pixel_binned,
        i;
   long *bins;
   float hist_max,
         hist_min,
         bin_size;

   float min, max;

   /* allocate memory for histogram bins & initialize variables */
   num_bins = 400;  /* let use 400 bins */
   if( NULL == ( bins = (long *)malloc( sizeof(long)*num_bins)) )
      return MEM_ALT_ERR;
   memset( bins, 0, sizeof(long)*num_bins);
   pixel_low = 0;
   pixel_high = 0;
   pixel_binned = 0;

   /* find min & max range for histogram - use mean +- 4 std_dev. or Max/Min
   ** if Max/Min is less
   */
   hist_min = bp->mean - (bp->stddev*4);
   if( hist_min < bp->min )
      hist_min = bp->min;
   hist_max = bp->mean + (bp->stddev*4);
   if( hist_max < bp->max )
      hist_max = bp->max;

   bin_size = (hist_max - hist_min) / num_bins;

#if DEBUG
   printf("min: %3.1f,%3.1f->%3.1f\n", bp->mean-(bp->stddev*4), bp->min, hist_min);
   printf("max: %3.1f,%3.1f->%3.1f\n", bp->mean+(bp->stddev*4), bp->max, hist_max);
   printf("BinSize = %5.2f \n", bin_size);
#endif

   /* Loop through data, and bin according to values.
   */
   for( i = 0; i < bp->N; i++ )
   {
      float data;
      int   bin;

      data = dfdatainx( bp, i );
      bin  =  (data-hist_min) / bin_size;

      if( bin < 0 )
         pixel_low++;
      else if( bin >= num_bins )
         pixel_high++;
      else
      {
         pixel_binned++;
         bins[bin]++;
      }
#if DEBUG
      if( i < 10 ) printf(" data=%f  bin=%d \n", data, bin ); 
#endif
   }

#if DEBUG
   printf(" Low: %d %4.2f%% \n", pixel_low,  (100.0*pixel_low) / bp->N);
   printf(" Hi:  %d %4.2f%% \n", pixel_high, (100.0*pixel_high) / bp->N);
   printf(" Bin: %d %4.2f%% \n", pixel_binned, (100.0*pixel_binned) / bp->N);
   printf(" Total=%d  N=%ld \n", pixel_low+pixel_high+pixel_binned, bp->N);
#endif

   /* Find max/min */
   min = hist_min;
   max = hist_max;
   {
      int cnt, inx;

      /* find range value for min */
      cnt = pixel_low;
      for( i=0; i < num_bins; i++ )
      {
         float p;

         min = hist_min + ( bin_size * i );
         p  = (100.0 * cnt)/bp->N;

         cnt += bins[i];
         p  = (100.0 * cnt)/bp->N;
         if( p >= 1.0 )  /* if > 1 percent */
            break;
      }

      /* find range value for max */
      cnt = pixel_high;
      inx = num_bins-1;
      for( i=0; i<num_bins; i++, inx-- )
      {
         float p;

         max = hist_max - (bin_size*i);
         p  = (100.0 * cnt)/bp->N;

         cnt += bins[inx];
         p  = (100.0 * cnt)/bp->N;
         if( p >= 1.0 )  /* if > 1 percent */
            break;
      }

      if( (min + 1.0) > max )
         max = min + 1.0;
   }

   *Rmin = rint( min );
   *Rmax = rint( max );
   free( bins );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_imagezoom() - Set the zoom level for a image display.
**     Syntax: ImageZoom zoom dpinx
**--------------------------------------------------------------------------------
*/
int do_imagezoom( int index, char * par )
{
   int zoom,
       dpinx,
       rc;

   /* Get dpinx */
   if( (rc = parseIntR( &zoom, par, " ", -7, 20)) != ERR_NONE)
      return rc;
   zoom = (zoom==0 ? 1 : zoom);    /* can't be zero */

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].image_zoom != zoom )
   {
      Dpy[dpinx].image_zoom = zoom;
      if( Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_lcutarea() - Set the range of pixel to be included in the lcut.
**     Syntax: LCutArea { All | Box } [dpinx]
**--------------------------------------------------------------------------------
*/
int do_lcutarea( int index, char * par )
{
   int rc, area, dpinx;

   /* Get area */
   if( par == NULL )
      return ERR_INV_FORMAT;

   if( (area = parseSelection( par, " ", allbox_selection )) < 0 )
      return area;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].lcut_area != area )
   {
      Dpy[dpinx].lcut_area = area;

      if( Dpy[dpinx].dpytype == DPYTYPE_LINECUT )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_lcutautoscale() - Set the autoscale float for linecut.
**     Syntax: LCutAutoScale { Fixed | Auto } [dpinx]
**--------------------------------------------------------------------------------
*/
int do_lcutautoscale( int index, char * par )
{
   int scale,
       dpinx,
       rc;

   /* Get scale */
   if( (scale = parseSelection( par, " ", imageautoscale_selection )) < 0 )
      return scale;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].lcut_autoscale != scale )
   {
      Dpy[dpinx].lcut_autoscale = scale;

      if( Dpy[dpinx].dpytype == DPYTYPE_LINECUT )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_lcutrange() - Sets the linecut display range
**     Syntax:  LCutRange  min max [dpinx]
**--------------------------------------------------------------------------------
*/
int do_lcutrange( index, par )
   int index;
   char * par;
{
   int dpinx,
       rc;
   long min, max;

   /* Get max & min */
   if( (rc = parseLong( &min, par, " ")) != ERR_NONE)
      return rc;
   if( (rc = parseLong( &max, NULL, " ")) != ERR_NONE)
      return rc;

   if( max <= min )
      return ERR_INV_FORMAT;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
    Dpy[dpinx].lcut_autoscale = FALSE;
   if( Dpy[dpinx].lcut_min != min || Dpy[dpinx].lcut_max != max )
   {
      Dpy[dpinx].lcut_min = min;
      Dpy[dpinx].lcut_max = max;
      if( Dpy[dpinx].dpytype==DPYTYPE_LINECUT )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_lcutxy() - Selects the column for a line cut.
**     Syntax: LCutXY x y [dpinx]
**--------------------------------------------------------------------------------
*/
int do_lcutxy( int index, char * par )
{
   int rc, x, y, dpinx;

   /* Get x */
   if( (rc = parseIntR( &x, par, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;

   /* Get y */
   if( (rc = parseIntR( &y, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if((Dpy[dpinx].lcut_x != x ) || ( Dpy[dpinx].lcut_y != y ))
   {
      Dpy[dpinx].lcut_x = x;
      Dpy[dpinx].lcut_y = y;
      if( Dpy[dpinx].dpytype == DPYTYPE_LINECUT )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_math() -performs a math expression.
**     Syntax: b = b {*|/|+|-} {b|num}
**        'b' can be { a | b | c | ... }
**--------------------------------------------------------------------------------
*/
int do_math( int index, char * par)
{
   int  dest, s1, s2, ops,
        is_buffer_math,
        rc;
   float constant;
   char buf[40];

   /* dest */
   if( (dest = parseSelection( par, " ", buffer_selection )) < 0 )
      return dest;

   /* = */
   if( (rc=parseSelection( NULL, " ", mathops_selection )) < 0 )
      return rc;
   if( rc != 4 ) return ERR_INV_FORMAT;

   /* s1 */
   if( (s1 = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return s1;

   /* ops */
   if( (ops=parseSelection( NULL, " ", mathops_selection )) < 0 )
      return ops;
   if( !INRANGE(DF_MATH_ADD, ops, DF_MATH_DIV))  return ERR_INV_FORMAT;

   /* s2 or constand */
   if( (rc=parseString( buf, sizeof(buf), NULL, " ")) != ERR_NONE )
      return rc;

   is_buffer_math = TRUE;
   if( (s2 = parseSelection( buf, " ", buffer_selection )) < 0 )
   {
      is_buffer_math = FALSE;
      if( (rc = parseFloat( &constant, buf, " ")) != ERR_NONE)
         return rc;
   }

   /* Call function to perform math operation */
   if( is_buffer_math )
   {
      rc = df_buffer_math( &Buffer[dest], &Buffer[s1], &Buffer[s2], ops );
   }
   else
   {
      rc = df_constant_math( &Buffer[dest], &Buffer[s1], constant, ops );
   }

   /*
   ** redraw destination frame.
   */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );

   return rc;
}

/*--------------------------------------------------------------------------------
**  do_m_edit - opens the selected file in nedit.
**--------------------------------------------------------------------------------
*/
int do_m_edit( int index, char * par )
{
   char * pathname;

   /* get the filename */
   if( NULL == (pathname = strtok( par, " ")) )
      return ERR_INV_FORMAT;

   if( fork() == 0 )
   {
      char * arg[4];

      arg[0] = "nedit";
      arg[1] = pathname;
      arg[2] = NULL;
      execvp("/usr/local/bin/nedit", arg);
      exit(0);
   }

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_m_execute - executes the macro.
**--------------------------------------------------------------------------------
*/
int do_m_execute( int index, char * par )
{
   char * pathname;

   /* get the filename */
   if( NULL == (pathname = strtok( par, " ")) )
      return ERR_INV_FORMAT;

   /* if currently executing, close & remove timer */
   if( Md.fp != NULL )
   {
      gtk_timeout_remove( Md.exe_timerid );  /* remove application timer */
      fclose( Md.fp );
   }

   /* open file & start application timer */
   if( NULL == (Md.fp = fopen(pathname, "r")) )
      return ERR_FILE_READ;

   Md.exe_timerid = gtk_timeout_add( 100L, m_exe_timer_func, NULL );

   printTextOut( CM_BLUE, "Starting Macro file %s (fd=%d) \n", pathname, fileno(Md.fp) );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_m_filemask - applies the mask to the file list display.
**--------------------------------------------------------------------------------
*/
int do_m_filemask( int index, char * par )
{
   char * mask;

   mask = strtok( par, " ");
   if( mask == NULL ) mask = "*";

   strxcpy( Md.filemask, mask, sizeof(Md.filemask));
   gtk_entry_set_text( GTK_ENTRY(Md.file_mask_w), (char*) Md.filemask );

   update_file_list( FALSE, Md.path, Md.filemask, Md.file_list_w );
   m_clear_file();
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_m_load - loads the selected file into the text widget.
**--------------------------------------------------------------------------------
*/
int do_m_load( int index, char * par )
{
   int  rc;
   char * filename;
   char textbuf[150];
   char pathname[128];
   FILE * fp;

   /* get the filename */
   if( NULL == (filename = strtok( par, " ")) )
      return ERR_INV_FORMAT;

   /* extract path & dir from pathname */
   cat_pathname( pathname, Md.path, filename, sizeof(pathname));

   rc = ERR_NONE;

   /* open file */
   if( NULL == ( fp = fopen(pathname, "rt") ) )
      { rc = ERR_FILE_READ; goto ldone; }

   /* Insert file into text buffer */
   {
      int length;
      gtk_text_freeze( GTK_TEXT(Md.file_text_w) );
      length = gtk_text_get_length( GTK_TEXT(Md.file_text_w) );
      gtk_text_set_point( GTK_TEXT(Md.file_text_w), length );         /* set the cursor to the end of the text */
      gtk_text_backward_delete( GTK_TEXT(Md.file_text_w), length );   /* clear the text already there */

      while ( NULL != fgets( textbuf, sizeof(textbuf), fp ) )
      {
         gtk_text_insert( GTK_TEXT(Md.file_text_w), NULL, NULL, NULL, textbuf, -1 );   /* insert text */
      }
      gtk_text_thaw( GTK_TEXT(Md.file_text_w) );
   }

ldone:
   fclose( fp );
   fp = NULL;
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_m_path - applies the path to the file list display.
**--------------------------------------------------------------------------------
*/
int do_m_path( int index, char * par )
{
   int rc;
   char buf[256];
   char date[10];
   char * cptr;

   time_t      now = time((time_t *) 0);
   struct tm * today = gmtime( &now );
   rc = ERR_NONE;

   cptr = strtok( par, " ");
   if( cptr == NULL ) cptr = "$HOME";

   expand_pathname( buf, sizeof(buf), cptr );

   sprintf( date, "%02d%3.3s", today->tm_mday, Month_name[today->tm_mon]);
   str_replace_sub( buf, buf, sizeof(buf), "$DATE", date);

   if( exist_path( buf ) == -1 )
   {
      rc =  ERR_INV_PATH;
      goto ldone;

      if( create_path( buf ) < 0 )
      { rc =  ERR_INV_PATH; goto ldone; }
   }

ldone:
   strxcpy( Md.path, buf, sizeof(Md.path));
   gtk_entry_set_text( GTK_ENTRY(Md.path_w), (char*) Md.path );
   bfp_set_path( &Bfp_m_path, Md.path);

   update_file_list( FALSE, Md.path, Md.filemask, Md.file_list_w );
   m_clear_file();
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_m_refresh - refreshes the file list display, clears the selection, and
**                 clears the file display text area.
**--------------------------------------------------------------------------------
*/
int do_m_refresh( int index, char * par )
{
   update_file_list( FALSE, Md.path, Md.filemask, Md.file_list_w );
   m_clear_file();
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_m_setbutton - create a shortcut button for the selected macro file.
**--------------------------------------------------------------------------------
*/
int do_m_setbutton( int index, char * par )
{
   int rc, inx;
   char name[30],
        path[80];
   char *cptr;

   /* button index */
   if( (rc=parseIntR( &inx, par, " ", 0, NUM_FUN_BUT)) != ERR_NONE)
      return rc;

   /* path */
   if( NULL == (cptr = strtok( NULL, " ")) )
      return ERR_INV_FORMAT;

   strxcpy( path, cptr, sizeof(path) );
   unpad( path, ' ');
   if( strlen( path )  < 1 )
      return ERR_INV_FORMAT;

   /* filename */
   if( NULL == (cptr = strtok( NULL, " ")) )
      return ERR_INV_FORMAT;

   strxcpy( name, cptr, sizeof(name) );
   unpad( name, ' ');
   if( strlen( name )  < 1 )
      return ERR_INV_FORMAT;

   /* copy information into global variables */
   Md.fb_ok[inx] = TRUE;
   strxcpy( Md.fb_fname[inx], name, sizeof(Md.fb_fname[0]));
   strxcpy( Md.fb_path[inx], path, sizeof(Md.fb_path[0]));

   /* set button resource */
   gtk_widget_set_style( GTK_WIDGET(GTK_BIN(Md.f_buttons[inx])->child), Style_Blue );
   gtk_label_set_text( GTK_LABEL(GTK_BIN(Md.f_buttons[inx])->child), name );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_m_stop - stop an executing macro.
**--------------------------------------------------------------------------------
*/
int do_m_stop( int index, char * par )
{
   if( Md.fp != NULL )
   {
      fclose( Md.fp );
      Md.fp = NULL;
      gtk_timeout_remove( Md.exe_timerid );   /* remove application timer */
      printTextOut( CM_BLUE, "Terminating current macro execution!\n" );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_noisearea() - Set the range of pixels to be include in the Noise Display
**     Syntax: NoiseArea  All|Box
**--------------------------------------------------------------------------------
*/
int do_noisearea( int index, char * par )
{
   int area, dpinx, rc;

   /* Get area */
   if( par == NULL )
      return ERR_INV_FORMAT;

   if( (area = parseSelection( par, " ", allbox_selection )) < 0 )
      return area;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].noise_area != area )
   {
      Dpy[dpinx].noise_area = area;
      if( Dpy[dpinx].dpytype == DPYTYPE_NOISE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_noiseautoscale() - Set the autoscale of the noise graph
**     Syntax: NoiseAutoScale off|on
**--------------------------------------------------------------------------------
*/
int do_noiseautoscale( int index, char * par )
{
   int scale, dpinx, rc;

   /* Get scale */
   if( par == NULL )
      return ERR_INV_FORMAT;

   if( (scale = parseSelection( par, " ", imageautoscale_selection )) < 0 )
      return scale;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].noise_autoscale != scale )
   {
      Dpy[dpinx].noise_autoscale = scale;
      if( Dpy[dpinx].dpytype == DPYTYPE_NOISE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_noiseg1range() - Sets the range of the max/min/mean noise graph.
**     Syntax:  NoiseG1Range min max
**--------------------------------------------------------------------------------
*/
int do_noiseg1range( int index, char * par )
{
   int dpinx, rc;
   long min, max;

   /* Get max & min */
   if( (rc = parseLong( &min, par, " ")) != ERR_NONE)
      return rc;
   if( (rc = parseLong( &max, NULL, " ")) != ERR_NONE)
      return rc;

   if( max <= min )
      return ERR_INV_FORMAT;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   Dpy[dpinx].noise_autoscale = FALSE;
   if( Dpy[dpinx].noise_g1_min != min || Dpy[dpinx].noise_g1_max != max )
   {
      Dpy[dpinx].noise_g1_min = min;
      Dpy[dpinx].noise_g1_max = max;
      if( Dpy[dpinx].dpytype == DPYTYPE_NOISE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_noiseg2range() - Sets the range of the max/min/mean noise graph.
**     Syntax:  NoiseG2Range min max
**--------------------------------------------------------------------------------
*/
int do_noiseg2range( int index, char * par )
{
   int dpinx, rc;
   long min, max;

   /* Get max & min */
   if( (rc = parseLong( &min, par, " ")) != ERR_NONE)
      return rc;
   if( (rc = parseLong( &max, NULL, " ")) != ERR_NONE)
      return rc;

   if( max <= min )
      return ERR_INV_FORMAT;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   Dpy[dpinx].noise_autoscale = FALSE;
   if( Dpy[dpinx].noise_g2_min != min || Dpy[dpinx].noise_g2_max != max )
   {
      Dpy[dpinx].noise_g2_min = min;
      Dpy[dpinx].noise_g2_max = max;
      if( Dpy[dpinx].dpytype == DPYTYPE_NOISE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_noisegraphtype() - Sets the graph type for noise display.
**     Syntax: NoiseGraphType Text|Graph
**--------------------------------------------------------------------------------
*/
int do_noisegraphtype( int index, char * par )
{
   int graphtype, dpinx, rc;

   /* Get graphtype */
   if( par == NULL )
      return ERR_INV_FORMAT;

   if( (graphtype = parseSelection( par, " ", noisegraphtype_selection )) < 0 )
      return graphtype;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].noise_graph_type != graphtype )
   {
      Dpy[dpinx].noise_graph_type = graphtype;
      if( Dpy[dpinx].dpytype == DPYTYPE_NOISE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_noisemod() - Sets the modular value for noise display.
**     Syntax: noisemod num
**--------------------------------------------------------------------------------
*/
int do_noisemod( int index, char * par )
{
   int dpinx, mod, rc;

   /* Get mod */
  if( (rc = parseIntR( &mod, par, " ", 1, 256)) != ERR_NONE)
      return rc;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].noise_mod != mod )
   {
      Dpy[dpinx].noise_mod = mod;
      if( Dpy[dpinx].dpytype == DPYTYPE_NOISE )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}


/*--------------------------------------------------------------------------------
**  do_offset_angle() - Sets the tcs offset angle.
**     Syntax:  Offset.angle angel
**--------------------------------------------------------------------------------
*/
int do_offset_angle( int index, char *par )
{
   int rc;
   float angle;

   if( (rc = parseFloatR( &angle, par, " ", 0.0, 360.0)) != ERR_NONE)
      return rc;

   Lc.offset_angle = angle;
   cal_offset_radec( );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_offset_begxy() - Sets the from (x,y).
**     Syntax:  Offset.from x y
**--------------------------------------------------------------------------------
*/
int do_offset_begxy( int index, char *par )
{
   int rc;
   float x, y;

   if( (rc = parseFloatR( &x, par,  " ,", 0.0, NUM_PIXEL)) != ERR_NONE)
      return rc;
   if( (rc = parseFloatR( &y, NULL, " ", 0.0, NUM_PIXEL)) != ERR_NONE)
      return rc;

   Lc.offset_beg_x = x;
   Lc.offset_beg_y = y;
   cal_offset_radec( );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_offset_endxy() - Sets the from (x,y).
**     Syntax:  Offset.to x y
**--------------------------------------------------------------------------------
*/
int do_offset_endxy( int index, char *par )
{
   int rc;
   float x, y;

   if( (rc = parseFloatR( &x, par,  " ,", 0.0, NUM_PIXEL)) != ERR_NONE)
      return rc;
   if( (rc = parseFloatR( &y, NULL, " ", 0.0, NUM_PIXEL)) != ERR_NONE)
      return rc;

   Lc.offset_end_x = x;
   Lc.offset_end_y = y;
   cal_offset_radec( );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_offset_platescale() - Sets the tcs offset platescale.
**     Syntax:  Offset.platescale platescale
**--------------------------------------------------------------------------------
*/
int do_offset_platescale( int index, char *par )
{
   int rc;
   float platescale;

   if( (rc = parseFloatR( &platescale, par, " ", 0.001, 100.0)) != ERR_NONE)
      return rc;

   Lc.offset_platescale = platescale;
   cal_offset_radec( );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_offset_tcs() - Sends the offset commands to the TCS.
**     Syntax:  Offset.TCS
**--------------------------------------------------------------------------------
*/
int do_offset_tcs( int index, char *par )
{
   int   rc;
   char  buf[40];

   rc = ERR_NONE;

   /*----------------------------
   **  Send the New Offsets to the TCS
   */
   /* sprintf( buf, "0 %2.1f %2.1f 0 C.PEAK", Lc.offset_ra, Lc.offset_dec); */
   sprintf( buf, "0 %2.1f %2.1f 0 C.SCN", Lc.offset_ra, Lc.offset_dec);

   if( tcs_com( buf, buf, sizeof(buf), Lc.tcshostname) != ERR_NONE )
      rc = ERR_SOCKET_ERR;

   return rc;
}

/*--------------------------------------------------------------------------------
**  do_offset_tcsab() - Sends the beamswitch offset commands to the TCS.
**     Syntax:  OffsetAB.TCS
**--------------------------------------------------------------------------------
*/
int do_offset_tcsab( int index, char *par )
{
   int   rc;
   char  buf[40];

   rc = ERR_NONE;

   /*----------------------------
   **  Send the New Offsets to the TCS
   */
   sprintf( buf, "%2.1f %2.1f TW.BS", Lc.offset_ra, Lc.offset_dec);

   if( tcs_com( buf, buf, sizeof(buf), Lc.tcshostname) != ERR_NONE )
      rc = ERR_SOCKET_ERR;

   return rc;
}

/*--------------------------------------------------------------------------------
**  cal_offset_radec() -  calculates the RA,DEC offsets.
**--------------------------------------------------------------------------------
*/
void cal_offset_radec( void )
{
   double angle;

   angle = Lc.offset_angle * (M_PI/180.0);
   Lc.offset_ra  = Lc.offset_platescale *
                   ( ((Lc.offset_end_x-Lc.offset_beg_x)*cos(angle)) +
                     ((Lc.offset_end_y-Lc.offset_beg_y)*sin(angle)) );
   Lc.offset_dec = Lc.offset_platescale *
                   ( ((Lc.offset_beg_x-Lc.offset_end_x)*sin(angle)) +
                     ((Lc.offset_end_y-Lc.offset_beg_y)*cos(angle)) );
}

/*--------------------------------------------------------------------------------
**  do_path() - set the application's default data path.
**     Syntax: Path directory
**--------------------------------------------------------------------------------
*/
int do_path( int index, char * par )
{
   int l;
   char buf[256];
   char date[10];

   time_t      now = time((time_t *) 0);
   struct tm * today = gmtime( &now );

   if( par == NULL ) par = "$HOME";
   expand_pathname( buf, sizeof(buf), par );

   sprintf( date, "%02d%02d%02d", today->tm_year, today->tm_mon+1, today->tm_mday);
   str_replace_sub( buf, buf, sizeof(buf), "$DATE", date);

   if( exist_path( buf ) == -1 )
   {
       if( create_path( buf ) < 0 )
          return ERR_INV_PATH;
   }

   /* append '/' if not already present */
   l = strlen( buf );
   if( buf[l-1] != '/' )
      strcat( buf, "/");

#if DEBUG
   printf("copying %s to Lc.path\n", buf);
#endif
   strxcpy( Lc.path, buf, sizeof(Lc.path));
   strxcpy( Lc.dialog_path, buf, sizeof(Lc.dialog_path));

   /* set browse to path dialog */
   bfp_set_path( &Bfp_path, Lc.path );

   /* set file access dialogs */
   fad_set_path( &Fad_open, Lc.path );
   fad_set_path( &Fad_save, Lc.path );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_print() - Prints the current display in the drawingArea.
**     Syntax: Print dpinx
**--------------------------------------------------------------------------------
*/
int do_print( int index, char * par )
{
   int  dpinx,
        rc;
   FILE *fp;
   struct dpy_t *dp;
   char buf[60];

   /* get display index */
   if( (rc = parseIntR( &dpinx, par, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;
   dp = &Dpy[dpinx];

   /* check status */
   if( Buffer[dp->bufinx].status == DF_EMPTY )
      return ERR_BUF_EMPTY;

   /* Open Temper file */
   if( NULL == ( fp = fopen( "/tmp/dv_print.ps", "wt")) )
      return ERR_FILE_WRITE;

   /* Setup postscript file and make letter head */
   if( (rc = print_psheader( fp )) != ERR_NONE)
      goto err;

   /* Print fits header information */
   if( (rc = print_fitsheader( fp, dp )) != ERR_NONE)
      goto err;

   /* Print graphic */
   switch( dp->dpytype )
   {
      case DPYTYPE_IMAGE:
         if( Lc.printertype )
            rc = print_color_image(fp, dp );
         else
            rc = print_image(fp, dp );
         break;

      case DPYTYPE_HISTOGRAM:
         rc = print_histogram(fp, dp );
         break;

      case DPYTYPE_LINECUT:
         rc = print_linecut(fp, dp );
         break;

      case DPYTYPE_NOISE:
         rc = print_noise(fp, dp );
         break;

      case DPYTYPE_XLINECUT:
         rc = print_xcut(fp, dp );
         break;

      default:
         rc = print_gdummy(fp, dp );
         break;
   }
   if( rc != ERR_NONE)
      goto err;

   fprintf( fp, "showpage\n%%Trailer\n");
   fclose( fp );

   /* Send postscript file to printer */
   if( Lc.printtofile )
   {
      printTextOut( CM_GRAY, " Created /tmp/dv_print.ps. Did not sent to printer.\n");
   }
   else
   {
      sprintf( buf, "lp -c -s -d%s /tmp/dv_print.ps \n", Lc.printer);
      printTextOut( CM_GRAY, " Printer command: ");
      printTextOut( CM_GRAY, buf );
      system( buf );
      chmod( "/tmp/dv_print.ps", S_IRWXU | S_IRWXG | S_IRWXO );
   }
   return rc;

err:
   fclose( fp );
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_printer - Output postscript to this printer
**     Syntax: Pinter name
**--------------------------------------------------------------------------------
*/
int do_printer( int index, char * par )
{
   int rc;
   char buf[40];

   /* get the pathname */
   if( (rc=parseString( buf, sizeof(buf), par, " ")) != ERR_NONE )
      return rc;

   strxcpy( Lc.printer, buf, sizeof(Lc.printer));
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_printertype() - Identifies the type of printer.
**     Syntax: PrinterType { BW | Color }
**--------------------------------------------------------------------------------
*/
int do_printertype( int index, char * par )
{
   int ipar;

   /* get printertype */
   if( (ipar=parseSelection( par, " ", printer_selection)) < 0 )
      return ipar;

   Lc.printertype = ipar;
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_printtofile() - If TRUE the postscript print file is
**     created, but not sent to printer.
**     Syntax: PrintToFile { Off | On }
**--------------------------------------------------------------------------------
*/
int do_printtofile( int index, char * par )
{
   int ipar;

   if( (ipar=parseSelection( par, " ", offon_selection)) < 0 )
      return ipar;

   Lc.printtofile = ipar;
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_ptimagesize() - Sets the image size for the pointer display .
**     Syntax: noisemod num [dpinx]
**--------------------------------------------------------------------------------
*/
int do_ptimagesize( int index, char * par )
{
   int dpinx, size, rc;

   /* Get size */
   if( (rc = parseInt( &size, par, " ")) != ERR_NONE)
      return rc;

   /* must be odd & force range */
   if( iseven( size )) size++;
   if( size < 11 ) size = 11;
   if( size > 31 ) size = 31;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   Dpy[dpinx].pt_image_size = size;
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_push - pushes command on Lc.cmd_stack. Intended
**            for socket users.
**--------------------------------------------------------------------------------
*/
int do_push( int index, char * par )
{
   int l;
   char *cptr;

   if( par == NULL )
      return ERR_NONE;

   if( Lc.stack_inx >= NUM_CMD_STACK-1 )
      return ERR_INV_RNG;

   if( (l = strlen(par)) > 100 )
      l = 100;
   else
      l++;

   if( (cptr = malloc( l )) == NULL )
      return MEM_ALT_ERR;;

   strxcpy( cptr, par, l);

   Lc.cmd_stack[Lc.stack_inx] = cptr;
   Lc.stack_inx++;
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_quit() - exits the applications
**    Syntax: Quit
**--------------------------------------------------------------------------------
*/
int do_quit( int index, char * par )
{
   int i;

#if DEBUG
   printf("do_quit()\n");
#endif

   /* deallocated any colormap related resources */
   cm_free();

   /* deallocated any FITS lib resources  */
   for( i = 0; i<NUM_BUFFER; i++ )
      if( Buffer[i].status != DF_EMPTY ) df_free_fbuffer( &Buffer[i] );

   /* remove Networking resources */
   if( Lc.sock_tag )
      gdk_input_remove( Lc.sock_tag );
   if( Lc.sock_fd > 0 )
      close( Lc.sock_fd );

   /* Un-register the RPC program */
   (void) pmap_unset(DVRPCPROG, DVRPCVERS);

   /* OK, now quit GUI. */
   gtk_main_quit();
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_read - read a data file from (pathname) into (buf_id).
**  Syntax: Read fullpathname/file buf_id
**--------------------------------------------------------------------------------
*/
int do_read( int index, char * par )
{
   int  bufinx,
        fd,
        rc;
   char pathname[180];
   char dir[128];
   char filename[40];

   /* get the pathname */
   if( (rc=parseString( pathname, sizeof(pathname), par, " ")) != ERR_NONE )
      return rc;

   /* get buf_id */
   if( (bufinx=parseSelection( NULL, " ", buffer_selection)) < 0 )
      return bufinx;

   /* extract path & dir from pathname */
   filename_from_path( filename, pathname, sizeof(filename));
   dir_from_path( dir, pathname, sizeof(dir));

#if DEBUG
   printf("DO READ\n");
   printf("   Pathname: [%s]\n", pathname);
   printf("        dir: [%s]\n", dir);
   printf("   filename: [%s]\n", filename);
   printf("     bufinx: %d\n", bufinx);
#endif

   /*
   **  open file, try to read in a fits file, and close.
   */
   if( (fd = open(pathname, O_RDONLY)) < 0 )
      return  ERR_FILE_READ;

   rc = df_read_fits( fd, dir, filename, &Buffer[bufinx], FALSE, FALSE );
   close( fd );

   /*
   ** Update Dpy, Stats with bufinx
   */
   cal_box_stats( bufinx );
   redraw_dpydata_for_bufinx( bufinx );
   save_update_dialog( bufinx );

   /* update default path with last used directory */
   if( rc == ERR_NONE )
      do_path( 0, dir );

   return rc;
}

/*--------------------------------------------------------------------------------
**  do_readfile - reads a file in directory Lc.path
**  Syntax: Readfile filename buffer
**--------------------------------------------------------------------------------
*/
int do_readfile( int index, char * par )
{
   int  bufinx,
        fd, rc;
   char pathname[180];
   char filename[40];

   /* get the filename */
   if( (rc=parseString( filename, sizeof(filename), par, " ")) != ERR_NONE )
      return rc;

   /* get buf_id */
   if( (bufinx=parseSelection( NULL, " ", buffer_selection)) < 0 )
      return bufinx;

   /* Cat Lc.path & filename */
   cat_pathname( pathname, Lc.path, filename, sizeof(pathname));

#if DEBUG
   printf("DO READFILE\n");
   printf("   Pathname: [%s]\n", pathname);
   printf("   filename: [%s]\n", filename);
   printf("     bufinx: %d\n", bufinx);
#endif

   /*
   **  open file, try to read in a fits file, and close.
   */
   if( (fd = open(pathname, O_RDONLY)) < 0 )
      return  ERR_FILE_READ;

   rc = df_read_fits( fd, Lc.path, filename, &Buffer[bufinx], FALSE, FALSE );
   close( fd );

   /*
   ** Update Dpy, Stats with bufinx
   */
   cal_box_stats( bufinx );
   redraw_dpydata_for_bufinx( bufinx );
   save_update_dialog( bufinx );

   return rc;
}

/*--------------------------------------------------------------------------------
**  do_readmovie - reads a frame from a 3d Fits from (pathname) into (buf_id).
**  Syntax: ReadMovie fullpathname/file buf_id
**--------------------------------------------------------------------------------
*/
int do_readmovie( int index, char * par )
{
   int  bufinx,
        fd,
        rc;
   char pathname[180];
   char dir[128];
   char filename[40];

   /* get the pathname */
   if( (rc=parseString( pathname, sizeof(pathname), par, " ")) != ERR_NONE )
      return rc;

   /* get buf_id */
   if( (bufinx=parseSelection( NULL, " ", buffer_selection)) < 0 )
      return bufinx;

   /* extract path & dir from pathname */
   filename_from_path( filename, pathname, sizeof(filename));
   dir_from_path( dir, pathname, sizeof(dir));

   /*
   **  open file, try to read in a fits file, and close.
   */
   if( (fd = open(pathname, O_RDONLY)) < 0 )
      return  ERR_FILE_READ;

   rc = df_read_fits( fd, dir, filename, &Buffer[bufinx], FALSE, TRUE );
   close( fd );

   /*
   ** Update Dpy, Stats with bufinx
   */
   cal_box_stats( bufinx );
   redraw_dpydata_for_bufinx( bufinx );
   save_update_dialog( bufinx );

   return rc;
}


/*--------------------------------------------------------------------------------
**  do_readsock
**  Syntax: ReadSock bufid
**--------------------------------------------------------------------------------
*/
int do_readsock( int index, char * par )
{
   int  bufinx,
        rc;

   /* get buf_id */
   if( (bufinx=parseSelection( par, " ", buffer_selection)) < 0 )
      return bufinx;

   rc = df_read_fits( Lc.connect_fd, Lc.path, "unsaved.fts", &Buffer[bufinx],
                      TRUE, FALSE);

   /*
   ** Update Dpy, Stats with bufinx
   */
   cal_box_stats( bufinx );
   redraw_dpydata_for_bufinx( bufinx );
   save_update_dialog( bufinx );

   return rc;
}

/*--------------------------------------------------------------------------------
**  do_rotate() - rotate the image.
**     Syntax: rotate bufid { M90 | P90 | 180 }
**--------------------------------------------------------------------------------
*/
int do_rotate( int index, char * par )
{
   int dest, ops, rc;

   /* dest */
   if( (dest = parseSelection( par, " ", buffer_selection )) < 0 )
      return dest;

   /* operation - how much to rotate  */
   if( (ops = parseSelection( NULL, " ", rotate_selection )) < 0 )
      return ops;

   /* do it */
   rc = df_buffer_rotate( &Buffer[dest], &Buffer[dest], ops );

   /* refresh display */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_save - save a data buffer from (buf_id) into (pathname).
**  Syntax: Save fullpathname/file buf_id
**--------------------------------------------------------------------------------
*/
int do_save( int index, char * par )
{
   int  bufinx,
        fd,
        rc;
   char pathname[180];
   char dir[128];
   char filename[40];

#if DEBUG
   printf("saving [%s] \n", par );
#endif

   /* get the pathname */
   if( (rc=parseString( pathname, sizeof(pathname), par, " ")) != ERR_NONE )
      return rc;

   /* get buf_id */
   if( (bufinx=parseSelection( NULL, " ", buffer_selection)) < 0 )
      return bufinx;

   /* extract path & dir from pathname */
   filename_from_path( filename, pathname, sizeof(filename));
   dir_from_path( dir, pathname, sizeof(dir));

#if DEBUG
   printf("DO SAVE\n");
   printf("   Pathname: [%s]\n", pathname);
   printf("        dir: [%s]\n", dir);
   printf("   filename: [%s]\n", filename);
   printf("     bufinx: %d\n", bufinx);
#endif

   /*
   **  open/create file, try to write in a fits file, and close.
   */
   if( (fd = open(pathname, (O_CREAT|O_WRONLY|O_TRUNC), (S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH))) < 0 )
      return  ERR_FILE_CREATE;

   rc = df_write_fits( fd, dir, filename, &Buffer[bufinx] );
   close( fd );

   /*
   ** Update Dpy with bufinx
   */
   redraw_dpytitle_for_bufinx( bufinx );

   /* force file selection box to refresh path */
   fad_set_path( &Fad_open, Lc.path );
   fad_set_path( &Fad_save, Lc.path );

   /* update default path with last used directory */
   if( rc == ERR_NONE )
      do_path( 0, dir );


   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_savefile - save a file in directory Lc.path
**  Syntax: Savefile filename buffer
**--------------------------------------------------------------------------------
*/
int do_savefile( int index, char * par )
{
   int  bufinx,
        rc;
   char pathname[180];
   char filename[40];

   /* get the filename */
   if( (rc=parseString( filename, sizeof(filename), par, " ")) != ERR_NONE )
      return rc;

   /* get buf_id */
   if( (bufinx=parseSelection( NULL, " ", buffer_selection)) < 0 )
      return bufinx;

   /* Cat Lc.path & filename */
   cat_pathname( pathname, Lc.path, filename, sizeof(pathname));

#if DEBUG
   printf("DO SAVEFILE\n" );
   printf("   Pathname: [%s]\n", pathname);
   printf("   filename: [%s]\n", filename);
   printf("     bufinx: %d\n", bufinx);
#endif
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_showmovie() - Reads and Display all frames from a 3D Fits file.
**     Syntax: ShowMovie /path/filename bufid
**--------------------------------------------------------------------------------
*/
int do_showmovie( int index, char * par )
{
   int  bufinx,
        fd,
        i,
        rc;
   char pathname[180];
   char dir[128];
   char filename[40];

   /* get the pathname */
   if( (rc=parseString( pathname, sizeof(pathname), par, " ")) != ERR_NONE )
      return rc;

   /* get buf_id */
   if( (bufinx=parseSelection( NULL, " ", buffer_selection)) < 0 )
      return bufinx;

   /* extract path & dir from pathname */
   filename_from_path( filename, pathname, sizeof(filename));
   dir_from_path( dir, pathname, sizeof(dir));

   /*
   **  open file, try to read in a fits file, and close.
   */
   if( (fd = open(pathname, O_RDONLY)) < 0 )
      return  ERR_FILE_READ;

   rc = df_read_fits( fd, dir, filename, &Buffer[bufinx], FALSE, TRUE );

   /*
   ** Update Dpy, Stats with bufinx
   */
   cal_box_stats( bufinx );
   redraw_dpydata_for_bufinx( bufinx );
   save_update_dialog( bufinx );

   /*----------------------------------------------
   ** read and copy each move frame into the buffer.
   */
   for( i=1; i < Buffer[bufinx].nframes; i++ )
   {
      showmovie_readimage( fd, &Buffer[bufinx], i );

      cal_box_stats( bufinx );
      redraw_dpydata_for_bufinx( bufinx );
   }

   close( fd );

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  showmovie_readimage() - reads a frame from the 3D fits files into bp.
**--------------------------------------------------------------------------------
*/
int showmovie_readimage(
   int fd,               /* file descriptor of 3D fits file */
   struct df_buf_t * bp, /* buffer to hold data */
   int whichframe        /* which frame to read [0...n] */
)
{
   int rc,
       n,
       image_size,        /* nuber of byte in 1 image */
       numrec,            /* number of fits records to read */
       pixels_per_record, /* number of pixels in each FITS record */
       pixels_left,       /* counter */
       loop,
       i;
   float * dest;
   char *fits_buf;

   /* allocate a read buffer */
   if( NULL == (fits_buf = (char*)malloc( DF_FITS_RECORD_LEN)) )
      return MEM_ALT_ERR;
   rc = ERR_NONE;

   /*--------------------------------
   ** seek file pointer to start of image
   */
   image_size = bp->org_size * bp->naxis1 * bp->naxis2;
   n = bp->sizeof_header + (image_size * whichframe);

   if( lseek( fd, n, SEEK_SET) != n )
      { rc = ERR_FILE_READ; goto ldone; }

   /*-------------------------------------
   **
   */
   numrec = ceil( (float) bp->N * bp->org_size / DF_FITS_RECORD_LEN);
   pixels_per_record = DF_FITS_RECORD_LEN / bp->org_size;
   pixels_left = bp->N;
   dest  = bp->fdata;
   for(loop=0; loop < numrec; loop++)
   {
      /*  Read Next Record */
      n = read(fd, (char*)fits_buf, DF_FITS_RECORD_LEN);
      if( DF_FITS_RECORD_LEN != n )
         { rc =  ERR_FILE_READ; goto ldone; }

      if( bp->org_bitpix == DF_BITPIX_CHAR )
      {
         float pixel;
         unsigned char  *src = (char *)fits_buf;

         /* copy to bp->fdata */
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
            pixel = *src++;
            *dest++ = pixel;
            pixels_left--;
         }
      }
      else if( bp->org_bitpix == DF_BITPIX_SHORT )
      {
         float pixel;
         short  *src = (short *)fits_buf;

         /* copy to bp->fdata */
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
            pixel = (short) ntohs(*src++);
            *dest++ = pixel;
            pixels_left--;
         }
      }
      else if( bp->org_bitpix == DF_BITPIX_LONG )
      {
         float pixel;
         long  *src = (long *)fits_buf;

         /* copy to bp->fdata */
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
            pixel = (long) ntohl(*src++);
            *dest++ = pixel;
            pixels_left--;
         }
      }
      else if( bp->org_bitpix == DF_BITPIX_FLOAT )
      {
         union u_df_lf pixel;
         unsigned long  *src = (unsigned long *)fits_buf;

         /* copy to bp->fdata */
         for( i=0; i < pixels_per_record && pixels_left; i++)
         {
            pixel.l =  ntohl( *src++);
            *dest++ = pixel.f;
            pixels_left--;
         }
      }
      else
         { rc = ERR_INV_FORMAT; goto ldone; }
   }

   /* Apply bzero / bscale to data */
   if( (bp->org_bscale != 1.0) || (bp->org_bzero != 0) )
   {
      dest  = bp->fdata;
      for( i=0; i < bp->N; i++ )
      {
         *dest = (*dest * bp->org_bscale) + bp->org_bzero;
         dest++;
      }
   }

   /* fill in stats */
   df_stats( bp );

ldone:
   free( fits_buf );
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_smooth() - dv function to smooth the image.
**     Syntax: smooth src to dest
**--------------------------------------------------------------------------------
*/
int do_smooth( int index, char * par )
{
   int  dest, src, rc;

   /* src */
   if( (src = parseSelection( par, " ", buffer_selection )) < 0 )
      return src;

   /* to */
   if( (rc = parseSelection( NULL, " ", to_selection )) < 0 )
      return rc;

   /* dest */
   if( (dest = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return dest;

   rc = df_buffer_userfun( &Buffer[dest], &Buffer[src], my_smooth_fun);

   /* redraw destination frame */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

int my_smooth_fun(  struct df_buf_t *dest, struct df_buf_t *op1 )
{
   double sum;
   int x, y,
       xi, yi,
       inx,
       n;

   for( y=0; y < op1->naxis2; y++ )
   {
      for( x=0; x < op1->naxis1; x++ )
      {
         sum = 0;
         n = 0;

         for( yi=y-1; yi<=y+1; yi++ )
         {
            for( xi=x-1; xi<=x+1; xi++ )
            {
               if( INRANGE(0, yi, dest->naxis2-1) && INRANGE(0, xi, dest->naxis1-1))
               {
                  sum += dfdataxy( op1, xi, yi);
                  n++;
               }
            }
         }
         inx = y * op1->naxis1 + x;
         dest->fdata[inx] = sum / n;
      }
   }
   return 0;
}

/*--------------------------------------------------------------------------------
**  do_spexcom() - Issues a command to spex's IC.
**     Syntax: SpexCom command
**--------------------------------------------------------------------------------
*/
int do_spexcom( int index, char * par )
{
   if( par == NULL )
      return ERR_NONE;

   return spex_com( par );
}

/*--------------------------------------------------------------------------------
**  do_sqrt() - Takes a square root of an image.
**     Syntax: sqrt src to dest
**--------------------------------------------------------------------------------
*/
int do_sqrt( int index, char * par )
{
   int  dest, src, rc;

   /* src */
   if( (src = parseSelection( par, " ", buffer_selection )) < 0 )
      return src;

   /* to */
   if( (rc = parseSelection( NULL, " ", to_selection )) < 0 )
      return rc;

   /* dest */
   if( (dest = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return dest;

   rc = df_buffer_math( &Buffer[dest], &Buffer[src], &Buffer[src], DF_MATH_SQRT);

   /* redraw destination frame */
   cal_box_stats( dest );
   redraw_dpydata_for_bufinx( dest );
   save_update_dialog( dest );
   return rc;
}

/*--------------------------------------------------------------------------------
**  do_statsfixedwh() - Controls the ability to set/fix the wid, hgt of the stats box.
**  Syntax: StatsFixedWH bufid { off | on } [wid hgt]
**--------------------------------------------------------------------------------
*/
int do_statsfixedwh( index, par )
   int index;
   char * par;
{
   int bufinx,
       offon,
       wid, hgt,
       x, y,
       rc;

   /* Get bufid */
   if( (bufinx = parseSelection( par, " ", buffer_selection )) < 0 )
      return bufinx;

   /* Get offon */
   if( (offon = parseSelection( NULL, " ", offon_selection )) < 0 )
      return offon;

   /* Get wid - optional defaults to current width if not specified. */
   if( (rc = parseIntR( &wid, NULL, " ", 0, NUM_PIXEL)) != ERR_NONE)
      wid = Stats[bufinx].objwid;

   /* Get hgt - optional defaults to current height if not specified. */
   if( (rc = parseIntR( &hgt, NULL, " ", 0, NUM_PIXEL)) != ERR_NONE)
      hgt = Stats[bufinx].objhgt;

   /* if no data in buffer, just return */
   if( Buffer[bufinx].status == DF_EMPTY )
   {
      Stats[bufinx].fixedWH = offon;
      Stats[bufinx].objwid = wid;
      Stats[bufinx].objhgt = hgt;
      return ERR_NONE;
   }

   /* Fixup x, y, wid, hgt to fit inside image */
   if( wid > Buffer[bufinx].naxis1 ) wid = Buffer[bufinx].naxis1;
   if( hgt > Buffer[bufinx].naxis2 ) hgt = Buffer[bufinx].naxis2;

   x = Stats[bufinx].objx;
   if( x > (Buffer[bufinx].naxis1 - wid)) x = Buffer[bufinx].naxis1 - wid;

   y = Stats[bufinx].objy;
   if( y > (Buffer[bufinx].naxis2 - hgt)) y = Buffer[bufinx].naxis2 - hgt;

   /* Erase old box and draw new one */
   draw_xor_box_on_buffer( bufinx, Stats[bufinx].objx,   Stats[bufinx].objy,
                                 Stats[bufinx].objwid, Stats[bufinx].objhgt);
   draw_xor_box_on_buffer( bufinx, x, y, wid, hgt);

   /* set new parameters */
   Stats[bufinx].fixedWH = offon;
   Stats[bufinx].objx   = x;
   Stats[bufinx].objy   = y;
   Stats[bufinx].objwid = wid;
   Stats[bufinx].objhgt = hgt;

   /* Update calculations and update screen */
   cal_box_stats( bufinx );
   redraw_dpytype_stats_for_bufinx(bufinx);

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_statsobjbox() - set the object position and box size.
**  Syntax: StatsObjBox x, y, wid, hgt bufid
**--------------------------------------------------------------------------------
*/
int do_statsobjbox( int index, char * par )
{
   int x, y, wid, hgt, bufinx,
       rc;

   /* parse parameters: x, y wid, hgt, & bufinx */
   if( (rc = parseIntR( &x, par, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &y, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &wid, NULL, " ", 0, NUM_PIXEL-x)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &hgt, NULL, " ", 0, NUM_PIXEL-y)) != ERR_NONE)
      return rc;
   if( (bufinx = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return bufinx;

   /* Erase old box and draw new one */
   draw_xor_box_on_buffer( bufinx, Stats[bufinx].objx,   Stats[bufinx].objy,
                                 Stats[bufinx].objwid, Stats[bufinx].objhgt);
   draw_xor_box_on_buffer( bufinx, x, y, wid, hgt);

   /* Store new values in Stats array */
   Stats[bufinx].objx = x;
   Stats[bufinx].objy = y;
   Stats[bufinx].objwid = wid;
   Stats[bufinx].objhgt = hgt;

   /* Update calculations and update screen */
   cal_box_stats( bufinx );  /* cal stats only if buffer is referenced */
   redraw_dpytype_stats_for_bufinx(bufinx);

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_statssetsky() - set the sky position and box size to equal the object's.
**  Syntax: StatsSetSky bufinx
**--------------------------------------------------------------------------------
*/
int do_statssetsky( index, par )
   int index;
   char * par;
{
   int bufinx;

   /* Get bufid */
   if( (bufinx = parseSelection( par, " ", buffer_selection )) < 0 )
      return bufinx;

   Stats[bufinx].skyx = Stats[bufinx].objx;
   Stats[bufinx].skyy = Stats[bufinx].objy;
   Stats[bufinx].skywid = Stats[bufinx].objwid;
   Stats[bufinx].skyhgt = Stats[bufinx].objhgt;

   /* Update calculations and update screen */
   cal_box_stats( bufinx );
   redraw_dpytype_stats_for_bufinx(bufinx);

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_statsxorline() - sets the position of the xor line.
**  Syntax: Statsxorline xbeg, ybeg, xend, yend  bufid
**--------------------------------------------------------------------------------
*/
int do_statsxorline( int index, char * par )
{
   int xbeg, ybeg, xend, yend, bufinx,
       rc;

   /* parse parameters:  xbeg, ybeg, xend, yend, & bufinx  */
   if( (rc = parseIntR( &xbeg, par, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &ybeg, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &xend, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (rc = parseIntR( &yend, NULL, " ", 0, NUM_PIXEL-1)) != ERR_NONE)
      return rc;
   if( (bufinx = parseSelection( NULL, " ", buffer_selection )) < 0 )
      return bufinx;

   /* Erase old box and draw new one */
   draw_xor_line_on_buffer( bufinx, Stats[bufinx].ln_xbeg, Stats[bufinx].ln_ybeg,
                                    Stats[bufinx].ln_xend, Stats[bufinx].ln_yend);
   draw_xor_line_on_buffer( bufinx, xbeg, ybeg, xend, yend);

   /* Store new values in Stats array */
   Stats[bufinx].ln_xbeg = xbeg;
   Stats[bufinx].ln_ybeg = ybeg;
   Stats[bufinx].ln_xend = xend;
   Stats[bufinx].ln_yend = yend;

   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_tcshostname() - Name the tcs interface computer
**--------------------------------------------------------------------------------
*/
int do_tcshostname( int index, char *par )
{
   if( par == NULL) par = "vtcshost";

   strxcpy( Lc.tcshostname, par, sizeof(Lc.tcshostname));
    gtk_entry_set_text( GTK_ENTRY(TCShostname_w), Lc.tcshostname );
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_usefitsanglescale() - If TRUE the TCS offsets are calculated
**     using the Position Angle variable in the FITS header.
**     Syntax: UseFITSPositionAngle { Off | On }
**--------------------------------------------------------------------------------
*/
int do_usefitsanglescale( int index, char * par )
{
   int ipar;

   if( (ipar=parseSelection( par, " ", offon_selection)) < 0 )
      return ipar;

   Lc.usefitsanglescale = ipar;
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_UseHex() - Displays pixel values in hex or decmial.
**     Syntax:  UseHex { off | on }
**--------------------------------------------------------------------------------
*/
int do_usehex( int index, char * par )
{
   int ipar;

   if( (ipar = parseSelection( par, " ", offon_selection )) < 0 )
      return ipar;

   Lc.usehex = ipar;
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_xcutautoscale() - Set the autoscale of the XLineCut graph
**     Syntax: XCutAutoScale off|on
**--------------------------------------------------------------------------------
*/
int do_xcutautoscale( int index, char * par )
{
   int scale,
       dpinx,
       rc;

   /* Get scale */
   if( (scale = parseSelection( par, " ", imageautoscale_selection )) < 0 )
      return scale;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   if( Dpy[dpinx].xcut_autoscale != scale )
   {
      Dpy[dpinx].xcut_autoscale = scale;

      if( Dpy[dpinx].dpytype == DPYTYPE_XLINECUT )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_xcutrange() - Sets the range of the XLineCut graph.
**     Syntax:  XCutRange min max
**--------------------------------------------------------------------------------
*/
int do_xcutrange( int index, char * par )
{
   int dpinx,
       rc;
   long min, max;

   /* Get max & min */
   if( (rc = parseLong( &min, par, " ")) != ERR_NONE)
      return rc;
   if( (rc = parseLong( &max, NULL, " ")) != ERR_NONE)
      return rc;

   if( max <= min )
      return ERR_INV_FORMAT;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   /* update */
   Dpy[dpinx].xcut_autoscale = FALSE;
   if( Dpy[dpinx].xcut_min != min || Dpy[dpinx].xcut_max != max )
   {
      Dpy[dpinx].xcut_min = min;
      Dpy[dpinx].xcut_max = max;
      if( Dpy[dpinx].dpytype == DPYTYPE_XLINECUT )
         call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/*--------------------------------------------------------------------------------
**  do_xcutset() - Set the coordinates of the XLineCut
**     Syntax: XCutSet xbeg ybeg xend yend
**--------------------------------------------------------------------------------
*/
int do_xcutset( int index, char * par )
{
   long lpar;
   int  xbeg, ybeg, xend, yend, dpinx,
        rc;
   char *cptr;

   /* Get x, y, wid, hgt */
   if( (NULL == (cptr=strtok(par, " ,"))) || (-1 == my_atol(cptr, &lpar)) )
      return ERR_INV_FORMAT;
   xbeg = lpar;
   if( (NULL == (cptr=strtok(NULL, " ,"))) || (-1 == my_atol(cptr, &lpar)) )
      return ERR_INV_FORMAT;
   ybeg = lpar;
   if( (NULL == (cptr=strtok(NULL, " ,"))) || (-1 == my_atol(cptr, &lpar)) )
      return ERR_INV_FORMAT;
   xend = lpar;
   if( (NULL == (cptr=strtok(NULL, " ,"))) || (-1 == my_atol(cptr, &lpar)) )
      return ERR_INV_FORMAT;
   yend = lpar;
   if( !INRANGE(0, xbeg, NUM_PIXEL-1) || !INRANGE(0, ybeg, NUM_PIXEL-1) ||
       !INRANGE(0, xend, NUM_PIXEL-1) || !INRANGE(0, yend, NUM_PIXEL-1) )
      return ERR_INV_RNG;

   /* Get dpinx */
   if( (rc = parseIntR( &dpinx, NULL, " ", 0, Lc.num_dpy-1)) != ERR_NONE)
      dpinx = Lc.active;

   if( Dpy[dpinx].xcut_xbeg!=xbeg || Dpy[dpinx].xcut_ybeg!=ybeg ||
       Dpy[dpinx].xcut_xend!=xend || Dpy[dpinx].xcut_yend!=yend )
   {
       Dpy[dpinx].xcut_xbeg = xbeg;
       Dpy[dpinx].xcut_ybeg = ybeg;
       Dpy[dpinx].xcut_xend = xend;
       Dpy[dpinx].xcut_yend = yend;
       if( Dpy[dpinx].dpytype == DPYTYPE_XLINECUT )
          call_dpydata_redraw( dpinx );
   }
   return ERR_NONE;
}

/********************************************************************************/
/*  Helper Functions                                                            */
/********************************************************************************/

/*--------------------------------------------------------------------------------
**  int qsort_comp_string( i, j ) - Macro Dialog.
**--------------------------------------------------------------------------------
*/
int qsort_comp_string( char **i, char **j)
{
   int r;
   r = strcmp(*i, *j);
   return r;
}

/*--------------------------------------------------------------------------------
**  math_fixstring() - fixes up the math string by padding each element
**  with a space. So the user doesn't have to.
**--------------------------------------------------------------------------------
*/
int math_fixstring(
   char * scr,
   int    scr_size)    /* Max len of scr */
{
   int d, s, count;
   char dest[40];

   d = s = count = 0;
   while( (d < sizeof(dest)-5) && (scr[s] != 0))
   {
      if( (scr[s]=='='|| scr[s]=='+' || scr[s]=='-' || scr[s]=='*' || scr[s]=='/')
           && count < 2 )
      {
         dest[d++] = ' ';
         dest[d++] = scr[s++];
         dest[d++] = ' ';
         count++;
      }
      else
         dest[d++] = scr[s++];
   }
   dest[d] = 0;
   strxcpy( scr, dest, scr_size);
   return ERR_NONE;
}

/****************************************************************************/
/****************************************************************************/
