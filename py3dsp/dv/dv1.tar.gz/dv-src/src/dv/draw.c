/********************************************************************************/
/*  DRAW.C - drawing routines which can be applied to drawing_area widgets.     */
/********************************************************************************/

#define EXTERN extern

/*-----------------------------
**  Standard include files
**-----------------------------
*/

#include <sys/stat.h>
#include <sys/time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

/*-----------------------------
**  Non-standard include files
**-----------------------------
*/
#include <error_msg.h>
#include <addlib.h>
#include <dflib.h>

#include "cm.h"           /* include colormap information  */
#include "dialog.h"       /* include path dialog box */

#include "dv.h"           /* DV MAIN APPLICATION  */

static int Box_x,     /* Used in dpydata_*_event() function to keep track of */
           Box_y;     /* begining of the XOR boxes.                          */

/********************************************************************************/
/*  Colormap_w functions - drawing_area repaint, event, etc.                    */
/********************************************************************************/

/*----------------------------------------------------------------------------
**  colormap_configure_event() - configure event handler for Colormap_w
**----------------------------------------------------------------------------
*/
int colormap_configure_event( GtkWidget *widget, GdkEventConfigure *event )
{
   return TRUE;
}

/*----------------------------------------------------------------------------
**  colormap_expose_event() - expose event handler for Colormap_w
**----------------------------------------------------------------------------
*/
int colormap_expose_event( GtkWidget *widget, GdkEventExpose *event )
{
   colormap_redraw( widget );
   return FALSE;
}

/*----------------------------------------------------------------------------
**  call_colormap_redraw() - dv code calls this to refresh the colormap area.
**----------------------------------------------------------------------------
*/
void call_colormap_redraw( void )
{
   colormap_redraw( Colormap_w );
}

/*----------------------------------------------------------------------------
**  colormap_redraw() - display a colormap in the window.
**----------------------------------------------------------------------------
*/
void colormap_redraw( GtkWidget *da )
{
   int i,
       color,
       da_wid, da_hgt;
   GdkImage *image;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   image = gdk_image_new( GDK_IMAGE_NORMAL, CM.visual, da_wid, da_hgt );
   if( image == NULL )
      return;
#if DEBUG
   printf("colormap_redraw(): image: %dx%dx%d\n", image->width, image->height, image->depth );
#endif
   if( CM.visual->type == GDK_VISUAL_PSEUDO_COLOR)
   {
      unsigned char *cbuf = (char *) image->mem;

      /* fill in 1st scan line */
      for( i=0; i< da_wid; i++)
      {
         color = map( i, 0, da_wid-1, CM_NUM_STATIC_COLORS, CM_NUM_COLORS-1);
         cbuf[i] =  CM.colors[color].pixel;
      }
      /* copy 1st line to fill hgt of image buffer */
      for( i=0; i< da_hgt; i++)
         memcpy( cbuf+(i*da_wid), cbuf, da_wid);
   }
   else if( CM.visual->type == GDK_VISUAL_TRUE_COLOR)
   {
      unsigned long *lbuf = (long *) image->mem;
      /* fill in 1st scan line */
      for( i=0; i< da_wid; i++)
      {
         color = map( i, 0, da_wid-1, CM_NUM_STATIC_COLORS, CM_NUM_COLORS-1);
         lbuf[i] =  CM.colors[color].pixel;
      }
      /* copy 1st line to fill hgt of image buffer */
      for( i=0; i< da_hgt; i++)
         memcpy( lbuf+(i*da_wid), lbuf, da_wid*sizeof(long));
   }

   gdk_draw_image( da->window, Nor_gc, image, 0, 0, 0, 0, da_wid, da_hgt);
   gdk_image_destroy( image );
}

/********************************************************************************/
/*  dpytitle drawingArea's signal functions - drawing_area repaint, event, etc. */
/********************************************************************************/
/*----------------------------------------------------------------------------
**  dpytitle_configure_event() - configure event handler for dpytitle Drawing Area
**----------------------------------------------------------------------------
*/
int dpytitle_configure_event( GtkWidget *widget, GdkEventConfigure *event )
{
   return TRUE;
}
/*----------------------------------------------------------------------------
**  dpytitle_expose_event() - expose event handler for dpytitle Drawing Area
**----------------------------------------------------------------------------
*/
int dpytitle_expose_event( GtkWidget *widget, GdkEventExpose *event )
{
   dpytitle_redraw( widget );
   return FALSE;
}

/*----------------------------------------------------------------------------
**  call_dpytitle_redraw() - dv code calls this to refresh a dpytitle area.
**----------------------------------------------------------------------------
*/
void call_dpytitle_redraw( int dpinx )
{
   dpytitle_redraw( Dpy[dpinx].title_drawingarea );
}

/*-------------------------------------------------------------------------------
**  redraw_dpytitle_for_bufinx() - Calls the redraw function for the dpytitle_w
**      for all dpy using bufinx.
**-------------------------------------------------------------------------------
*/
void redraw_dpytitle_for_bufinx( int bufinx )
{
   int dpinx;

   for( dpinx = 0; dpinx < Lc.num_dpy; dpinx++ )
      if( Dpy[dpinx].bufinx == bufinx )
         call_dpytitle_redraw( dpinx );
}

/*----------------------------------------------------------------------------
**  dpytitle_redraw() - DPY.Title area's main redraw function.
**----------------------------------------------------------------------------
*/
void dpytitle_redraw( GtkWidget *da )
{
   int dpinx,
       da_wid, da_hgt;
   char buf[80];
   struct dpy_t *dp;
   struct df_buf_t *bp;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   /* get display / data buffer info */
   dpinx = (int) gtk_object_get_user_data( GTK_OBJECT(da));
   dp = &Dpy[dpinx];
   bp = &Buffer[dp->bufinx];
   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   /* clears window  or set to yellow for active display */
   if( dpinx == Lc.active )
   {
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW] );
      gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);
   }
   else
      gdk_window_clear( da->window );

   /* display information */
   if( bp->status == DF_EMPTY )
      sprintf( buf, "%d. %s = Empty buffer (%dx%d)", dpinx, buffer_selection[dp->bufinx],
         da_wid, da_hgt);
   else
      sprintf( buf, "%d. %s = %s/%d ", dpinx, buffer_selection[dp->bufinx],
         bp->filename,  (int)(Lc.divbydivisor ? bp->divisor : 1));

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, 2, Fixed_font_hgt, buf );
}

/********************************************************************************/
/*  dpytitle IO events                                                          */
/********************************************************************************/

/*------------------------------------------------------------------------
**  dpytitle_button_press_event() - catches mouse button presses....
**------------------------------------------------------------------------
*/
int dpytitle_button_press_event (GtkWidget *da, GdkEventButton *event, gpointer data )
{
   char buf[40];
   int dpinx = (int) data;

   sprintf( buf, "Active %d ", dpinx );
   cmd_execute( buf, FALSE );
   return TRUE;
}

/********************************************************************************/
/*  dpydata drawingArea's signal functions - drawing_area repaint, event, etc.  */
/********************************************************************************/
/*----------------------------------------------------------------------------
**  dpydata_configure_event() - configure event handler for dpydata Drawing Area
**----------------------------------------------------------------------------
*/
int dpydata_configure_event( GtkWidget *widget, GdkEventConfigure *event )
{
   return TRUE;
}
/*----------------------------------------------------------------------------
**  dpydata_expose_event() - expose event handler for dpydata Drawing Area
**----------------------------------------------------------------------------
*/
int dpydata_expose_event( GtkWidget *widget, GdkEventExpose *event )
{
   dpydata_redraw( widget );
   return FALSE;
}

/*----------------------------------------------------------------------------
**  call_dpydata_redraw() - dv code calls this to refresh a dpydata area.
**----------------------------------------------------------------------------
*/
void call_dpydata_redraw( int dpinx )
{
   dpydata_redraw( Dpy[dpinx].data_drawingarea );
}

/*-------------------------------------------------------------------------------
**  redraw_dpydata_for_bufinx() - Calls the redraw function for the dpytitle_w
**      for all dpy using bufinx.
**-------------------------------------------------------------------------------
*/
void redraw_dpydata_for_bufinx( int bufinx )
{
   int dpinx;

   for( dpinx = 0; dpinx < Lc.num_dpy; dpinx++ )
      if( Dpy[dpinx].bufinx == bufinx )
         call_dpydata_redraw( dpinx );
}

/*---------------------------------------------------------------------------
** redraw_dpytype_stats_for_bufinx( int bufinx )
**-------------------------------------------------------------------------------
*/
void redraw_dpytype_stats_for_bufinx( int bufinx )
{
   int dpinx;

   for( dpinx = 0; dpinx < Lc.num_dpy; dpinx++ )
      if( (Dpy[dpinx].bufinx == bufinx)  && (Dpy[dpinx].dpytype==DPYTYPE_STATS) )
         call_dpydata_redraw( dpinx );
}

/*----------------------------------------------------------------------------
**  dpydata_redraw() - DPY.Title area's main redraw function.
**----------------------------------------------------------------------------
*/
void dpydata_redraw( GtkWidget *da )
{
   int dpinx;
   struct dpy_t *dp;
   struct df_buf_t *bp;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   /* get display / data buffer info */
   dpinx = (int) gtk_object_get_user_data( GTK_OBJECT(da));
   dp = &Dpy[dpinx];
   bp = &Buffer[dp->bufinx];

   /* display information */
   if( bp->status == DF_EMPTY )
      draw_X( da, dp, bp );
   else
   {
      switch( Dpy[dpinx].dpytype )
      {
         case DPYTYPE_IMAGE:
            draw_image( da, dp, bp );
            break;

         case DPYTYPE_HEADER:
            draw_header( da, dp, bp );
            break;

         case DPYTYPE_HISTOGRAM:
            draw_histogram( da, dp, bp );
            break;

         case DPYTYPE_LINECUT:
            draw_linecut( da, dp, bp );
            break;

         case DPYTYPE_XLINECUT:
            draw_xcut( da, dp, bp );
            break;

         case DPYTYPE_NOISE:
            draw_noise( da, dp, bp );
            break;

         case DPYTYPE_POINTER:
            draw_pointer( da, dp, bp );
            break;

         case DPYTYPE_STATS:
            draw_stats( da, dp, bp );
            break;

         default:
            draw_X( da, dp, bp );
            break;
      }
   }
   /*
   ** Update scroll bars...
   */
   update_scrollbars( dpinx );

   /*
   ** Update Dpytitle display
   */
   call_dpytitle_redraw( dpinx );
}

/********************************************************************************/
/*  dpydata IO events                                                           */
/********************************************************************************/

/*------------------------------------------------------------------------
**  dpydata_button_press_event() - catches mouse button presses....
**------------------------------------------------------------------------
*/
int dpydata_button_press_event (GtkWidget *da, GdkEventButton *event, gpointer data )
{
   int x, y,              /* xy location of pointer */
       da_wid, da_hgt;
   char buf[60];

   struct dpy_t *dp    = &Dpy[(int) data ];
   struct df_buf_t *bp = &Buffer[dp->bufinx];

   /* handle event for DPYTYPE_IMAGE and non-empty buffers, otherwise return */
   if( (dp->dpytype != DPYTYPE_IMAGE) || (bp->status == DF_EMPTY ))
      return TRUE;

   /* get info about event */
   x = event->x;
   y = event->y;

   /* get info drawing area */
   gdk_window_get_size( da->window, &da_wid, &da_hgt );

   /* convert (x,y) to pixel location; return if pointer is outside image  */
   {
      float pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));
      x = dp->image_offx + ( x / pixel_wid);
      y = dp->image_offy + ( y / pixel_wid);

      if( !INRANGE( 0, x, bp->naxis1-1) || !INRANGE(0, y, bp->naxis2-1))
         return TRUE;
   }

   /*--------------------------------------------
   ** Screen for event and respond...
   */
   if( event->button == 1 )
   {
      /* Pushing button 1, centers the box at the cursor location.
      ** Also, let's grab the keyboard focus.
      */
      int wid = Stats[dp->bufinx].objwid;
      int hgt = Stats[dp->bufinx].objhgt;
      sprintf( buf, "StatsObjBox  %d %d %d %d %c ", x - (wid/2), y-(hgt/2), wid, hgt,  'A'+dp->bufinx);
      cmd_execute( buf, TRUE );

      gtk_widget_grab_focus( da );
   }
   else if( event->button == 2 )
   {
      /* Pushing button 2, initializes the upper-left position of the Box
      */
      Box_x = x;
      Box_y = y;

#if 0
      /*-------------------------------------------------
      ** Update TCS offset coordinates.
      */
      Lc.offset_beg_x = x;
      Lc.offset_beg_y = y;
      if( Lc.usefitsanglescale )
      {
         Lc.offset_angle      = bp->pos_angle;
         Lc.offset_platescale = bp->arcsec_pixel;
      }
      cal_offset_radec( );
      update_offset_widgets();
#endif
   }
   return TRUE;
}

/*------------------------------------------------------------------------
**  dpydata_motion_notify_event() - catches mouse motion events....
**------------------------------------------------------------------------
*/
int dpydata_motion_notify_event (GtkWidget *da, GdkEventMotion *event, gpointer data )
{
   int x, y,              /* xy location of pointer */
       da_wid, da_hgt,
       l;
   char buf[60];
   GdkModifierType state;

   int dpinx = (int) data;
   struct dpy_t *dp    = &Dpy[dpinx];
   struct df_buf_t *bp = &Buffer[dp->bufinx];

   /* handle event for DPYTYPE_IMAGE and non-empty buffers, otherwise return */
   if( (dp->dpytype != DPYTYPE_IMAGE) || (bp->status == DF_EMPTY ))
      return TRUE;

   /* get info about event */
   if (event->is_hint)
      gdk_window_get_pointer (event->window, &x, &y, &state);
   else
   {
      x = event->x;
      y = event->y;
      state = event->state;
   }

   /* get info drawing area */
   gdk_window_get_size( da->window, &da_wid, &da_hgt );

   /* convert (x,y) to pixel location; return if pointer is outside image  */
   {
      float pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));
      x = dp->image_offx + ( x / pixel_wid);
      y = dp->image_offy + ( y / pixel_wid);

      if( !INRANGE( 0, x, bp->naxis1-1) || !INRANGE(0, y, bp->naxis2-1))
         return TRUE;
   }

   /*--------------------------------------------
   ** Screen for event and respond...
   */
   if( (state & (GDK_BUTTON2_MASK|GDK_SHIFT_MASK)) == (GDK_BUTTON2_MASK|GDK_SHIFT_MASK) )
   {
      /* Dragging the mouse while hold down button 2 & the shift Key,
      ** changes the xor line.
      */
      sprintf( buf, "StatsXORLine %d %d %d %d %c ", Box_x, Box_y, x, y, 'A'+dp->bufinx);
      cmd_execute( buf, TRUE );

      /*-------------------------------------------------
      ** Update offset coordinates.
      */
      Lc.offset_beg_x = Box_x;
      Lc.offset_beg_y = Box_y;
      Lc.offset_end_x = x;
      Lc.offset_end_y = y;
      if( Lc.usefitsanglescale )
      {
         Lc.offset_angle      = bp->pos_angle;
         Lc.offset_platescale = bp->arcsec_pixel;
      }
      cal_offset_radec( );
      update_offset_widgets();
   }
   else if( state & GDK_BUTTON2_MASK )
   {
      /* Dragging the mouse while hold down button 2, change the wid & hgt of the objbox.
      */
      int wid = x-Box_x+1;
      int hgt = y-Box_y+1;
      if( wid > 0 && hgt > 0 && !Stats[dp->bufinx].fixedWH)
      {
         sprintf( buf, "StatsObjBox %d %d %d %d %c ", Box_x, Box_y, x-Box_x+1, y-Box_y+1, 'A'+dp->bufinx);
         cmd_execute( buf, FALSE );
      }

      /*-------------------------------------------------
      ** Update offset coordinates.
      */
#if 0
       Lc.offset_end_x = x;
      Lc.offset_end_y = y;
      if( Lc.usefitsanglescale )
      {
         Lc.offset_angle      = bp->pos_angle;
         Lc.offset_platescale = bp->arcsec_pixel;
      }
      cal_offset_radec( );
      update_offset_widgets();
#endif
   }
   else if( state & GDK_BUTTON3_MASK )
   {
      /* mouse motion with Button 3 pressed, changes the colormap
      ** width and center variables.
      */
      float f;

      f = (float) event->x / da_wid;
      if( INRANGE( 0.0, f, 1.0 ))
         CM.center = f;

      f = (float) event->y / da_hgt;
      if( INRANGE( 0.01, f, 3.0 ))
         CM.width = f;

      cm_set_colormap( &CM );
   }
   else
   {
      /* plain mouse motion, displays "[x,y] = value" in  title
      ** And Update the Pointer Display (if configured).
      */
      int   xp;
      float data = dfdataxy( bp, x, y );

      if( Lc.usehex )
         sprintf( buf, " [%3d,%3d]=0x%08lx ", x, y, (long)data);
      else
      {
         if( INRANGE(-10.0, data, 10.0))
            sprintf( buf, " [%3d,%3d]=%8.4f ", x, y, data);
         else if( INRANGE( -1000.0, data, 1000.0))
            sprintf( buf, " [%3d,%3d]=%8.2f ", x, y, data);
         else
            sprintf( buf, " [%3d,%3d]=%8.1f ", x, y, data);
      }

      l = strlen( buf );
      xp = da_wid - ((l-1)*Fixed_font_wid);

      /* draw text on status window */
      if( dpinx == Lc.active )
      {
          gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
          gdk_draw_rectangle( dp->title_drawingarea->window, Nor_gc, TRUE, xp, 1,
                   l*Fixed_font_wid, Fixed_font_hgt);
      }
      else
         gdk_window_clear_area( dp->title_drawingarea->window, xp, 1,
         l*Fixed_font_wid, Fixed_font_hgt);

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);
      gdk_draw_text( dp->title_drawingarea->window, Fixed_font, Nor_gc, xp, Fixed_font_hgt, buf, l);

      /*-------------------------------------------------
      ** Find display with pointer_display, and redraw.
      */
      for( l=0; l<Lc.num_dpy; l++)
      {
         if( (Dpy[l].dpytype == DPYTYPE_POINTER))
            draw_pointer_update( Dpy[l].data_drawingarea, l, x, y, dpinx );
      }
   }

   return TRUE;
}

/*------------------------------------------------------------------------
**  dpydata_key_press_event() - catches keyboard presses....
**------------------------------------------------------------------------
*/
int dpydata_key_press_event (GtkWidget *da, GdkEventKey *event, gpointer data )
{
   int x, y,              /* xy location of pointer */
       dx, dy,
       da_wid, da_hgt;
   GdkModifierType state;
   char buf[60];

   struct dpy_t *dp    = &Dpy[(int) data ];
   struct df_buf_t *bp = &Buffer[dp->bufinx];

   /* handle event for DPYTYPE_IMAGE and non-empty buffers, otherwise return */
   if( (dp->dpytype != DPYTYPE_IMAGE) || (bp->status == DF_EMPTY ))
      return TRUE;

   /* get info about event & drawing area */
   gdk_window_get_pointer (event->window, &x, &y, &state);
   gdk_window_get_size( da->window, &da_wid, &da_hgt );

   /* convert (x,y) to pixel location; return if pointer is outside image  */
   {
      float pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));
      x = dp->image_offx + ( x / pixel_wid);
      y = dp->image_offy + ( y / pixel_wid);

      if( !INRANGE( 0, x, bp->naxis1-1) || !INRANGE(0, y, bp->naxis2-1))
         return TRUE;
   }

   /*--------------------------------------------
   ** Screen for event and respond...
   */
   /* dx, dy signal a change in position of the objbox */
   dx = 0;
   dy = 0;

   switch (event->keyval)
   {
      case GDK_Up:
         /* Up arrow move the objbox 1 pixel up */
         dy = -1;
      break;

      case GDK_Down:
         /* Down arrow move the objbox 1 pixel down */
         dy = 1;
      break;

      case GDK_Left:
         /* Left arrow move the objbox 1 pixel left */
         dx = -1;
      break;

      case GDK_Right:
         /* Right arrow move the objbox 1 pixel right */
         dx = 1;
      break;

      case 'L':
      case 'l':
         sprintf( buf, "LCutXY %d %d ", x, y);
         cmd_execute( buf, TRUE );
      break;

      case 'F':
      case 'f':
			/*-------------------------------------------------
			** Update offset coordinates.
			*/
			Lc.offset_beg_x = x;
			Lc.offset_beg_y = y;
			if( Lc.usefitsanglescale )
			{
				Lc.offset_angle      = bp->pos_angle;
				Lc.offset_platescale = bp->arcsec_pixel;
			}
			cal_offset_radec( );
			update_offset_widgets();
      break;

      case 'T':
      case 't':
			/*-------------------------------------------------
			** Update offset coordinates.
			*/
			Lc.offset_end_x = x;
			Lc.offset_end_y = y;
			if( Lc.usefitsanglescale )
			{
				Lc.offset_angle      = bp->pos_angle;
				Lc.offset_platescale = bp->arcsec_pixel;
			}
			cal_offset_radec( );
			update_offset_widgets();
   }

   /* if dx, dy has changed, move objbox */
   if( dx || dy )
   {
      sprintf( buf, " StatsObjBox %d %d %d %d %c ",
         Stats[dp->bufinx].objx+dx, Stats[dp->bufinx].objy+dy,
         Stats[dp->bufinx].objwid, Stats[dp->bufinx].objhgt,
         'A'+dp->bufinx);
      cmd_execute( buf, FALSE );
   }

   return TRUE; /* TRUE prevent these keypress event from affecting the focus. */
}

/*------------------------------------------------------------------------
**  dpydata_focus_in/out_event() -
**------------------------------------------------------------------------
*/
int dpydata_focus_in_event (GtkWidget *da, GdkEventFocus *event, gpointer data )
{
   GTK_WIDGET_SET_FLAGS( da, GTK_HAS_FOCUS);
   return FALSE;
}
int dpydata_focus_out_event (GtkWidget *da, GdkEventFocus *event, gpointer data )
{
   GTK_WIDGET_UNSET_FLAGS( da, GTK_HAS_FOCUS);
   return TRUE;
}

/********************************************************************************/
/*  General datadata drawing routines.                                          */
/********************************************************************************/

/*----------------------------------------------------------------------------
**  draw_X() - clear display & draw a frame on outer edge.
**----------------------------------------------------------------------------
*/
void draw_X( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   int da_wid, da_hgt;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   /* clears window */
   gdk_window_clear( da->window );

   /* draw a frame in window  */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, FALSE, 0, 0, da_wid-1, da_hgt-1);
}


/*----------------------------------------------------------------------------
**  draw_image() - Display the FITS data as an Image.
**----------------------------------------------------------------------------
*/
void draw_image( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   char buf[80];
   int dpinx,
       da_wid, da_hgt;
   GdkImage *image;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   dpinx = (int) gtk_object_get_user_data( GTK_OBJECT(da));
   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   /*----------------------------------------
   ** Let's check autoscale values
   */
   if( dp->image_autoscale )
   {
      float sd3 = bp->stddev*3;
      dp->image_min = bp->mean - sd3;
      dp->image_max = bp->mean + sd3;
      if( (dp->image_max - dp->image_min ) < 1.0 )
         dp->image_max = dp->image_min + 1.0;
   }

   /*-----------------------------------------------------------
   ** allocate image buffer & call appropriate drawing routine.
   */

   image = gdk_image_new( GDK_IMAGE_NORMAL, CM.visual, da_wid, da_hgt );
   if( image == NULL )
      return;
#if DEBUG
   printf("draw_image(): image: %dx%dx%d\n", image->width, image->height, image->depth );
#endif


   if( (CM.visual->type == GDK_VISUAL_PSEUDO_COLOR)  && (dp->image_zoom >= 1) )
      draw_image_plus_zoom_pseudocolor( dp, bp, da_wid, da_hgt, (char*)image->mem);
   else if( (CM.visual->type == GDK_VISUAL_TRUE_COLOR)  && (dp->image_zoom >= 1) )
      draw_image_plus_zoom_truecolor( dp, bp, da_wid, da_hgt, (long*)image->mem);
   else if( dp->image_zoom < 0 )
      draw_image_minus_zoom( dp, bp, da_wid, da_hgt, (char*)image->mem);
   else
     goto LNotSupported;

   /* transfer image to window & destroy image */
   gdk_draw_image( da->window, Nor_gc, image, 0, 0, 0, 0, da_wid, da_hgt);
   gdk_image_destroy( image );

   /*
   **  Draw the XOR box and line
   */
   draw_xor_box_on_canvas( dpinx, Stats[dp->bufinx].objx,   Stats[dp->bufinx].objy,
                                  Stats[dp->bufinx].objwid, Stats[dp->bufinx].objhgt);
   draw_xor_line_on_canvas( dpinx, Stats[dp->bufinx].ln_xbeg, Stats[dp->bufinx].ln_ybeg,
                                   Stats[dp->bufinx].ln_xend, Stats[dp->bufinx].ln_yend);
   return;

LNotSupported:
   gdk_image_destroy( image );

   /* clears window */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);

   sprintf( buf, "depth=%d  Zoom=%d - This mode is not yet supported.", image->depth, dp->image_zoom );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, 10, 20, buf );
}

/*----------------------------------------------------------------------
** draw_image_plus_zoom_pseudocolor() - Handles 8bit pseudocolor,
**  positive zooming for draw_image().
**  This function fill in the image memory buffer for display.
**----------------------------------------------------------------------
*/
void draw_image_plus_zoom_pseudocolor(
   struct dpy_t *dp,          /* pointer to Dpy[] */
   struct df_buf_t *bp,       /* pointer to Buffer[] */
   int da_wid,                /* size of draw area */
   int da_hgt,
   unsigned char * image_buf  /* allocated memory of buffer to fill */
)
{
   int    ximg, yimg,        /* x & y position in the image buffer  */
          wid_pix,           /* Size of screen pixels               */
          xarray, yarray,    /* controls which pixels to draw       */
          color,             /* color of the pixel                  */
          inx,               /* index to Buffer[bufinx].data[]       */
          wid,
          bitmap_pad,
          i;
   float  block;                  /* amount of count per color    */

   unsigned char * start_line;

   block = (dp->image_max - dp->image_min) / ((float)CM_NUM_RW_COLORS);
   wid_pix = dp->image_zoom;

   /* find bitmap_pad - amount of padding need per image->mem scan line, which are mod_32 in size */
   /* Padding is need since image->mem is an array of char (8bits) */
   i = da_wid % sizeof(long);
   bitmap_pad =  (i ? sizeof(long)-i : 0 );

   /* Adjust scroll bar parameters to fit to minimumize blank space */
   i = ( da_wid - ((bp->naxis1 - dp->image_offx ) * wid_pix) ) / wid_pix;
   if( i > 0 )
      dp->image_offx = MAX( 0, dp->image_offx-i);
   i = ( da_hgt - ((bp->naxis2 - dp->image_offy ) * wid_pix) ) / wid_pix;
   if( i > 0 )
      dp->image_offy = MAX( 0, dp->image_offy-i);

   /*---------------------------------------------------
   ** Loop through data & build display in XImage buffer.
   */
   for( yarray = dp->image_offy, yimg = 0;
        yarray < bp->naxis2 && yimg < da_hgt;
        yarray++ )
   {
      inx = yarray * bp->naxis1 + dp->image_offx;
      start_line = image_buf + (yimg * (da_wid+bitmap_pad));

      /*---------------------------------------
      **  Fill in the first row of the line.
      */
      for( xarray = dp->image_offx, ximg = 0;
           xarray < bp->naxis1 && ximg < da_wid;
           xarray++, inx ++)
      {
         float data = dfdatainx( bp, inx );

         if( data >= dp->image_max )
            color =  CM_NUM_COLORS-1;  /* last color */
         else if( data <= dp->image_min )
            color = CM_NUM_STATIC_COLORS; /* first color */
         else
            color = ( (data - dp->image_min) / block) + CM_NUM_STATIC_COLORS;

         wid = ( ximg+wid_pix < da_wid ) ? wid_pix : da_wid-ximg; /* screen pixel per data pixel */
         memset( (char*) start_line+ximg, CM.colors[color].pixel, wid ); /* apply to image */
         ximg += wid;     /* update ximg */
      }

      /* black out rest of scan line */
      memset( (char*)start_line+ximg, CM.colors[CM_BLACK].pixel, da_wid-ximg);

      /* Update yimg and copy wid_pix-1 lines for zoom. */
      yimg++;
      for( i=1; i < wid_pix && yimg < da_hgt; i++)
      {
         int size = da_wid+bitmap_pad;
         memcpy( (char*)start_line+(i*size), (char*) start_line, da_wid);
         yimg++;
      }
   }

   /*--------------------------------------------------------------
   ** clear rest of buffer if image is smaller than drawing area
   */
   if( yimg < da_hgt )
   {
      int size = da_wid+bitmap_pad;
      memset( (char*)image_buf+(yimg*size), CM.colors[CM_BLACK].pixel, (da_wid*da_hgt)-(yimg*size));
   }
}

/*-------------------------------------------------------------------------------
** draw_image_plus_zoom_truecolor() - Handles true color, positive zooming
**    for draw_image().
**-------------------------------------------------------------------------------
*/
void draw_image_plus_zoom_truecolor(
   struct dpy_t *dp,          /* pointer to Dpy[] */
   struct df_buf_t *bp,       /* pointer to Buffer[] */
   int da_wid,                /* size of draw area */
   int da_hgt,
   long * image_buf  /* allocated memory of buffer to fill */
)
{
   int    ximg, yimg,        /* x & y position in the image buffer  */
          wid_pix,           /* Size of screen pixels               */
          xarray, yarray,    /* controls which pixels to draw       */
          color,             /* color of the pixel                  */
          inx,               /* index to Buffer[bufinx].data[]       */
          wid,
          i;
   float  block;                  /* amount of count per color    */

   long * start_line;

   block = (dp->image_max - dp->image_min) / ((float)CM_NUM_RW_COLORS);
   wid_pix = dp->image_zoom;

   /* Adjust scroll bar parameters to fit to minimumize blank space */
   i = ( da_wid - ((bp->naxis1 - dp->image_offx ) * wid_pix) ) / wid_pix;
   if( i > 0 )
      dp->image_offx = MAX( 0, dp->image_offx-i);
   i = ( da_hgt - ((bp->naxis2 - dp->image_offy ) * wid_pix) ) / wid_pix;
   if( i > 0 )
      dp->image_offy = MAX( 0, dp->image_offy-i);

   /*---------------------------------------------------
   ** Loop through data & build display in XImage buffer.
   */
   for( yarray = dp->image_offy, yimg = 0;
        yarray < bp->naxis2 && yimg < da_hgt;
        yarray++ )
   {
      inx = yarray * bp->naxis1 + dp->image_offx;
      start_line = image_buf + (yimg * da_wid);

      /*---------------------------------------
      **  Fill in the first row of the line.
      */
      for( xarray = dp->image_offx, ximg = 0;
           xarray < bp->naxis1 && ximg < da_wid;
           xarray++, inx ++)
      {
         float data = dfdatainx( bp, inx );

         if( data >= dp->image_max )
            color =  CM_NUM_COLORS-1;  /* last color */
         else if( data <= dp->image_min )
            color = CM_NUM_STATIC_COLORS; /* first color */
         else
            color = ( (data - dp->image_min) / block) + CM_NUM_STATIC_COLORS;

         wid = ( ximg+wid_pix < da_wid ) ? wid_pix : da_wid-ximg; /* screen pixel per data pixel */
         longset( start_line+ximg, CM.colors[color].pixel, wid ); /* apply to image */
         ximg += wid;     /* update ximg */
      }

      /* black out rest of scan line */
      longset( start_line+ximg, CM.colors[CM_BLACK].pixel, da_wid-ximg);

      /* Update yimg and copy wid_pix-1 lines for zoom. */
      yimg++;
      for( i=1; i < wid_pix && yimg < da_hgt; i++)
      {
         memcpy( start_line+(i*da_wid), start_line, da_wid*sizeof(long));
         yimg++;
      }
   }

   /*--------------------------------------------------------------
   ** clear rest of buffer if image is smaller than drawing area
   */
   if( yimg < da_hgt )
   {
      memset( image_buf+(yimg*da_wid), CM.colors[CM_BLACK].pixel,
              ((da_wid*da_hgt)-(yimg*da_wid))*sizeof(long) );
   }
}

/*----------------------------------------------------------------------
** draw_image_minus_zoom() - Handles negative zooming for draw_image()
**   This function fill in the XImage memory buffer for display.
**----------------------------------------------------------------------
*/
void draw_image_minus_zoom(
   struct dpy_t *dp,       /* pointer to Dpy[]    */
   struct df_buf_t *bp,    /* pointer to Buffer[] */
   int  da_wid,            /* size of draw area   */
   int  da_hgt,
   unsigned char * image_buf  /* allocated memory of XImage buffer to  fill */
)
{
   int yarray, xarray,    /* reference to data */
       xda,  yda,         /* reference in drawing area */
       x, y,
       bitmap_pad,        /* padding so image_buf->mem.wid = da_wid */
       scanline_wid,      /* da_wid + bitmap_wid */
       zoom, color, i;

   double  data,
           block;          /* amount of count per color */

   long * long_buf;

   long_buf = (long*)image_buf; /* for true color use long_buf[] */
   block = (dp->image_max - dp->image_min) / ((float)CM_NUM_RW_COLORS);
   zoom = abs(dp->image_zoom) + 1;

   /* find bitmap_pad - amount of padding need for image->mem scan line, which are mod_32 in size */
   i = da_wid % sizeof(long);
   bitmap_pad =  (i ? sizeof(long)-i : 0 );
   scanline_wid = da_wid+bitmap_pad;       /* true wid of image buffer */

   /* Adjust scroll bar parameters to fit to minimumize blank space */
   i = ( da_wid - ((bp->naxis1 - dp->image_offx ) / zoom) ) * zoom;
   if( i > 0 )
      dp->image_offx = MAX( 0, dp->image_offx-i);
   i = ( da_hgt - ((bp->naxis2 - dp->image_offy ) / zoom) ) * zoom;
   if( i > 0 )
      dp->image_offy = MAX( 0, dp->image_offy-i);

   /*---------------------------------------------------
   ** Loop through data & build display in XImage buffer.
   */
   yarray = dp->image_offy;
   for( yda = 0; (yda < da_hgt) && (yarray < bp->naxis2); yda++ )
   {
      xarray = dp->image_offx;
      for( xda = 0; (xda < da_wid) && (xarray < bp->naxis1); xda++ )
      {
         /* sum image data for this pixel */
         data = 0;
         for( y=0; y<zoom && yarray+y < bp->naxis2; y++ )
         {
            i = (yarray * bp->naxis1) + xarray;
            for( x=0; x<zoom && xarray+x < bp->naxis1; x++ )
               data += dfdatainx( bp, i++ );
         }
         xarray += zoom; /* Increment X pixel reference */

         /* Divided data by number of pixel */
         data /= (float) (zoom*zoom);

         /* find color and store value in image buffer */
         if( data >= dp->image_max )
            color = CM_NUM_COLORS-1;      /* last color */
         else if( data <= dp->image_min )
            color = CM_NUM_STATIC_COLORS; /* first color */
         else
            color = ( (data - dp->image_min) / block) + CM_NUM_STATIC_COLORS;

         if( CM.visual->type == GDK_VISUAL_PSEUDO_COLOR )
            image_buf[ yda*scanline_wid + xda] = CM.colors[color].pixel;
         else
            long_buf[ yda*scanline_wid + xda] = CM.colors[color].pixel;
      }

      /* clear rest of row */
      if( CM.visual->type == GDK_VISUAL_PSEUDO_COLOR )
         memset( image_buf+(yda*scanline_wid+xda), CM.colors[CM_BLACK].pixel, da_wid-xda);
      else
         longset( long_buf+(yda*scanline_wid+xda), CM.colors[CM_BLACK].pixel, da_wid-xda);

      yarray += zoom; /* Increment Y pixel reference */
   }

   /* clear rest of image buf */
   if( CM.visual->type == GDK_VISUAL_PSEUDO_COLOR )
      memset( image_buf+(yda*scanline_wid), CM.colors[CM_BLACK].pixel, (da_hgt-yda)*scanline_wid);
   else
      longset( long_buf+(yda*scanline_wid), CM.colors[CM_BLACK].pixel, (da_hgt-yda)*scanline_wid);
}

/*--------------------------------------------------------------
** longset() - set the value of an array of long in memory.
*/
void longset( long * buf, long value, long n)
{
   int i;

   if( n < 0 ) return;

    for( i=0; i<n; i++)
       *buf++ = value;
}


/*----------------------------------------------------------------------------
**  draw_header() - Display the FITS Header information.
**----------------------------------------------------------------------------
*/
void draw_header( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   char buf[85];
   int dpinx,
       row,
       line,
       l,
       char_wid, char_hgt,
       da_wid, da_hgt;
   char * cptr;
   struct df_fheader_t *fhdr; /* Pointer to fits header structure */

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   dpinx = (int) gtk_object_get_user_data( GTK_OBJECT(da));
   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   /* clears window */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN] );

   row  = 0;
   line = 0;

   /* loop throught fits head & display each line */
   fhdr = bp->fheader;
   while( (fhdr != NULL) && (row < da_hgt) )
   {
      cptr = fhdr->buf;
      for( l=0; (l < (DF_FITS_RECORD_LEN/80)) && (row < da_hgt); l++ )
      {
         if( line >= dp->header_row )
         {
            memcpy( buf, cptr+dp->header_col, 80-dp->header_col);
            buf[80 - dp->header_col] = 0x00;
            gdk_draw_string( da->window, Fixed_font, Nor_gc, 2, row+=char_hgt, buf );
         }
         line++;
         cptr += 80;
      }
      fhdr = fhdr->next;  /* get next header block  */
   }
}

/*----------------------------------------------------------------------
** get_histogram_info() - Calculates the histogram hist info.
**----------------------------------------------------------------------
*/
int get_histogram_info(
   struct dpy_t *dp,         /* display parmaters - Must have value fits buffer  */
   struct hist_info *hist    /* This function returns this histogram info */
)
{
   int i,
       x_beg, x_numpixel,
       y_beg, y_numpixel,
       x1, y1;

   struct df_buf_t *bp;
   bp = &Buffer[dp->bufinx];    /* buffer pointer */

   /* get range of pixel to consider for histogram */
   if( dp->hist_area )
   {
      x_beg = Stats[dp->bufinx].objx;
      x_numpixel = MIN( Stats[dp->bufinx].objwid, Buffer[dp->bufinx].naxis1-x_beg);
      x_numpixel = MAX( 1, x_numpixel);
      y_beg = Stats[dp->bufinx].objy;
      y_numpixel = MIN( Stats[dp->bufinx].objhgt, Buffer[dp->bufinx].naxis1-y_beg);
      y_numpixel = MAX( 1, y_numpixel);
   }
   else
   {
      x_beg = 0;
      x_numpixel = bp->naxis1;
      y_beg = 0;
      y_numpixel = bp->naxis2;
   }

   /*
   **  Initizlize the hist_info structure.
   */
   hist->pixel_low = 0;
   hist->pixel_high = 0;
   hist->pixel_graph = 0;
   hist->pixel_total = 0;
   hist->max_bin_value = 0;

   hist->num_of_bins = dp->hist_bin;
   memset( hist->bins, 0, hist->num_of_bins*sizeof(hist->bins[0]));

   /*--------------------------------------------------
   ** Loop through pixel and count the bins
   */
   for( y1 = y_beg; y1 < y_beg+y_numpixel; y1++)
   {
      i = y1 * bp->naxis1 + x_beg;
      for( x1 = x_beg; x1 < x_beg+x_numpixel; x1++)
      {
         float data;
         int bin;

         data = dfdatainx( bp, i);

         bin = (int)rint(map( data, dp->image_min, dp->image_max, 0, hist->num_of_bins-1));
         if( bin < 0 )
            hist->pixel_low++;
         else if ( bin >= hist->num_of_bins )
            hist->pixel_high++;
         else
         {
            hist->pixel_graph++;
            hist->bins[bin]++;
            hist->max_bin_value = MAX( hist->max_bin_value, hist->bins[bin]);
         }

         i++;
         hist->pixel_total++;
      }
   }

   return ERR_NONE;
}

/*----------------------------------------------------------------------
** draw_histogram() - Display a histogram in the drawing area.
**----------------------------------------------------------------------
*/
void draw_histogram( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   int i, l,
       char_wid, char_hgt,
       da_wid, da_hgt,
       x1, y1, x2, y2,
       xmin, xmax, ymin, ymax;

   float max_percent,
         f;
   char buf[85];
   char *cptr;
   struct hist_info hist;        /* histogram info */

   /*----------------------------------------
   ** Let's check autoscale values
   */
   if( dp->image_autoscale )
   {
      float sd3 = bp->stddev*3;
      dp->image_min = bp->mean - sd3;
      dp->image_max = bp->mean + sd3;
      if( (dp->image_max - dp->image_min ) < 1.0 )
         dp->image_max = dp->image_min + 1.0;
   }

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt );
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW] );

   /*-----------------------------------
   ** Get Histogram info
   */
   if( ERR_NONE != get_histogram_info( dp, &hist ))
   {
      cptr = " get_histogram_info(): error!";
      gdk_draw_text( da->window, Fixed_font, Nor_gc, char_wid, char_hgt, cptr, strlen(cptr));
      return;
   }

   /*-----------------------------------
   ** Find max percent to nearest 0.01%
   */
   max_percent = (100.0*hist.max_bin_value) / hist.pixel_total;
   max_percent = (floor(max_percent/0.01)+1) * 0.01;

   /*--------------------------------------
   **  Graph boundaries
   */
   xmin = 9*char_wid;
   xmax = da_wid - 2*char_wid;
   ymin = da_hgt - 2*char_hgt;
   ymax = char_hgt;

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY]);    /* Graph is gray */
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, xmin, ymax, xmax-xmin+1, ymin-ymax+1);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);   /* boarder is white */
   gdk_draw_rectangle( da->window, Nor_gc, FALSE, xmin, ymax, xmax-xmin, ymin-ymax);

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_MAGENTA]); /* Display header  */
   strcpy( buf, "HISTOGRAM"); l = strlen(buf);
   x1 = (da_wid - l*char_wid) / 2;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, char_hgt, buf, l);

   /*--------------------------------------
   **  label Y axis
   */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);   /* boarder is white */
   x1 = xmin - char_wid;
   for( f = 0; f <= max_percent; f += (max_percent/4) )
   {
      y1 = map( f, 0, max_percent, ymin, ymax);
      gdk_draw_line( da->window, Nor_gc, x1, y1, xmax, y1);

      sprintf( buf, "%2.3f%%", f); l = strlen(buf);

      x2 = xmin - ((l+1)*char_wid);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y1, buf, l);
   }

   /*--------------------------------------
   **  label X axis
   */
   /*
   **  Draw X axis.
   */
   y1 = ymin+char_hgt/2;
   y2 = y1 + char_hgt;
   for( i=0; i<=100; i+=25 )
   {
      l = map( i, 0.0, 100.0, dp->image_min, dp->image_max );
      sprintf( buf, "%d", l); l = strlen(buf);

      x1 = map( i, 0, 100, xmin, xmax);
      gdk_draw_line( da->window, Nor_gc, x1, ymin, x1, y1);
      x1 -= (l*char_wid)/2;
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, y2, buf, l);
   }

   /*------------------------------------------
   **  Draw histogram
   */
   for( i=0; i < hist.num_of_bins; i++)
   {
      x1 = map( i, 0, hist.num_of_bins, xmin, xmax);
      x2 = map( i+1, 0, hist.num_of_bins, xmin, xmax);
      y2 = map( 100.0*hist.bins[i]/hist.pixel_total, 0, max_percent, ymin, ymax);

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_MAGENTA]);
      gdk_draw_rectangle( da->window, Nor_gc, TRUE, x1, y2, x2-x1, ymin-y2);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLUE]);
      gdk_draw_rectangle( da->window, Nor_gc, FALSE, x1, y2, x2-x1, ymin-y2);
   }

   /* display pixel information */
   y1 = ymax + char_hgt + 1;
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);
   sprintf( buf, "Pixels Graphed = %4.4f%%", (100.0*hist.pixel_graph)/hist.pixel_total);
   l = strlen(buf);
   x1 = xmax - (l*char_wid) - 1;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, y1, buf, l );

   sprintf( buf, "Too Low = %4.4f%%", (100.0*hist.pixel_low)/hist.pixel_total);
   l = strlen(buf);
   x1 = xmax - (l*char_wid) - 1;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, y1+=char_hgt, buf, l );

   sprintf( buf, "Too High = %4.4f%%", (100.0*hist.pixel_high)/hist.pixel_total);
   l = strlen(buf);
   x1 = xmax - (l*char_wid) - 1;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, y1+=char_hgt, buf, l );
}


/*----------------------------------------------------------------------
** get_linecut_info() - Calculates the histogram hist info.
**----------------------------------------------------------------------
*/
int get_linecut_info(
   struct dpy_t *dp,         /* display parmaters - Must have value fits buffer  */
   struct lcut_info *lcut    /* This function returns this linecut info */
)
{
   int i,
       x1, y1;
   float f;

   struct df_buf_t *bp;
   struct stats_t  *sp;

   bp = &Buffer[dp->bufinx];    /* buffer pointer */
   sp = &Stats[dp->bufinx];     /* stats info */

   /* get range of pixel to consider for histogram */
   lcut->xmin = 0;
   lcut->xmax = bp->naxis1-1;
   lcut->ymin = 0;
   lcut->ymax = bp->naxis2-1;
   if( dp->lcut_area )
   {
      if( (sp->objx >= 0) &&
          ((sp->objx+sp->objwid) < bp->naxis1) &&
          (sp->objwid >= 2 ))
      {
         lcut->xmin = sp->objx;
         lcut->xmax = sp->objx + sp->objwid - 1;
      }

      if( (sp->objy >= 0) &&
          ((sp->objy+sp->objhgt) < bp->naxis2) &&
          (sp->objhgt >= 2 ))
      {
         lcut->ymin = sp->objy;
         lcut->ymax = sp->objy + sp->objhgt - 1;
      }
   }

   /*
   **  Check the axis where the line cut occur
   */
   lcut->xaxis = dp->lcut_x;
   lcut->yaxis = dp->lcut_y;
   if( !INRANGE( lcut->xmin, lcut->xaxis, lcut->xmax))
      lcut->xaxis = lcut->xmin + (lcut->xmax - lcut->xmin)/2;
   if( !INRANGE( lcut->ymin, lcut->yaxis, lcut->ymax))
      lcut->yaxis = lcut->ymin + (lcut->ymax - lcut->ymin)/2;

   /*
   **  Find Min & Max Range for graph's scale
   */
   if( dp->lcut_autoscale )
   {
      lcut->range_min = DF_MAX_SIGNED_LONG;
      lcut->range_max = DF_MIN_SIGNED_LONG;

      for( y1 = lcut->ymin;  y1 <= lcut->ymax; y1++)
      {
         i = y1 * bp->naxis1 + lcut->xmin;
         for( x1 = lcut->xmin;  x1 <= lcut->xmax; x1++)
         {
            f = dfdatainx( bp, i++ );

            if( lcut->range_min  > f ) lcut->range_min  = f;
            if( lcut->range_max  < f ) lcut->range_max  = f;
         }
      }
   }
   else
   {
     lcut->range_min = dp->lcut_min;
     lcut->range_max = dp->lcut_max;
   }

#if DEBUG
   printf(" lcut->xmin  %d\n", lcut->xmin);
   printf(" lcut->xmax  %d\n", lcut->xmax);
   printf(" lcut->ymin  %d\n", lcut->ymin);
   printf(" lcut->ymax  %d\n", lcut->ymax);

   printf(" lcut->xaxis %d\n", lcut->xaxis);
   printf(" lcut->yaxis %d\n", lcut->yaxis);

   printf(" lcut->r_min %3.1f\n", lcut->range_min);
   printf(" lcut->r_max %3.1f\n", lcut->range_max);
#endif

   return ERR_NONE;
}

/*----------------------------------------------------------------------
** draw_linecut() - Display a linecut in the drawing area.
**----------------------------------------------------------------------
*/
void draw_linecut( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   int i, l,
       char_wid, char_hgt,
       da_wid, da_hgt,
       x1, y1, x2, y2,
       xmin, xmax, ymin, ymax,
       idata;

   float f;
   char buf[85];
   char *cptr;
   struct lcut_info lcut;        /* linecut info */

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt );
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW] );

   /*-----------------------------------
   ** Get linecut info
   */
   if( ERR_NONE != get_linecut_info( dp, &lcut ))
   {
      cptr = " get_linecut_info(): error!";
      gdk_draw_text( da->window, Fixed_font, Nor_gc, char_wid, char_hgt, cptr, strlen(cptr));
      return;
   }

   /*--------------------------------------
   **  Graph boundaries
   */
   xmin = 7*char_wid;
   xmax = da_wid - 4*char_wid;
   ymin = da_hgt - 2*char_hgt;
   ymax = 3*char_hgt;

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY]);    /* Canvas is gray */
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);   /* Graph is black */
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, xmin, ymax, xmax-xmin+1, ymin-ymax+1);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);   /* Border is white */
   gdk_draw_rectangle( da->window, Nor_gc, FALSE, xmin, ymax, xmax-xmin, ymin-ymax);

   sprintf( buf, "LINECUT at %d, %d", lcut.xaxis, lcut.yaxis);
   l = strlen(buf);
   x1 = (da_wid - l*char_wid)/2;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, char_hgt, buf, l);

   /*
   **  Label Y axis.
   */
   x1 = xmin - char_wid;        /* Scale markings */
   for( i=0; i <= 100; i+=25 )
   {
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
      y1 = map( i, 0, 100, ymin, ymax) + 0.5;
      gdk_draw_line( da->window, Nor_gc, xmin-char_wid, y1, xmin, y1);
      gdk_draw_line( da->window, Nor_gc, xmax+char_wid, y1, xmax, y1);
      /*
      **  Values of pixels for NAXIS1 (Red)
      */
      f = map(i, 0, 100, lcut.range_min, lcut.range_max);
      sprintf( buf, "%3.0f", f); l = strlen(buf);
      x2 = xmin - ((l+1)*char_wid);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_RED]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y1, buf, l);
      /*
      **  Index of pixel for NAXIS2 (GREEN)
      */
      idata = map( i, 0, 100, lcut.ymax, lcut.ymin)+0.5;
      sprintf( buf, "%d", idata ); l = strlen( buf );
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, xmax+char_wid, y1, buf, l);
   }

   /*
   **  Draw X axis.
   */
   y1 = ymax-char_hgt/2;               /* Text for top    labels    */
   y2 = ymin+(char_hgt/2)+char_hgt;    /* Text for bottom labels    */
   for( i=0; i <= 100; i+=25 )
   {
      /* Line Markings */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
      x1 = map( i, 0, 100, xmin, xmax);
      l = char_hgt/2;
      gdk_draw_line( da->window, Nor_gc, x1, ymin, x1, ymin+l);
      gdk_draw_line( da->window, Nor_gc, x1, ymax, x1, ymax-l);
      /*
      **  Indexes of pixels for NAXIS1 (Red)
      */
      idata = map( i, 0, 100, lcut.xmin, lcut.xmax)+0.5;
      sprintf( buf, "%d", idata );
      l = strlen( buf );
      x2 = x1 - ((l+1)*char_wid)/2;
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_RED]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y2, buf, l);
      /*
      **  Values of pixel for NAXIS2 (Green)
      */
      f = map( i, 0, 100, lcut.range_min, lcut.range_max);
      sprintf( buf, "%3.0f", f); l = strlen(buf);
      x2 = x1 - ((l+1)*char_wid)/2;
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y1, buf, l);
   }
   /*
   ** Draw Profile for NAXIS1 (Red).
   */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_RED]);
   x2 = xmin;
   y2 = ymin;

   for( i = lcut.xmin;  i <= lcut.xmax; i++)
   {
      x1 = map( i+0.5, lcut.xmin, lcut.xmax, xmin, xmax);

      f = dfdataxy( bp, i, lcut.yaxis);

      if( f > lcut.range_max )
         y1 = ymax;
      else if( f < lcut.range_min )
         y1 = ymin;
      else
         y1 = map( f, lcut.range_min, lcut.range_max, ymin, ymax);

      gdk_draw_line( da->window, Nor_gc, x2, y2, x2, y1);
      gdk_draw_line( da->window, Nor_gc, x2, y1, x1, y1);

      x2 = x1;
      y2 = y1;
   }
   /*
   ** Draw Profile for NAXIS2 (Green).
   */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
   x2 = xmin;
   y2 = ymin;

   for( i = lcut.ymin;  i <= lcut.ymax; i++)
   {
      y1 = map( i+0.5, lcut.ymin, lcut.ymax, ymin, ymax);

      f = dfdataxy( bp, lcut.xaxis, i);

      if( f > lcut.range_max )
         x1 = xmax;
      else if( f < lcut.range_min )
         x1 = xmin;
      else
         x1 = map( f, lcut.range_min, lcut.range_max, xmin, xmax);

      gdk_draw_line( da->window, Nor_gc, x2, y2, x1, y2);
      gdk_draw_line( da->window, Nor_gc, x1, y2, x1, y1);

      x2 = x1;
      y2 = y1;
   }
}


/*----------------------------------------------------------------------
** draw_noise() - Display a linecut in the drawing area.            hack0
**----------------------------------------------------------------------
*/
void draw_noise( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   int    x1, y1, y2,
          xmin, xmax,          /* Graph area min, max, & size in pixels */
          ymin, ymax,
          char_wid,
          char_hgt,
          da_wid, da_hgt,
          mod,
          nrows,
          l,
          row, col;
   float  range_min, range_max;
   char   buf[85];

   struct noise_t *noisep;
   struct noise_t fnoise;

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   /*
   **  Allocate memory for data.
   */
   if( NULL == ( noisep = (struct noise_t *) calloc( dp->noise_mod, sizeof(struct noise_t)) ) )
   {
      printf("Memory allocation error\n");
      return;
   }
   memset( (char*) &fnoise, 0x00, sizeof(fnoise));

   /*
   **  Calculate noise
   */
   calc_noise( noisep, &fnoise, dp, bp );

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);

   /*--------------------------------------------------------------
   ** Display noise as text.
   */
   row = dp->noise_row;
   col = dp->noise_col;

   if ( !dp->noise_graph_type )
   {

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      sprintf(buf, "Min       Max       Mean      STD       N");
      gdk_draw_text( da->window, Fixed_font, Nor_gc,  8*char_wid,    char_hgt, buf+col, strlen(buf)-col);
      gdk_draw_text( da->window, Fixed_font, Nor_gc,           0,  2*char_hgt, "Array", 5);

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
      sprintf(buf, "%7.1f   %7.1f   %8.2f  %7.2f   %ld",
                    fnoise.min, fnoise.max, fnoise.mean, fnoise.std, fnoise.N);
      gdk_draw_text( da->window, Fixed_font, Nor_gc,  8*char_wid,  2*char_hgt, buf+col, strlen(buf)-col);

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_CYAN]);
      for( mod=0; (mod+row < dp->noise_mod) && (mod < da_hgt/char_hgt-1); mod++)
      {
         gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
         sprintf( buf, "Col %2d", mod+row);
         gdk_draw_text( da->window, Fixed_font, Nor_gc,              0,  (3+mod)*char_hgt, buf, 6);

         gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_CYAN]);
         sprintf(buf, "%7.1f   %7.1f   %8.2f  %7.2f   %ld",
                      noisep[mod+row].min, noisep[mod+row].max, noisep[mod+row].mean,
                      noisep[mod+row].std, noisep[mod+row].N);
         gdk_draw_text( da->window, Fixed_font, Nor_gc,  8*char_wid,  (3+mod)*char_hgt, buf+col, strlen(buf)-col);
      }
   }

   /*----------------------------------------------------------
   **  Draw Noise Graph.
   */
   if ( dp->noise_graph_type )
   {

      ymax = char_hgt;
      if( (da_hgt - ymax) < 60 )
              return;
      ymin = ymax + ((da_hgt-ymax)/2);
      xmin = 10*char_wid;
      xmax = da_wid - 2*char_wid;

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY]);
      gdk_draw_rectangle( da->window, Nor_gc, FALSE, xmin, ymax, xmax-xmin, ymin-ymax );

      if( dp->noise_autoscale )
      {
         range_min = fnoise.min;
         range_max = fnoise.max;
      }
      else
      {
         range_min = dp->noise_g1_min;
         range_max = dp->noise_g1_max;
      }
      nrows = dp->noise_mod+2;

      /* label Y axis */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
      sprintf( buf, "%3.1f", range_min); l = strlen(buf);
      x1 = xmin - ((l+1)*char_wid);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, ymin, buf, l);
      sprintf( buf, "%3.1f", range_max); l = strlen(buf);
      x1 = xmin - ((l+1)*char_wid);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, ymax+char_hgt, buf, l);

      /* Draw array stats */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
      x1 = map( 1, 0, nrows, xmin, xmax);
      y1 = map( fnoise.min, range_min, range_max, ymin, ymax);
      y2 = map( fnoise.max, range_min, range_max, ymin, ymax);
      gdk_draw_line( da->window, Nor_gc, x1, y1, x1, y2);
      gdk_draw_line( da->window, Nor_gc, x1-2, y1, x1+2, y1);
      gdk_draw_line( da->window, Nor_gc, x1-2, y2, x1+2, y2);
      y1 = map( fnoise.mean, range_min, range_max, ymin, ymax);
      gdk_draw_rectangle( da->window, Nor_gc, FALSE, x1-1, y1-1, 3, 3);

      /* Draw stats for each column */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_CYAN]);
      for( mod=0; mod < dp->noise_mod; mod++)
      {
          x1 = map( mod+2, 0, nrows, xmin, xmax);
          y1 = map( noisep[mod].min, range_min, range_max, ymin, ymax);
          y2 = map( noisep[mod].max, range_min, range_max, ymin, ymax);
          gdk_draw_line( da->window, Nor_gc, x1, y1, x1, y2);
          gdk_draw_line( da->window, Nor_gc, x1-2, y1, x1+2, y1);
          gdk_draw_line( da->window, Nor_gc, x1-2, y2, x1+2, y2);
          y1 = map( noisep[mod].mean, range_min, range_max, ymin, ymax);
          gdk_draw_rectangle( da->window, Nor_gc, FALSE, x1-1, y1-1, 3, 3);
      }

      /*
      **  Draw std graph.
      */
      ymax = ymin + char_hgt;
      ymin = da_hgt - char_hgt;

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY]);
      gdk_draw_rectangle( da->window, Nor_gc, FALSE, xmin, ymax, xmax-xmin, ymin-ymax );

      /* get range */
      if( dp->noise_autoscale )
      {
          range_min = fnoise.std;
          range_max = fnoise.std;
          for( mod=0; mod < dp->noise_mod; mod++)
          {
             if( noisep[mod].std < range_min ) range_min = noisep[mod].std;
             if( noisep[mod].std > range_max ) range_max = noisep[mod].std;
          }
      }
      else
      {
         range_min = dp->noise_g2_min;
         range_max = dp->noise_g2_max;
      }

      /* label Y axis */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
      sprintf( buf, "%3.1f", range_min); l = strlen(buf);
      x1 = xmin - ((l+1)*char_wid);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, ymin, buf, l);
      sprintf( buf, "%3.1f", range_max); l = strlen(buf);
      x1 = xmin - ((l+1)*char_wid);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, ymax+char_hgt, buf, l);

      /* Draw array std */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
      x1 = map( 1, 0, nrows, xmin, xmax);
      y1 = map( fnoise.std, range_min, range_max, ymin, ymax);
      gdk_draw_point( da->window, Nor_gc, x1, y1 );
      gdk_draw_rectangle( da->window, Nor_gc, FALSE, x1-2, y1-2, 5, 5);

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_CYAN]);
      for( mod=0; mod < dp->noise_mod; mod++)
      {
         x1 = map( mod+2, 0, nrows, xmin, xmax);
         y1 = map( noisep[mod].std, range_min, range_max, ymin, ymax);
         gdk_draw_point( da->window, Nor_gc, x1, y1 );
         gdk_draw_rectangle( da->window, Nor_gc, FALSE, x1-2, y1-2, 5, 5);

      }
   }

   /* free memory  */
   free( (char*) noisep);
}

/*----------------------------------------------------------------------
** calc_noise() - Perform noise calculations.                      hack4
**----------------------------------------------------------------------
*/
void calc_noise( struct noise_t *noisep, struct noise_t *fnoise,
                 struct dpy_t *dp, struct df_buf_t *bp )
{
   int i,
       mod,
       x1, y1,
       x_beg, x_numpixel,
       y_beg, y_numpixel;
   double ddata, d;

   /*
   **  Get pixel domain
   */
   if( dp->noise_area )
   {
      i = dp->bufinx;
      x_beg = Stats[i].objx;
      x_numpixel = MIN(Stats[i].objwid, bp->naxis1-x_beg);
      x_numpixel = MAX(1, x_numpixel);

      y_beg = Stats[i].objy;
      y_numpixel = MIN(Stats[i].objhgt, bp->naxis2-y_beg);
      y_numpixel = MAX(1, y_numpixel);
   }
   else
   {
      x_beg = 0;
      x_numpixel = bp->naxis1;
      y_beg = 0;
      y_numpixel = bp->naxis2;
   }
   /*
   ** loop through data & calculate stats
   */
   fnoise->min = DF_MAX_SIGNED_LONG;
   fnoise->max = DF_MIN_SIGNED_LONG;

   for( mod=0; mod < dp->noise_mod; mod++)
   {
      noisep[mod].min = DF_MAX_SIGNED_LONG;
      noisep[mod].max = DF_MIN_SIGNED_LONG;
   }

        /* PASS 1 */
   for( y1 = y_beg; y1 < y_beg+y_numpixel; y1++)
   {
      i = y1 * bp->naxis1 + x_beg;
      for( x1 = x_beg; x1 < x_beg+x_numpixel; x1++)
      {
         ddata = dfdatainx( bp, i);

         if( ddata > fnoise->max ) fnoise->max = ddata;
         if( ddata < fnoise->min ) fnoise->min = ddata;
         fnoise->mean += ddata;
         fnoise->N++;

         mod = i % dp->noise_mod;
         if( ddata > noisep[mod].max ) noisep[mod].max = ddata;
         if( ddata < noisep[mod].min ) noisep[mod].min = ddata;
         noisep[mod].mean += ddata;
         noisep[mod].N++;

          i++;
       }
    }

    /* calculate means */
    if( fnoise->N > 0 ) fnoise->mean /= fnoise->N;
    for( mod=0; mod < dp->noise_mod; mod++)
       if( noisep[mod].N > 0 ) noisep[mod].mean /= noisep[mod].N;


   /* PASS 2 */
   for( y1 = y_beg; y1 < y_beg+y_numpixel; y1++)
   {
      i = y1 * bp->naxis1 + x_beg;
      for( x1 = x_beg; x1 < x_beg+x_numpixel; x1++)
      {
         ddata = dfdatainx( bp, i );

         d = ddata - fnoise->mean;
         fnoise->std += d*d;

         mod = i % dp->noise_mod;
         d = ddata - noisep[mod].mean;
         noisep[mod].std += d*d;
         i++;
      }
   }

   if( fnoise->N > 1 ) fnoise->std = sqrt(fnoise->std / (fnoise->N-1));
   for( mod=0; mod < dp->noise_mod; mod++)
      if( noisep[mod].N > 1 ) noisep[mod].std = sqrt(noisep[mod].std / (noisep[mod].N-1));

}


/*----------------------------------------------------------------------
** draw_xcut() - Display a xcut graph.                              hack1
**----------------------------------------------------------------------
*/
void draw_xcut( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   int    x1, y1, x2, y2,
          xmin, xmax,          /* Graph area min, max, & size in pixels */
          ymin, ymax,
          char_wid,
          char_hgt,
          da_wid, da_hgt,
          num_xcut_items,
          inx,
          l, i;
   long   ldata,
          range_min, range_max;
   char buf[85];

   struct xcut_buf_t *xcut_buf;

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   /*
   **  allocate array for data
   */
   if( NULL == ( xcut_buf = (struct xcut_buf_t *) malloc( sizeof(struct xcut_buf_t)*NUM_PIXEL)) )
   {
      printf("Memory allocation error\n");
      return;
   }
   /*
   **  Using a digital differential analyser (DDA) algorithm, cycle through the data
   **  and place points in buffer, the min and max.
   */
   num_xcut_items = xcut_line ( dp->xcut_xbeg, dp->xcut_ybeg,
                                     dp->xcut_xend, dp->xcut_yend,
                                     bp, xcut_buf, NUM_PIXEL-1 );

   /* Get Y scale  */

   if( dp->xcut_autoscale )
   {
      range_min = DF_MAX_SIGNED_LONG;
      range_max = DF_MIN_SIGNED_LONG;
      for( i=0; i < num_xcut_items; i++)
      {
         ldata = xcut_buf[i].value;
         if( ldata < range_min ) range_min = ldata;
         if( ldata > range_max ) range_max = ldata;
      }
      dp->xcut_min = range_min;
      dp->xcut_max = range_max;
   }
   else
   {
      range_min = dp->xcut_min;
      range_max = dp->xcut_max;
   }
   /*
   **  Dimension graph area.
   */
   xmin =  7*char_wid;
   xmax =  da_wid - 2*char_wid;
   ymin =  da_hgt - 3*char_hgt;
   ymax =  (char_hgt*3) / 2;
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);    /* Canvas is black */
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);
   /***
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY]);
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, xmin, ymax, xmax-xmin+1, ymin-ymax+1 );
   ****/
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
   gdk_draw_rectangle( da->window, Nor_gc, FALSE, xmin, ymax, xmax-xmin,  ymin-ymax);

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
   sprintf( buf, "XCUT (%d,%d) to (%d, %d)", dp->xcut_xbeg, dp->xcut_ybeg,
                                             dp->xcut_xend, dp->xcut_yend);

   l = strlen(buf);
   x1 = (da_wid - l*char_wid)/2;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x1, char_hgt, buf, l);
   /*
   **  Label Y axis.
   */
   x1 = xmin - char_wid;        /* Scale markings */
   for( i=0; i <= 100; i+=25 )
   {
      y1 = map( (float)i, (float)0.0, (float)100.0, (float)ymin, (float)ymax)+0.5;
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      gdk_draw_line( da->window, Nor_gc, x1, y1, xmin, y1);
      /*
      **  Values of pixels for NAXIS1 (Red)
      */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
      ldata = map((float)i, (float)0.0, (float)100.0, (float)range_min, (float)range_max)+0.5;
      sprintf( buf, "%ld", ldata); l = strlen(buf);
      x2 = xmin - ((l+1)*char_wid);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y1, buf, l);
   }
   /*
   **  Draw X axis.
   */
   y1 = ymin+char_hgt/2;       /* line markings */
   y2 = y1 + char_hgt;         /* Text          */
   for( i=0; i <= 100; i+=25 )
   {
      x1 = map( (float)i, (float)0.0, (float)100.0, (float)xmin, (float)xmax);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      gdk_draw_line( da->window, Nor_gc, x1, ymin, x1, y1);

      inx = map( (float)i, (float)0.0, (float)100.0, (float)0, (float)num_xcut_items-1)+0.5;

      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_WHITE]);
      sprintf( buf, "%d", xcut_buf[inx].x); l = strlen( buf );
      x2 = x1 - ((l+1)*char_wid)/2;
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y2, buf, l);

      sprintf( buf, "%d", xcut_buf[inx].y); l = strlen( buf );
      x2 = x1 - ((l+1)*char_wid)/2;
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x2, y2+char_hgt, buf, l);
   }
   /*
   **  Draw the graph
   */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_RED]);

   x2 = xmin;
   y2 = ymin;
   for( i=0; i<num_xcut_items; i++)
   {
      x1 = map( (float)i+1, (float)0, (float)num_xcut_items, (float)xmin, (float)xmax);

      ldata = xcut_buf[i].value;
      if( ldata > range_max )
         y1 = ymax;
      else if( ldata < range_min )
         y1 = ymin;
      else
         y1 = map((float)ldata, (float)range_min, (float)range_max, (float)ymin, (float)ymax);

      gdk_draw_line( da->window, Nor_gc, x2, y2, x2, y1);
      gdk_draw_line( da->window, Nor_gc, x2, y1, x1, y1);

      x2 = x1;
      y2 = y1;
   }
   gdk_draw_line( da->window, Nor_gc, x2, y2, xmax, ymin);

   /*--------------------------
   ** output vfgfit.dat to gfit program.
   */
   if( Dpy[Lc.active].xcut_gfit )
   {
      FILE *fp;
      if( (fp = fopen( "/tmp/xgfit.dat", "w")) != NULL )
      {
         fchmod( fileno(fp), S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);

         fprintf( fp, " %d \n", num_xcut_items);
         for( i=0; i<num_xcut_items; i++)
            fprintf( fp, " %d %ld\n", i, xcut_buf[i].value);
         fclose( fp );
      }
      Dpy[Lc.active].xcut_gfit = FALSE;
   }

   free( (char *) xcut_buf);
}

/*----------------------------------------------------------------
** xcut_line - This copies the data from the buffer to destbuf.
**   It uses the digital differential analyzer (DDA) algorithm to
**   select a line of pixels from (x0, y0) to (x1, y1).
**   It returns count, the number of pixels found.
**----------------------------------------------------------------
*/
int xcut_line ( int x0, int y0, int x1, int y1,
                struct df_buf_t *bp,
                struct xcut_buf_t *destbuf,
                int num_destbuf )
{
   int x, y,
       reverse,
       count,
       i, is, ie, di;
   float dy, dx,
         dj, j;

   count = 0;
   dy = y1 - y0;
   dx = x1 - x0;

   if( fabs(dy) > fabs(dx) || dx==0 )
   {
      is = y0;
      ie = y1;
      di = ( dy > 0 ? 1 : -1);
      j  = x0;
      dj = dx/fabs(dy);
      reverse = 1;
   }
   else
   {
      is = x0;
      ie = x1;
      di = ( dx > 0 ? 1 : -1);
      j  = y0;
      dj = dy/fabs(dx);
      reverse = 0;
   }

   for( i=is; i!=ie+di; i += di)
   {
      x = i;
      y = j+0.5;
      if( reverse )
         { x = y; y = i; }

      if( INRANGE( 0, x, bp->naxis1-1) && INRANGE( 0, y, bp->naxis2-1))
      {
         destbuf->x = x;
         destbuf->y = y;
         destbuf->value = dfdataxy( bp, x, y);

         destbuf++;
         count++;
      }

      j += dj;
   }

   return count;
}


/*------------------------------------------------------
**  draw_pointer()
**------------------------------------------------------
*/

void draw_pointer( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   char * cptr;
   int  x, y, l,
        char_wid, char_hgt,
        da_wid, da_hgt;

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);

   y = da_hgt / 2;

   cptr = "Pointer Display";
   l = strlen(cptr);
   x = (da_wid - (char_wid*l))/2;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y, cptr, l);

   cptr = "Move pointer to image to begin";
   l = strlen(cptr);
   x = (da_wid - (char_wid*l))/2;
   gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+char_hgt, cptr, l);
}

/*------------------------------------------------------
**  draw_pointer_update()
**------------------------------------------------------
*/

void draw_pointer_update( GtkWidget *da, int dpinx, int ax, int ay, int image_dpinx )
{
   char buf[60];
   int  l,
        x, x_beg, x_end,
        y, y_beg, y_end,
        char_wid, char_hgt,
        da_wid, da_hgt,
        wid_pix,
        i_size;
   float data;

   struct dpy_t    *dp = &Dpy[dpinx];
   struct dpy_t    *imagedp = &Dpy[image_dpinx];
   struct df_buf_t *bp = &Buffer[imagedp->bufinx];

   /* draw only if (x,y) refers to a pixel */
   if( !INRANGE(0, ax, bp->naxis1-1)) return;
   if( !INRANGE(0, ay, bp->naxis2-1)) return;

   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK]);
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);

   /*---------------------------------------
   ** Draw & Label the pixel box
   */
   {
      int x1, x2, y1;

      x1 = char_wid;
      wid_pix = ((da_wid/2) - 2*char_wid)/dp->pt_image_size;
      i_size = wid_pix * dp->pt_image_size;
      x2 = x1 + (wid_pix * dp->pt_image_size) + 1;
      y1 = char_hgt;

      gdk_draw_rectangle( da->window, Nor_gc, FALSE, x1, y1, i_size+1, i_size+1);

      /* Draw tick marks */
      x = x1 + i_size/2;
      gdk_draw_line( da->window, Nor_gc, x, y1, x, y1-char_wid/2);
      sprintf( buf, " %3d ", ax );
      l = strlen( buf );
      x -= (l*char_wid)/2;
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y1-char_wid/2, buf, l);

      y = y1 + i_size/2;
      x = x2+char_wid;
      gdk_draw_line( da->window, Nor_gc, x2, y, x, y);
      sprintf( buf, "%d ", ay );
      l = strlen( buf );
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y, buf, l);

      /* get value of center pixel */
      data = dfdataxy( bp, ax, ay);

      /* display pixel value */
      x = (da_wid/2) + (4*char_wid);
      y = char_hgt;
      sprintf(buf, "Dec %7.1f ", data); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, "Hex 0x%08lx ", (long)data); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
   }

   /*---------------------------------------
   ** Put zoomed image in pixel box.
   */
   {
      int color,
          bitmap_pad,
          i;
      float block;
      GdkImage *image;
      long          * tc_buf;
      unsigned char * pc_buf;

      /*---------------------
      ** create Image
      */
      i_size = wid_pix * dp->pt_image_size;
      if( (image = gdk_image_new( GDK_IMAGE_NORMAL, CM.visual, i_size, i_size )) == NULL )
         return;

      /* pseudoColor & TrueColor are supported by using 2 different pointers:   */
      tc_buf = (long*) image->mem;          /* long  * tc_buf for TrueColor. */
      pc_buf = (unsigned char*) image->mem; /* uchar * pc_buf for pseudoColor. */

      block = (imagedp->image_max - imagedp->image_min) / ((float)CM_NUM_RW_COLORS);

      /* calculate the amount of padding each line has in image->mem */
      i = (CM.visual->type == GDK_VISUAL_PSEUDO_COLOR ? sizeof(char) : sizeof(long));
      i *= i_size;             /* size of ximage line in bytes */
      i = i % sizeof(long);    /* mod (wid,32 bit) */
      bitmap_pad = (i ? sizeof(long)-i : 0 );

      /*---------------------------------------------------
      ** Loop through data & build display in Image buffer.
      ** Also get max, min, mean;
      */
      y_beg = ay - dp->pt_image_size/2;
      y_end = y_beg + dp->pt_image_size - 1;
      x_beg = ax - dp->pt_image_size/2;
      x_end = x_beg + dp->pt_image_size - 1;
      for( y = y_beg; y <= y_end; y++ )
      {
         for( x = x_beg; x <= x_end; x++ )
         {
            color = CM_BLACK;

            if( INRANGE( 0, x, bp->naxis1-1)  && INRANGE( 0, y, bp->naxis2-1) )
            {
               data = dfdataxy( bp, x, y );
               if( data >= imagedp->image_max )
                  color = CM_NUM_COLORS-1;  /* last color */
               else if (data <= imagedp->image_min )
                  color =  CM_NUM_STATIC_COLORS; /* first color */
               else
                  color = ( (data - imagedp->image_min) / block) + CM_NUM_STATIC_COLORS;
            }

            if( CM.visual->type == GDK_VISUAL_PSEUDO_COLOR )
            {
               memset( (char*)pc_buf, CM.colors[color].pixel, wid_pix);
               pc_buf += wid_pix;
            }
            else
            {
               longset( tc_buf, CM.colors[color].pixel, wid_pix );
               tc_buf += wid_pix;
            }
         }
         if( bitmap_pad ) pc_buf += bitmap_pad;

         if( CM.visual->type == GDK_VISUAL_PSEUDO_COLOR )
         {
            int size = i_size + bitmap_pad;  /* add padding */
            for( i=1; i < wid_pix; i++ )
            {
               memcpy( pc_buf, (pc_buf - size), size);
               pc_buf += i_size;
               pc_buf += bitmap_pad;
            }
         }
         else
         {
            for( i=1; i < wid_pix; i++ )
            {
               memcpy( tc_buf, (tc_buf - i_size), i_size*sizeof(long));
               tc_buf += i_size;
            }
         }
      }

      /*---------------------------------------------------
      ** Place image into drawing area, and free Image.
      */
      gdk_draw_image( da->window, Nor_gc, image, 0, 0, char_wid + 1, char_hgt + 1,
                 i_size, i_size);
      gdk_image_destroy( image );
   }

   /*-----------------------------------------------
   ** calculate and display statistics.
   */
   {
      double N, min, max, sum, mean, std;

      cal_box_stats_subf( bp, 1, x_beg, y_beg, dp->pt_image_size,
         dp->pt_image_size, 0, 0, &N, &min, &max, &sum, &mean, &std);

      x = (da_wid/2) + (4*char_wid);
      y = 4*char_hgt;
      sprintf(buf, "   N %5.0f ", N); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, " Min %7.1f ", min); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, " Max %7.1f ", max); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, "Mean %7.1f ", mean); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, " STD %8.2f ", std); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
   }

   /*-----------------------------------------------------------
   **  XY line cut.
   */
   {
      int xmin, xmax, ymin, ymax,
          ox, oy,
          nx, ny;

      xmin = char_wid;
      xmax = xmin + i_size;
      ymax = da_hgt/2 + char_hgt;
      ymin = ymax + i_size;
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
      gdk_draw_rectangle( da->window, Nor_gc, FALSE, xmin, ymax, i_size, i_size);

      /* X line cut */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_RED]);
      ox = xmin;
      oy = ymin;
      x_beg = ax - dp->pt_image_size/2;
      x_end = x_beg + dp->pt_image_size - 1;
      for( x = x_beg; x <= x_end; x++ )
      {
         nx = ox + wid_pix;

         if( INRANGE( 0, x, bp->naxis1-1)  && INRANGE( 0, ay, bp->naxis2-1))
         {
            data = dfdataxy( bp, x, ay );

            ny = map( data, imagedp->image_min, imagedp->image_max, ymin, ymax);
            gdk_draw_line( da->window, Nor_gc, ox, oy, ox, ny);
            gdk_draw_line( da->window, Nor_gc, ox, ny, nx, ny);
            oy = ny;
         }

         ox = nx;
      }

      /* Y line cut */
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      ox = xmin;
      oy = ymax;
      y_beg = ay - dp->pt_image_size/2;
      y_end = y_beg + dp->pt_image_size - 1;
      for( y = y_beg; y <= y_end; y++ )
      {
         ny = oy + wid_pix;

         if( INRANGE( 0, ax, bp->naxis1-1)  && INRANGE( 0, y, bp->naxis2-1))
         {
            data = dfdataxy( bp, ax, y );

            nx = map( data, imagedp->image_min, imagedp->image_max, xmin, xmax);
            gdk_draw_line( da->window, Nor_gc, ox, oy, nx, oy);
            gdk_draw_line( da->window, Nor_gc, nx, oy, nx, ny);
            ox = nx;
         }

         oy = ny;
      }

      /* some text legends */
      x = (da_wid/2) + (2*char_wid);
      y = da_hgt/2 + char_hgt;

      strcpy(buf, "Line Cut" ); l = strlen(buf);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);

      x += 2*char_wid;
      sprintf(buf, "X at %d ", ax); l = strlen(buf);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_RED]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, "Y at %d ", ay); l = strlen(buf);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, "Range is %5.0f ", imagedp->image_min); l = strlen(buf);
      gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW]);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
      sprintf(buf, "      to %5.0f ", imagedp->image_max); l = strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l);
   }

}

/*----------------------------------------------------------------------------
**  draw_stats() - Display the FITS Header information.
**----------------------------------------------------------------------------
*/
void draw_stats( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   char buf[85];
   int x, y, l,
       char_wid, char_hgt,
       da_wid, da_hgt;
   float mean;
   struct stats_t *sptr;
   char *cptr;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   /* clears window */
   gdk_window_get_size( da->window, &da_wid, &da_hgt);
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   sptr = &Stats[dp->bufinx];   /* stats  pointer */

   /*----------------------
   ** Titles
   */
   cptr = "    Object Box"; l = strlen(cptr);
   my_draw_image_string( da->window, Fixed_font, Nor_gc, 10*char_wid,  4*char_hgt,
      char_wid, char_hgt, CM_BLACK, CM_GREEN, cptr, l);
   cptr = "       Sky Box"; l = strlen(cptr);
   my_draw_image_string( da->window, Fixed_font, Nor_gc, 27*char_wid,  4*char_hgt,
      char_wid, char_hgt, CM_BLACK, CM_GREEN, cptr, l);
   cptr = "     Obj - Sky"; l = strlen(cptr);
   my_draw_image_string( da->window, Fixed_font, Nor_gc, 10*char_wid, 12*char_hgt,
      char_wid, char_hgt, CM_BLACK, CM_GREEN, cptr, l);
   cptr = "Photometry Est"; l = strlen(cptr);
   my_draw_image_string( da->window, Fixed_font, Nor_gc, 27*char_wid, 12*char_hgt,
      char_wid, char_hgt, CM_BLACK, CM_GRAY, cptr, l);

   /*----------------------
   ** Labels
   */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY] );
   y = 0;
   x = char_wid;
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "Buffer:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "   Min:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "   Max:" );
   y = 0;
   x = 20*char_wid;
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "  Mean:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "   Var:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "StdDev:" );

   y = 4*char_hgt;
   x = char_wid;
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "loc/size:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "     Sum:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "    Mean:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " Std Dev:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "NumPixel:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " Minimum:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " Maximum:" );

   y = 12*char_hgt;
   x = char_wid;
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "     Sum:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "    Mean:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " Std Dev:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "NumPixel:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " Minimum:" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " Maximum:" );

   y = 12*char_hgt;
   x = 28*char_wid;
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " F=" );
   y += char_hgt;
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, "ZP=" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " K=" );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, " X=" );


   /*----------------------
   ** Values
   */
   y = 0;
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_YELLOW] );

   gdk_draw_string( da->window, Fixed_font, Nor_gc, 18*char_wid, y+=char_hgt,
      buffer_selection[dp->bufinx] );

   sprintf(buf, "%3.0f", bp->min); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (19-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%3.0f", bp->max); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (19-l)*char_wid, y+=char_hgt, buf, l);

   /* buffer's mean, var, std */
   y = 0;
   sprintf(buf, "%12.1f", bp->mean); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (40-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%12.2f", bp->stddev*bp->stddev); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (40-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%12.2f", bp->stddev); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (40-l)*char_wid, y+=char_hgt, buf, l);

   /* Print OBJECT values */
   y = 4*char_hgt;
   sprintf(buf, "(%d,%d)%dx%d", sptr->objx, sptr->objy, sptr->objwid, sptr->objhgt); l = strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.0f", sptr->objsum); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   mean = (sptr->objN>0 ? sptr->objsum/sptr->objN : 0);
   sprintf(buf, "%8.1f", mean); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.2f", sptr->objstd); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%d", sptr->objN); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.1f", sptr->objmin); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.1f", sptr->objmax); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);

   /* Print SKY values */
   y = 4*char_hgt;
   sprintf(buf, "(%d,%d)%dx%d", sptr->skyx, sptr->skyy, sptr->skywid, sptr->skyhgt); l = strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.0f", sptr->skysum); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);
   mean = (sptr->skyN>0 ? sptr->skysum/sptr->skyN : 0);
   sprintf(buf, "%8.1f", mean); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.2f", sptr->skystd); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%d", sptr->skyN); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.1f", sptr->skymin); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.1f", sptr->skymax); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (41-l)*char_wid, y+=char_hgt, buf, l);

   /* show obj-sky stats */
   y = 12*char_hgt;
   sprintf(buf, "%8.0f", sptr->redsum); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   mean = (sptr->redN>0 ? sptr->redsum/sptr->redN : 0);
   sprintf(buf, "%8.1f", mean); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.2f", sptr->redstd); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%d", sptr->redN); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.1f", sptr->redmin); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);
   sprintf(buf, "%8.1f", sptr->redmax); l=strlen(buf);
   gdk_draw_text( da->window, Fixed_font, Nor_gc, (24-l)*char_wid, y+=char_hgt, buf, l);

   /* calculate the estimate for aperture photometry */
   {
      double d, f;

      x = 31*char_wid;
      y = 12*char_hgt;

      d = bp->itime * (Lc.divbydivisor ? 1 : bp->divisor);
      if( d <= 0.0 ) d = 1;
      f = (sptr->redsum / d );

      sprintf(buf, "%1.0f/%4.2f ", sptr->redsum, d ); l=strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l );
      sprintf(buf, "%4.2f ", f ); l=strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l );

      sprintf(buf, "%4.2f", bp->filter_zp); l=strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l );

      sprintf(buf, "%4.2f", bp->ext_coff); l=strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l );

      sprintf(buf, "%4.2f", bp->airmass); l=strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l );

      x = 2*char_wid;
		y = 18*char_hgt;
		gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GREEN] );
      if( f > 0.0 )
      {
         d = ( -2.5 * log10(f)) + bp->filter_zp - (bp->ext_coff*bp->airmass);
			sprintf( buf, "MagEst= -2.5log(F)+ZP-(K*X) = %5.3f ", d);
      }
      else
         strcpy( buf, "MagEst= Invalid Input. No Est.");
      l=strlen(buf);
      gdk_draw_text( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf, l );
   }
}

/*----------------------------------------------------------------------------
**  draw_NA() - Not Available - use this until draw_() is written.
**----------------------------------------------------------------------------
*/
void draw_NA( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp )
{
   char buf[80];
   int dpinx,
       x, y,
       char_wid, char_hgt,
       da_wid, da_hgt;

   /* Check that the drawing area has been initialized. */
   if ( da->window == NULL )
      return;

   char_wid = Fixed_font_wid;
   char_hgt = Fixed_font_hgt;

   dpinx = (int) gtk_object_get_user_data( GTK_OBJECT(da));
   gdk_window_get_size( da->window, &da_wid, &da_hgt);

   /* clears window */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_GRAY] );
   gdk_draw_rectangle( da->window, Nor_gc, TRUE, 0, 0, da_wid, da_hgt);

   /* draw a frame in window  */
   gdk_gc_set_foreground( Nor_gc, &CM.colors[CM_BLACK] );
   gdk_draw_rectangle( da->window, Nor_gc, FALSE, 0, 0, da_wid-1, da_hgt-1);

   x = char_wid;
   y = char_hgt;

   sprintf( buf, "dpyinx = %d " , dpinx );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf );

   sprintf( buf, "bufinx = %d " , dp->bufinx );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf );

   sprintf( buf, "dpytype = %s " , dpytype_selection[dp->dpytype] );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf );

   sprintf( buf, "buf->status = %s ", buffer_status_names[bp->status] );
   gdk_draw_string( da->window, Fixed_font, Nor_gc, x, y+=char_hgt, buf );
}

/********************************************************************************/
/*                   Scroll bars related routines                               */
/********************************************************************************/

/*----------------------------------------------------------------------------
**  dpy_vadj_cb() - Callback for dpy's vertical scrollbar adjustments.
**----------------------------------------------------------------------------
*/
void dpy_vadj_cb( GtkAdjustment *adj, gpointer data )
{
   int dpinx            = (int) data;
   struct dpy_t *dp     = &Dpy[dpinx];         /* reference to dpy    */
   struct df_buf_t *bp  = &Buffer[dp->bufinx]; /* reference to buffer */

   if( bp->status == DF_EMPTY )
      return;

   if( dp->dpytype == DPYTYPE_HEADER )
   {
      dp->header_row = rint(adj->value);
      call_dpydata_redraw( dpinx );
   }
   else if( dp->dpytype == DPYTYPE_IMAGE )
   {
      dp->image_offy = rint(adj->value);
      call_dpydata_redraw( dpinx );
   }

}

/*----------------------------------------------------------------------------
**  dpy_hadj_cb() - Callback for dpy's horizontial scrollbar adjustments.
**----------------------------------------------------------------------------
*/
void dpy_hadj_cb( GtkAdjustment *adj, gpointer data )
{
   int dpinx            = (int) data;
   struct dpy_t *dp     = &Dpy[dpinx];         /* reference to dpy    */
   struct df_buf_t *bp  = &Buffer[dp->bufinx]; /* reference to buffer */

   if( bp->status == DF_EMPTY )
      return;

   if( dp->dpytype == DPYTYPE_HEADER )
   {
      dp->header_col = rint(adj->value);
      call_dpydata_redraw( dpinx );
   }
   else if( dp->dpytype == DPYTYPE_IMAGE )
   {
      dp->image_offx = rint(adj->value);
      call_dpydata_redraw( dpinx );
   }

}

/*----------------------------------------------------------------
**  update_scrollbars - set the scrollbars parameters according
**     to values in the Dpy strcuture.
**----------------------------------------------------------------
*/
void update_scrollbars( int dpinx )
{
   int da_wid, da_hgt;

   struct dpy_t    *dp = &Dpy[dpinx];            /* dpy pointer    */
   struct df_buf_t *bp = &Buffer[dp->bufinx];    /* buffer pointer */

   gfloat Hlower = 0,            /* minimum value */
          Hupper = 1,            /* maximum value */
          Hvalue = 0,            /* current value */
          Hstep_increment = 1,   /* step increment */
          Hpage_increment = 1,   /* page increment */
          Hpage_size = 1,        /* page size */
          Vlower = 0,
          Vupper = 1,
          Vvalue = 0,
          Vstep_increment = 1,
          Vpage_increment = 1,
          Vpage_size = 1;

   /* Check that the drawing area has been initialized. */
   if ( dp->data_drawingarea->window == NULL )
      return;

   /* get wid & hgt of drawing area */
   gdk_window_get_size( dp->data_drawingarea->window, &da_wid, &da_hgt);

   /*-------------------------------
   ** header
   */
   if( (bp->status != DF_EMPTY) && (dp->dpytype == DPYTYPE_HEADER) )
   {
      int char_wid = Fixed_font_wid;
      int char_hgt = Fixed_font_hgt;

      Hlower = 0;
      Hupper = 80;
      Hpage_size = MIN( da_wid / char_wid, Hupper);
      Hstep_increment = 1;
      Hpage_increment = Hpage_size-1;
      Hvalue = MIN(dp->header_col, Hupper-Hpage_size);
      Hvalue = MAX(Hvalue, 0 );

      Vlower = 0;
      Vupper = bp->Nheader-1;
      Vpage_size = MIN( da_hgt / char_hgt, Vupper);
      Vstep_increment = 1;
      Vpage_increment = Vpage_size-1;
      Vvalue = MIN(dp->header_row, Vupper-Vpage_size);
      Vvalue = MAX(Vvalue, 0 );
   }

   /*-------------------------------
   ** Image
   */
   if( (bp->status != DF_EMPTY) && (dp->dpytype == DPYTYPE_IMAGE) )
   {
      float pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));

      Hlower = 0;
      Hupper = bp->naxis1;
      Hpage_size = MIN( da_wid / pixel_wid, bp->naxis1);
      Hstep_increment = 1;
      Hpage_increment = Hpage_size;
      Hvalue = dp->image_offx;

      Vlower = 0;
      Vupper = bp->naxis2;
      Vpage_size = MIN( da_hgt / pixel_wid, bp->naxis2);
      Vstep_increment = 1;
      Vpage_increment = Vpage_size;
      Vvalue = dp->image_offy;
   }

   /*--------------------------------------------------------
   ** write changes back to the scrollbar/adjustment widget
   */
#if DEBUG
   printf("update_scrollbars\n");
   printf("V: lower=%5.1f upper=%5.1f S_inc=%5.1f P_inc=%5.1f P_size=%5.1f value=%5.1f\n",
      Vlower, Vupper, Vstep_increment, Vpage_increment, Vpage_size, Vvalue);
   printf("H: lower=%5.1f upper=%5.1f S_inc=%5.1f P_inc=%5.1f P_size=%5.1f value=%5.1f\n",
      Hlower, Hupper, Hstep_increment, Hpage_increment, Hpage_size, Hvalue);
#endif

   dp->hadj->lower = Hlower;
   dp->hadj->upper = Hupper;
   dp->hadj->value = Hvalue;
   dp->hadj->step_increment = Hstep_increment;
   dp->hadj->page_increment = Hpage_increment;
   dp->hadj->page_size = Hpage_size;

   dp->vadj->lower = Vlower;
   dp->vadj->upper = Vupper;
   dp->vadj->value = Vvalue;
   dp->vadj->step_increment = Vstep_increment;
   dp->vadj->page_increment = Vpage_increment;
   dp->vadj->page_size = Vpage_size;

   gtk_adjustment_changed( dp->hadj );
   gtk_adjustment_changed( dp->vadj );
}

/********************************************************************************/
/*               Other drawing routines...                                      */
/********************************************************************************/

/*----------------------------------------------------------------
**  draw_xor_box_on_canvas() - Draw the object box on the canvas
**----------------------------------------------------------------
*/
void draw_xor_box_on_canvas( dpinx, x, y, wid, hgt )
   int dpinx;            /* Identifies canvas to xor on     */
   int x, y, wid, hgt;   /* Draw a box around these pixels  */
{
   int      box_x, box_y, box_wid, box_hgt;
   float    pixel_wid;

   struct dpy_t *dp = &Dpy[dpinx];

   /* determine position of upper-left pixel */
   pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));
   box_x = ((x - dp->image_offx) * pixel_wid) + 0.5;
   box_y = ((y - dp->image_offy) * pixel_wid) + 0.5;

   box_wid = wid * pixel_wid;
   box_hgt = hgt * pixel_wid;
   /* Adjust values so rectangle is draw around the pixels */
   box_x--; box_y--; box_wid++; box_hgt++;

   /* Draw it */
   gdk_gc_set_foreground( Xor_gc, &CM.colors[CM_GREEN] );
   gdk_draw_rectangle( dp->data_drawingarea->window, Xor_gc, FALSE, box_x, box_y, box_wid, box_hgt);

}

/*----------------------------------------------------------------
**  draw_xor_box_on_buffer() - Calls draw_xor_on_canvas for each
**     canvas displaying data from this buffer.
**----------------------------------------------------------------
*/
void draw_xor_box_on_buffer( bufinx, x, y, wid, hgt )
   int bufinx;            /* Update all images of data in Buffer[bufinx] */
   int x, y, wid, hgt;    /* Draw a box around these pixels              */
{
   int      dpinx;

   for( dpinx = 0; dpinx < Lc.num_dpy; dpinx++)
      if( Dpy[dpinx].bufinx == bufinx && Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
      {
         draw_xor_box_on_canvas( dpinx, x, y, wid, hgt);
      }
}

/*----------------------------------------------------------------
**  draw_xor_line_on_canvas() - Draw the xor line on the canvas
**----------------------------------------------------------------
*/
void draw_xor_line_on_canvas( dpinx, xbeg, ybeg, xend, yend )
   int dpinx;                   /* Identifies canvas to xor on         */
   int xbeg, ybeg, xend, yend;  /* Draw a line from (x1,y1) to (x2,y2) */
{
   int      x1, y1, x2, y2;
   float    pixel_wid;

   struct dpy_t *dp = &Dpy[dpinx];

   /* determine position of upper-left pixel */
   pixel_wid = dp->image_zoom > 0 ? dp->image_zoom : 1.0/(1.0+abs(dp->image_zoom));
   x1 = ((xbeg - dp->image_offx) * pixel_wid) + (pixel_wid/2);
   y1 = ((ybeg - dp->image_offy) * pixel_wid) + (pixel_wid/2);

   x2 = ((xend - dp->image_offx) * pixel_wid) + (pixel_wid/2);
   y2 = ((yend - dp->image_offy) * pixel_wid) + (pixel_wid/2);

   /* Draw it */
   gdk_gc_set_foreground( Xor_gc, &CM.colors[CM_WHITE] );
   gdk_draw_line( dp->data_drawingarea->window, Xor_gc, x1, y1, x2, y2);
}

/*----------------------------------------------------------------
**  draw_xor_line_on_buffer() - Calls draw_xor_line_on_canvas for each
**     canvas displaying data from this buffer.
**----------------------------------------------------------------
*/
void draw_xor_line_on_buffer( bufinx, xbeg, ybeg, xend, yend )
   int bufinx;            /* Update all images of data in Buffer[bufinx] */
   int xbeg, ybeg, xend, yend;  /* Draw a line from (x,y)beg to (x,y)end */
{
   int      dpinx;

   for( dpinx = 0; dpinx < Lc.num_dpy; dpinx++)
      if( Dpy[dpinx].bufinx == bufinx && Dpy[dpinx].dpytype == DPYTYPE_IMAGE )
      {
         draw_xor_line_on_canvas( dpinx, xbeg, ybeg, xend, yend);
      }
}

/*----------------------------------------------------------------------------
**  my_draw_image_string() - draw a string with a colored background.
**----------------------------------------------------------------------------
*/
void my_draw_image_string(
   GdkDrawable  *drawable,
   GdkFont      *font,
   GdkGC         *gc,
   int      x,
   int      y,
   int      char_wid,
   int      char_hgt,
   int      fg,
   int      bg,
   const gchar  *string,
   int strlen
)
{
   gdk_gc_set_foreground( gc, &CM.colors[bg] );
   gdk_draw_rectangle( drawable, gc, TRUE, x,  y-char_hgt+3, strlen*char_wid, char_hgt );
   gdk_gc_set_foreground( gc, &CM.colors[fg] );
   gdk_draw_string( drawable, font, gc, x,  y, string);
}

/********************************************************************************/
/********************************************************************************/
