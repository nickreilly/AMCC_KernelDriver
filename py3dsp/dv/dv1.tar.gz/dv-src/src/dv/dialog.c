/********************************************************************************/
/*  DIALOG.C - contains bfp (Browse for Path)                                   */
/********************************************************************************/

#define EXTERN extern

/*-------------------------
**  Standard include files
**-------------------------
*/

#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <gtk/gtk.h>

/*------------------------------
**  Non-standard include files
**------------------------------
*/
#include <error_msg.h>
#include <addlib.h>

#include "cm.h"           /* include colormap information  */
#include "dialog.h"       /* include path dialog box */

#include "dv.h"           /* DV MAIN APPLICATION  */

/*************************************************************************
**  BFP (Browse for Path) function - A dialog window for seleting a
** directory name by navigating the mouse on an option_menu/clist.
**
** To use allocate a struct browseForPath_t structure for housekeeping.
**
** User function are:
**
**    bfp_create_dialog() - create dialog box and initialize bfp structure.
**
**    bfp_hide_dialog() - Hide the dialog window.
**
**    bfp_show_dialog() - Shows the dialog window.
**
**    bfp_set_path() - Sets the current path for the dialog window.
**
**    bfp_set_ok_cb() - Install you callback for the OK button. See
**       bfp_ok_cb() for details.
**
** static functions are:
**    int bfp_delete_event( ) - handles delete window events.
**    void bfp_ok_cb( ) - default OK button callback.
**    void bfp_cancel_cb( ) - default cancel button callback.
**    void bfp_refresh_cb( ) - default refresh button callback.
**    void bfp_menuitem_cb( ) - menuitem selection callback.
**    void bfp_clist_cb( ) -  clist selection callback.
**
************************************************************************
*/

/* prototype static functions */

static int bfp_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data );
void fad_mask_cb( GtkEntry *widget, gpointer data );
void fad_refresh_cb( GtkWidget *widget, gpointer data );
static void bfp_ok_cb( GtkWidget *widget, gpointer data );
static void bfp_cancel_cb( GtkWidget *widget, gpointer data );
static void bfp_refresh_cb( GtkWidget *widget, gpointer data );
static void bfp_menuitem_cb( GtkMenuItem * menuitem, gpointer data );
static void bfp_clist_cb( GtkCList * clist, gint row, gint col, GdkEventButton *event,
                          gpointer data);


/*-----------------------------------------------------------------------
** bfp_create_dialog() - Browse For Path create dialog.
**   You must pass it a browseForPath_t structure and
**   callbackup function for the option menu selections.
**-----------------------------------------------------------------------
*/
int bfp_create_dialog ( struct browseForPath_t *bfp, char * title )
{
   GtkWidget * table;
   GtkWidget * button;
   GtkWidget * label;
   GtkWidget * menu;
   GtkWidget * scrollbars;
   GtkWidget * widget;

   char * menu_stub[1];

   /* initalize structure */
   bfp->dialog_window = NULL;
   bfp->path_option_w = NULL;
   bfp->clist         = NULL;
   bfp->entry         = NULL;
   bfp->ok_button     = NULL;
   dirlist_init( &bfp->dirlist );

   /*---------------------------------
   ** Create bfp->dialog_window
   */
   bfp->dialog_window = gtk_window_new( GTK_WINDOW_DIALOG );
   gtk_window_set_title( GTK_WINDOW (bfp->dialog_window), title );
   gtk_window_set_policy( GTK_WINDOW(bfp->dialog_window), TRUE, TRUE, FALSE );
   gtk_signal_connect( GTK_OBJECT(bfp->dialog_window), "delete_event",
      GTK_SIGNAL_FUNC(bfp_delete_event), NULL);
   gtk_signal_connect( GTK_OBJECT(bfp->dialog_window), "destroy",
      GTK_SIGNAL_FUNC(bfp_delete_event), NULL);

   /* table to contain my widgets */
   table = gtk_table_new( 100, 100, FALSE );
   gtk_widget_set_usize( GTK_WIDGET(table), 300, 300 );
   gtk_container_add (GTK_CONTAINER (bfp->dialog_window), table);

   /*--------------------------------------------
   **  Path Label & bfp->path_option_w (Option Menu)
   */
   menu_stub[0] = NULL;
   menu = MyCreateMenuFromSelection( menu_stub, FALSE, bfp_menuitem_cb, bfp );
   bfp->path_option_w = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(bfp->path_option_w), menu );

   gtk_table_attach_defaults( GTK_TABLE(table), bfp->path_option_w, 10, 90, 0, 10 );
   gtk_widget_show( bfp->path_option_w );

   /*---------------------------------------------
   **  clist with scroll bars to show directories
   */
   bfp->clist = gtk_clist_new( 1 );
   gtk_clist_set_shadow_type (GTK_CLIST(bfp->clist), GTK_SHADOW_IN);
   gtk_clist_set_selection_mode( GTK_CLIST(bfp->clist), GTK_SELECTION_EXTENDED );
   gtk_clist_column_titles_passive( GTK_CLIST(bfp->clist) );
   gtk_widget_set_usize( GTK_WIDGET(bfp->clist), 250, 100 );
   gtk_signal_connect( GTK_OBJECT(bfp->clist), "select_row",
      GTK_SIGNAL_FUNC(bfp_clist_cb), (gpointer) bfp );

   gtk_widget_show(bfp->clist);

   scrollbars = gtk_scrolled_window_new( NULL, NULL );
   gtk_container_add( GTK_CONTAINER(scrollbars), bfp->clist );
   gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(scrollbars),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS );
   gtk_container_set_border_width( GTK_CONTAINER(scrollbars), 5 );
   gtk_table_attach_defaults( GTK_TABLE(table), scrollbars, 0, 100, 10, 76 );
   gtk_widget_show( scrollbars );

   /*---------------------------------------------------------
   **  label to let the used know what the current path is:
   */
   label = gtk_label_new( "Path is: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 20, 78, 88 );
   gtk_widget_show( label );

   bfp->entry = gtk_entry_new_with_max_length( DIRLIST_MAX_PATH );
   gtk_entry_set_editable( GTK_ENTRY(bfp->entry), FALSE);
   gtk_table_attach_defaults( GTK_TABLE(table), bfp->entry, 20, 90, 78, 88 );
   gtk_widget_show( bfp->entry );

   /*---------------------------------
   **  hseparator
   */
   widget = gtk_hseparator_new();
   gtk_table_attach_defaults( GTK_TABLE(table), widget, 0, 100, 88, 90 );
   gtk_widget_show( widget );

   /*---------------------------------
   **  OK button
   */
   bfp->ok_button = gtk_button_new_with_label( "OK");
   gtk_table_attach_defaults( GTK_TABLE(table), bfp->ok_button, 5, 45, 90, 100);
   gtk_signal_connect( GTK_OBJECT (bfp->ok_button), "clicked",
       GTK_SIGNAL_FUNC ( bfp_ok_cb ), (gpointer) bfp );
   gtk_widget_show(bfp->ok_button);

   /*---------------------------------
   **  Cancel button to hide dialog
   */
   button = gtk_button_new_with_label( "Cancel");
   gtk_table_attach_defaults( GTK_TABLE(table), button, 45, 70, 90, 100);
   gtk_signal_connect( GTK_OBJECT (button), "clicked",
      GTK_SIGNAL_FUNC (bfp_cancel_cb ), (gpointer) bfp );
   gtk_widget_show(button);

   /*---------------------------------
   **  Refresh button
   */
   button = gtk_button_new_with_label( "Refresh");
   gtk_table_attach_defaults( GTK_TABLE(table), button, 75, 95, 90, 100);
   gtk_signal_connect( GTK_OBJECT (button), "clicked",
      GTK_SIGNAL_FUNC (bfp_refresh_cb ), (gpointer) bfp );
   gtk_widget_show(button);

   gtk_widget_show( table );
   return 0;
}

/*-----------------------------------------------------------------------
** bfp_show_dialog() - show the window.
**-----------------------------------------------------------------------
*/
void bfp_show_dialog ( struct browseForPath_t *bfp )
{
   gtk_widget_show( bfp->dialog_window );
   gdk_window_raise( bfp->dialog_window->window );
}

/*-----------------------------------------------------------------------
** bfp_hide_dialog() - hides the bfp window.
**-----------------------------------------------------------------------
*/
void bfp_hide_dialog ( struct browseForPath_t *bfp )
{
   gtk_widget_hide( bfp->dialog_window );
}

/*-----------------------------------------------------------------------
** bfp_set_path() - Set a new path.
**-----------------------------------------------------------------------
*/
void bfp_set_path( struct browseForPath_t *bfp, char * path )
{
   /*-------------------------------------
   ** call function to make diretory list
   */
   dirlist_newpath( &bfp->dirlist, path );

   /*----------------------------------------------
   ** update the option menu
   */
   {
      GtkWidget * old_menu;
      GtkWidget * new_menu;

      old_menu = gtk_option_menu_get_menu( GTK_OPTION_MENU(bfp->path_option_w) );
      gtk_option_menu_remove_menu( GTK_OPTION_MENU(bfp->path_option_w) );
      /* gtk_widget_destroy( old_menu ); */

      new_menu = MyCreateMenuFromSelection( bfp->dirlist.list, FALSE,
         bfp_menuitem_cb, bfp );
      gtk_option_menu_set_menu( GTK_OPTION_MENU(bfp->path_option_w), new_menu );
   }

   /*----------------------------------------------
   ** update the directory list
   */
   update_file_list( TRUE, bfp->dirlist.path, "*", bfp->clist );

   /*----------------------------------------------
   ** update the label
   */
   gtk_entry_set_text( GTK_ENTRY(bfp->entry), bfp->dirlist.path );
}

/*-----------------------------------------------------------------------
**  bfp_set_ok_cb() - allows user to install their own OK button callback.
**-----------------------------------------------------------------------
*/
void bfp_set_ok_cb( struct browseForPath_t *bfp, GtkSignalFunc func )
{
   gtk_signal_connect( GTK_OBJECT (bfp->ok_button), "clicked", func,
      (gpointer) bfp );
}

/***************************************************************************
**  BFP's Internal functions
***************************************************************************
*/

/*-----------------------------------------------------------------------
**  bfp_delete_event()
**-----------------------------------------------------------------------
*/
int bfp_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data )
{
   /* Return FALSE - gtk will call base_destroy_cb();
   **         TRUE - gtk will ignore delete event.
   */
   gtk_widget_hide( GTK_WIDGET(widget) );
   return(TRUE);
}

/*-----------------------------------------------------------------------
** bfp_ok_cb() - the defaule ok button callback.
**-----------------------------------------------------------------------
*/
void bfp_ok_cb( GtkWidget *widget, gpointer data )
{
   struct browseForPath_t *bfp = (struct browseForPath_t *)data;

#if DEBUG
   printf("bfp_ok_cb() the path is %s\n", bfp->dirlist.path );
#endif

   bfp_hide_dialog ( bfp );
}

/*-----------------------------------------------------------------------
** bfp_cancel_cb() - the defaule cancel callback. Just hides the dialog
**   window.
**-----------------------------------------------------------------------
*/
void bfp_cancel_cb( GtkWidget *widget, gpointer data )
{
   bfp_hide_dialog ( (struct browseForPath_t *)data );
}

/*----------------------------------------------------------------------
** bfp_refresh_cb() - the refresh callback.
**-----------------------------------------------------------------------
*/
void bfp_refresh_cb( GtkWidget *widget, gpointer data )
{
   struct browseForPath_t *bfp = (struct browseForPath_t *)data;

   /* update the directory list */
   update_file_list( TRUE, bfp->dirlist.path, "*", bfp->clist );
}

/*-----------------------------------------------------------------------
** bfp_menuitem_cb - the default menu item callback. Set new path from
**   user's selection.
**-----------------------------------------------------------------------
*/
void bfp_menuitem_cb( GtkMenuItem * menuitem, gpointer data )
{
   int inx;
   struct browseForPath_t *bfp;
   char newpath[DIRLIST_MAX_PATH];

   inx = (int)data;      /* selected path from option menu */
   bfp = (struct browseForPath_t *)gtk_object_get_user_data( GTK_OBJECT(menuitem));

   strxcpy( newpath,  bfp->dirlist.list[inx], sizeof(newpath) );
   bfp_set_path( bfp, newpath );
}

/*-----------------------------------------------------------------------
** bfp_clist_cb - the clist selection callback. Selects a new path
**    from user's selection.
**-----------------------------------------------------------------------
*/
void bfp_clist_cb( GtkCList * clist, gint row, gint col, GdkEventButton *event,
                   gpointer data)
{
   char * text;
   char newpath[DIRLIST_MAX_PATH];
   struct browseForPath_t *bfp = (struct browseForPath_t *)data;

   if( col==0 ) /* if col == 0 means it was double click (not sure why) */
   {
      gtk_clist_get_text( clist, row, col, &text );
      cat_pathname( newpath, bfp->dirlist.path, text, sizeof(newpath) );
      bfp_set_path( bfp, newpath );
   }
}


/*************************************************************************
**  FAD (Browse for Path) function - A dialog window for seleting a
** directory name by navigating the mouse on an option_menu/clist.
**
** To use allocate a struct fileAccessDialog_t structure for housekeeping.
**
** User function are:
**
**    fad_create_dialog() - create dialog box and initialize fad structure.
**
**    fad_hide_dialog() - Hide the dialog window.
**
**    fad_show_dialog() - Shows the dialog window.
**
**    fad_set_path() - Sets the current path for the dialog window.
**
**    fad_set_filename() - Sets the current filename for the dialog window.
**
**    fad_set_buffer() - Sets the current buffer for the dialog window.
**
**    fad_set_ok_cb() - Install you callback for the OK button. See
**       fad_ok_cb() for details.
**
**    fad_set_buffer_cb() - Install you callback for the Buffer selection.
**
** static functions are:
**    int  fad_delete_event( ) - handles delete window events.
**    void fad_ok_cb( ) - default OK button callback.
**    void fad_cancel_cb( ) - default cancel button callback.
**    void fad_buffer_cb( ) - default buffer menu callback.
**    void fad_menuitem_cb( ) - menuitem selection callback.
**    void fad_clist_cb( ) -  clist selection callback.
**
************************************************************************
*/

/* prototype static functions */

static int  fad_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data );
static void fad_ok_cb( GtkWidget *widget, gpointer data );
static void fad_cancel_cb( GtkWidget *widget, gpointer data );
static void fad_buffer_cb( GtkMenuItem * menuitem, gpointer data );
static void fad_menuitem_cb( GtkMenuItem * menuitem, gpointer data );
static void fad_dir_clist_cb( GtkCList * clist, gint row, gint col, GdkEventButton *event,
                              gpointer data);
static void fad_file_clist_cb( GtkCList * clist, gint row, gint col, GdkEventButton *event,
                               gpointer data);


/*-----------------------------------------------------------------------
** fad_create_dialog() - Browse For Path create dialog.
**   You must pass it a fileAccessDialog_t structure and
**   callbackup function for the option menu selections.
**-----------------------------------------------------------------------
*/
int fad_create_dialog ( struct fileAccessDialog_t *fad, char * title, char * selection[], int clearflag )
{
   GtkWidget * table;
   GtkWidget * button;
   GtkWidget * label;
   GtkWidget * menu;
   GtkWidget * scrollbars;
   GtkWidget * widget;

   char * menu_stub[1];
   char * dir_title[1];
   char * file_title[1];

   /* initalize structure */
   fad->dialog_window     = NULL;
   fad->table             = NULL;
   fad->path_option_w     = NULL;
   fad->buffer_option_w   = NULL;
   fad->mask_entry        = NULL;
   fad->dir_clist         = NULL;
   fad->file_clist        = NULL;
   fad->path_entry        = NULL;
   fad->file_entry        = NULL;
   fad->ok_button         = NULL;
   fad->func              = NULL;
   fad->clearfilenameflag = clearflag;
   dirlist_init( &fad->dirlist );
   strcpy( fad->mask, "*");

   /*---------------------------------
   ** Create fad->dialog_window
   */
    fad->dialog_window = gtk_window_new( GTK_WINDOW_DIALOG );
   gtk_window_set_title( GTK_WINDOW (fad->dialog_window), title );
   gtk_window_set_policy( GTK_WINDOW(fad->dialog_window), TRUE, TRUE, FALSE );
   gtk_signal_connect( GTK_OBJECT(fad->dialog_window), "delete_event",
      GTK_SIGNAL_FUNC(fad_delete_event), NULL);
   gtk_signal_connect( GTK_OBJECT(fad->dialog_window), "destroy",
      GTK_SIGNAL_FUNC(fad_delete_event), NULL);

   /* table to contain my widgets */
   table = gtk_table_new( 100, 100, TRUE );
   gtk_widget_set_usize( GTK_WIDGET(table), 420, 370 );
   gtk_container_add( GTK_CONTAINER(fad->dialog_window), table );
   gtk_container_set_border_width( GTK_CONTAINER(fad->dialog_window), 10 );
   gtk_widget_show( table );
   fad->table = table;

   /*--------------------------------------------
   **  Path Label & fad->path_option_w (Option Menu)
   */
   menu_stub[0] = NULL;
   menu = MyCreateMenuFromSelection( menu_stub, FALSE, fad_menuitem_cb, fad );
   fad->path_option_w = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(fad->path_option_w), menu );
   gtk_widget_show( fad->path_option_w );
   gtk_table_attach_defaults( GTK_TABLE(table), fad->path_option_w, 0, 50, 0, 8 );

   /*---------------------------------------------------------
   **  Filter entry
   */
   label = gtk_label_new( " Filter: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 50, 65, 0, 8 );
   gtk_widget_show( label );

   fad->mask_entry = gtk_entry_new_with_max_length( 40 );
   gtk_entry_set_editable( GTK_ENTRY(fad->mask_entry), TRUE );
   gtk_table_attach_defaults( GTK_TABLE(table), fad->mask_entry, 65, 85, 0, 8 );
   gtk_entry_set_text( GTK_ENTRY(fad->mask_entry), fad->mask);
   gtk_signal_connect( GTK_OBJECT(fad->mask_entry), "activate",
                       GTK_SIGNAL_FUNC(fad_mask_cb), (gpointer) fad);

   gtk_widget_show( fad->mask_entry );

   /*---------------------------------------------
   **  refresh button
   */
   button = gtk_button_new_with_label( "Refresh");
   gtk_table_attach_defaults( GTK_TABLE(table), button, 85, 100, 0, 8 );
   gtk_signal_connect( GTK_OBJECT (button), "clicked",
      GTK_SIGNAL_FUNC (fad_refresh_cb ), (gpointer) fad );
   gtk_widget_show(button);

   /*---------------------------------------------
   **  clist with scroll bars to show directories
   */
   dir_title[0] = "Directories";
   fad->dir_clist = gtk_clist_new_with_titles( 1, (gchar**) dir_title );
   gtk_clist_set_shadow_type (GTK_CLIST(fad->dir_clist), GTK_SHADOW_IN );
   gtk_clist_set_selection_mode( GTK_CLIST(fad->dir_clist), GTK_SELECTION_EXTENDED );
   gtk_clist_column_titles_passive( GTK_CLIST(fad->dir_clist) );
   gtk_widget_set_usize( GTK_WIDGET(fad->dir_clist), 250, 100 );
   gtk_signal_connect( GTK_OBJECT(fad->dir_clist), "select_row",
      GTK_SIGNAL_FUNC(fad_dir_clist_cb), (gpointer) fad );

   gtk_widget_show(fad->dir_clist);

   scrollbars = gtk_scrolled_window_new( NULL, NULL );
   gtk_container_add( GTK_CONTAINER(scrollbars), fad->dir_clist );
   gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(scrollbars),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS );
   gtk_container_set_border_width( GTK_CONTAINER(scrollbars), 5 );
   gtk_table_attach_defaults( GTK_TABLE(table), scrollbars, 0, 50, 8, 76 );
   gtk_widget_show( scrollbars );

   /*---------------------------------------------
   **  clist with scroll bars to show files
   */
   file_title[0] = "Files";
   fad->file_clist = gtk_clist_new_with_titles( 1, (gchar**) file_title );
   gtk_clist_set_shadow_type (GTK_CLIST(fad->file_clist), GTK_SHADOW_IN );
   gtk_clist_set_selection_mode( GTK_CLIST(fad->file_clist), GTK_SELECTION_EXTENDED );
   gtk_clist_column_titles_passive( GTK_CLIST(fad->file_clist) );
   gtk_widget_set_usize( GTK_WIDGET(fad->file_clist), 250, 100 );
   gtk_signal_connect( GTK_OBJECT(fad->file_clist), "select_row",
      GTK_SIGNAL_FUNC(fad_file_clist_cb), (gpointer) fad );

   gtk_widget_show(fad->file_clist);

   scrollbars = gtk_scrolled_window_new( NULL, NULL );
   gtk_container_add( GTK_CONTAINER(scrollbars), fad->file_clist );
   gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(scrollbars),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS );
   gtk_container_set_border_width( GTK_CONTAINER(scrollbars), 5 );
   gtk_table_attach_defaults( GTK_TABLE(table), scrollbars, 50, 100, 8, 76 );
   gtk_widget_show( scrollbars );

   /*---------------------------------------------------------
   **  label to let the user know what the current path is:
   */
   label = gtk_label_new( " Directory: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 20, 78, 84 );
   gtk_widget_show( label );

   fad->path_entry = gtk_entry_new_with_max_length( DIRLIST_MAX_PATH );
   gtk_entry_set_editable( GTK_ENTRY(fad->path_entry), FALSE );
   gtk_table_attach_defaults( GTK_TABLE(table), fad->path_entry, 20, 95, 78, 84 );
   gtk_widget_show( fad->path_entry );

   /*---------------------------------------------------------
   **  label to let the user know what the current filename is:
   */
   label = gtk_label_new( " Filename: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 0, 20, 86, 92 );
   gtk_widget_show( label );

   fad->file_entry = gtk_entry_new_with_max_length( 80 );
   gtk_entry_set_editable( GTK_ENTRY(fad->file_entry), TRUE );
   gtk_table_attach_defaults( GTK_TABLE(table), fad->file_entry, 20, 60, 86, 92 );
   gtk_widget_show( fad->file_entry );

   /*---------------------------------------------------------
   **  buffer option menu to select the buffer for the data:
   */
   label = gtk_label_new( " Buffer: " );
   gtk_misc_set_alignment( GTK_MISC(label), 1, 0.5 );
   gtk_table_attach_defaults( GTK_TABLE(table), label, 60, 80, 86, 92 );
   gtk_widget_show( label );

   menu = MyCreateMenuFromSelection( selection, FALSE, fad_buffer_cb, fad );
   fad->buffer_option_w = gtk_option_menu_new();
   gtk_option_menu_set_menu( GTK_OPTION_MENU(fad->buffer_option_w), menu );

   gtk_table_attach_defaults( GTK_TABLE(table), fad->buffer_option_w, 80, 95, 86, 92 );
   gtk_widget_show( fad->buffer_option_w );

   /*---------------------------------
   **  hseparator
   */
   widget = gtk_hseparator_new();
   gtk_table_attach_defaults( GTK_TABLE(table), widget, 0, 100, 92, 94 );
   gtk_widget_show( widget );

   /*---------------------------------
   **  OK button
   */
   fad->ok_button = gtk_button_new_with_label( "OK");
   gtk_table_attach_defaults( GTK_TABLE(table), fad->ok_button, 5, 20, 94, 100 );
   gtk_signal_connect( GTK_OBJECT (fad->ok_button), "clicked",
       GTK_SIGNAL_FUNC ( fad_ok_cb ), (gpointer) fad );
   gtk_widget_show(fad->ok_button);

   /*---------------------------------
   **  Cancel button to hide dialog
   */
   button = gtk_button_new_with_label( "Cancel");
   gtk_table_attach_defaults( GTK_TABLE(table), button, 30, 45, 94, 100 );
   gtk_signal_connect( GTK_OBJECT (button), "clicked",
      GTK_SIGNAL_FUNC (fad_cancel_cb ), (gpointer) fad );
   gtk_widget_show(button);

   gtk_widget_show( table );
   return 0;
}

/*-----------------------------------------------------------------------
** fad_show_dialog() - show the window.
**-----------------------------------------------------------------------
*/
void fad_show_dialog ( struct fileAccessDialog_t *fad )
{
   gtk_widget_show( fad->dialog_window );
   gdk_window_raise( fad->dialog_window->window );
}

/*-----------------------------------------------------------------------
** fad_hide_dialog() - hides the fad window.
**-----------------------------------------------------------------------
*/
void fad_hide_dialog ( struct fileAccessDialog_t *fad )
{
   gtk_widget_hide( fad->dialog_window );
}

/*-----------------------------------------------------------------------
** fad_set_path() - Set a new path.
**-----------------------------------------------------------------------
*/
void fad_set_path( struct fileAccessDialog_t *fad, char * path )
{
   /*-------------------------------------
   ** call function to make directory list
   */
   dirlist_newpath( &fad->dirlist, path );

   /*----------------------------------------------
   ** update the option menu
   */
   {
      GtkWidget * old_menu;
      GtkWidget * new_menu;

      old_menu = gtk_option_menu_get_menu( GTK_OPTION_MENU(fad->path_option_w) );
      gtk_option_menu_remove_menu( GTK_OPTION_MENU(fad->path_option_w) );
      /* gtk_widget_destroy( old_menu ); */

      new_menu = MyCreateMenuFromSelection( fad->dirlist.list, FALSE,
         fad_menuitem_cb, fad );
      gtk_option_menu_set_menu( GTK_OPTION_MENU(fad->path_option_w), new_menu );
   }

   /*----------------------------------------------
   ** update the directory list
   */
   update_file_list( TRUE, fad->dirlist.path, "*", fad->dir_clist );
   update_file_list( FALSE, fad->dirlist.path, fad->mask, fad->file_clist );

   /*----------------------------------------------
   ** update the label
   */
   gtk_entry_set_text( GTK_ENTRY(fad->path_entry), fad->dirlist.path );
}

/*-----------------------------------------------------------------------
** fad_set_filename() - Set a new filename.
**-----------------------------------------------------------------------
*/
void fad_set_filename( struct fileAccessDialog_t *fad, char * filename )
{
   /*-------------------------------------
   ** get filename
   */
   strxcpy( fad->filename, filename, sizeof(fad->filename) );

   /*----------------------------------------------
   ** update the label
   */
   gtk_entry_set_text( GTK_ENTRY(fad->file_entry), fad->filename );
}

/*-----------------------------------------------------------------------
** fad_set_buffer() - Set a new buffer.
**-----------------------------------------------------------------------
*/
void fad_set_buffer( struct fileAccessDialog_t *fad, int bufinx )
{
   /*-------------------------------------
   ** call function to make diretory list
   */
   fad->bufinx = bufinx;

   /*----------------------------------------------
   ** update the option menu
   */
   gtk_option_menu_set_history( GTK_OPTION_MENU(fad->buffer_option_w), fad->bufinx );
}

/*-----------------------------------------------------------------------
**  fad_set_ok_cb() - allows user to install their own OK button callback.
**-----------------------------------------------------------------------
*/
void fad_set_ok_cb( struct fileAccessDialog_t *fad, GtkSignalFunc func )
{
   gtk_signal_connect( GTK_OBJECT (fad->ok_button), "clicked", func,
      (gpointer) fad );
}

/*-----------------------------------------------------------------------
**  fad_set_buffer_cb() - allows user to install their own buffer menu callback.
**-----------------------------------------------------------------------
*/
void fad_set_buffer_cb( struct fileAccessDialog_t *fad, GtkSignalFunc func )
{
   fad->func = func;
}

/********************************************************************************/
/*  FAD's Internal functions                                                    */
/********************************************************************************/

/*-----------------------------------------------------------------------
**  fad_delete_event()
**-----------------------------------------------------------------------
*/
int fad_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data )
{
   /* Return FALSE - gtk will call base_destroy_cb();
   **         TRUE - gtk will ignore delete event.
   */
   gtk_widget_hide( GTK_WIDGET(widget) );
   return(TRUE);
}

/*-------------------------------------------------------------------------------
** fad_ok_cb() - the default ok button callback.
**-------------------------------------------------------------------------------
*/
void fad_ok_cb( GtkWidget *widget, gpointer data )
{
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

#if DEBUG
   printf("fad_ok_cb() the path is %s\n", fad->dirlist.path );
#endif

   fad_hide_dialog( fad );
}

/*-------------------------------------------------------------------------------
** fad_cancel_cb() - the default cancel callback. Just hides the dialog
**   window.
**-------------------------------------------------------------------------------
*/
void fad_cancel_cb( GtkWidget *widget, gpointer data )
{
   fad_hide_dialog( (struct fileAccessDialog_t *)data );
}

/*-------------------------------------------------------------------------------
** fad_buffer_cb() - the default buffer callback. Just saves the buffer index.
**-------------------------------------------------------------------------------
*/
void fad_buffer_cb( GtkMenuItem * menuitem, gpointer data )
{
   struct fileAccessDialog_t *fad;

   fad = (struct fileAccessDialog_t *)gtk_object_get_user_data( GTK_OBJECT(menuitem) );
   fad->bufinx = (int)data;      /* selected path from option menu */

   if( fad->func != NULL )
       (fad->func)( menuitem, data );
}

/*-------------------------------------------------------------------------------
**  fad_mask_cb() - call back to set TCS hostname.
**-------------------------------------------------------------------------------
*/
void fad_mask_cb( GtkEntry *widget, gpointer data )
{
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   /* copy mask sting into fad structure */
   strxcpy( fad->mask, gtk_entry_get_text(GTK_ENTRY(widget)), sizeof(fad->mask) );

   /* update file list */
   update_file_list( FALSE, fad->dirlist.path, fad->mask, fad->file_clist );
}

/*-------------------------------------------------------------------------------
** fad_refresh_cb() - refreshes the list
**-------------------------------------------------------------------------------
*/
void fad_refresh_cb( GtkWidget *widget, gpointer data )
{
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   /* update the directory list */
   update_file_list( TRUE, fad->dirlist.path, "*", fad->dir_clist );

   /* update file list */
   update_file_list( FALSE, fad->dirlist.path, fad->mask, fad->file_clist );
}

/*-----------------------------------------------------------------------
** fad_menuitem_cb - the default menu item callback. Set new path from
**   user's selection.
**-----------------------------------------------------------------------
*/
void fad_menuitem_cb( GtkMenuItem * menuitem, gpointer data )
{
   int inx;
   struct fileAccessDialog_t *fad;
   char newpath[DIRLIST_MAX_PATH];

   inx = (int)data;      /* selected path from option menu */
   fad = (struct fileAccessDialog_t *)gtk_object_get_user_data( GTK_OBJECT(menuitem) );

   strxcpy( newpath,  fad->dirlist.list[inx], sizeof(newpath) );
   fad_set_path( fad, newpath );
}

/*-----------------------------------------------------------------------
** fad_dir_clist_cb - the directory clist selection callback. Selects a new path
**    from user's selection.
**-----------------------------------------------------------------------
*/
void fad_dir_clist_cb( GtkCList * clist, gint row, gint col, GdkEventButton *event,
                       gpointer data )
{
   char * text;
   char newpath[DIRLIST_MAX_PATH];
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   if( col==0 ) /* if col == 0 means it was double click (not sure why) */
   {
      gtk_clist_get_text( clist, row, col, &text );
      cat_pathname( newpath, fad->dirlist.path, text, sizeof(newpath) );
      fad_set_path( fad, newpath );
      if ( fad->clearfilenameflag )
         fad_set_filename( fad, "" );
   }
}

/*-----------------------------------------------------------------------
** fad_file_clist_cb - the file clist selection callback. Selects a new filename
**    from user's selection.
**-----------------------------------------------------------------------
*/
void fad_file_clist_cb( GtkCList * clist, gint row, gint col, GdkEventButton *event,
                        gpointer data )
{
   char * text;
   struct fileAccessDialog_t *fad = (struct fileAccessDialog_t *)data;

   gtk_clist_get_text( clist, row, 0, &text );
   fad_set_filename( fad, text );
}

/********************************************************************************/
/********************************************************************************/
