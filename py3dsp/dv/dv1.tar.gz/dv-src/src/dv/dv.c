/********************************************************************************/
/*  DV.C - main source file for the DV application                              */
/********************************************************************************/

#define EXTERN
#define MAIN 1

/*--------------------------------------------------------
**  Non-standard include files added by the U of R NIR Lab
**--------------------------------------------------------
*/
#include "rpc_dv.h"


/*------------------------
**  Standard include files
**------------------------
*/
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/time.h>
#include <sys/types.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <gtk/gtk.h>

/*----------------------------
**  Non-standard include files
**----------------------------
*/
#include <error_msg.h>
#include <addlib.h>
#include <dflib.h>

#include "cm.h"           /* include colormap information  */
#include "dialog.h"       /* include misc dialog box */

#include "dv.h"           /* DV MAIN APPLICATION  */


/*-----------------------------------------------------------------------
**  main()
**-----------------------------------------------------------------------
*/
int main( int argc, char *argv[] )
{
   int pseudocolor_ok,
       truecolor_ok,
       dvport,
       rc,
       c, i;
   char *font_name;
   char buf[128];

   extern char *optarg;
   extern int optind, opterr;

   register SVCXPRT *transp;

   /* initialize gtk & parse gtk related command line arguments. */
   gtk_init(&argc, &argv);

   /*----------------------------------------------------------
   ** parse command line arguments for application options.
   */
   rc = ERR_NONE;
   dvport         = IRTF_DV_PORT;
   font_name      = NULL;
   pseudocolor_ok = TRUE;
   truecolor_ok   = TRUE;
   Lc.num_dpy     = 5;
   while( (c = getopt( argc, argv, "PTf:mlp:")) > 0 )
   {
      switch( c )
      {
         case 'P':
            /* Force pseudoColor, by disabling trueColor */
            pseudocolor_ok = TRUE;
            truecolor_ok = FALSE;
            break;

         case 'T':
            /* Force trueColor, by disabling pseudoColor */
            truecolor_ok = TRUE;
            pseudocolor_ok = FALSE;
            break;

         case 'f':
            font_name = optarg;
            break;
            /* font */

         case 'm':
            /* medium DV */
            Lc.num_dpy = 7;
            break;

         case 'l':
            /* large DV */
            Lc.num_dpy = 9;
            break;

         case 'p':
            i = atoi(optarg);
            if( INRANGE( IRTF_VIEWER_MSGQ, i, IRTF_DV_GUIDEDOG_PORT))
               dvport = i;
            break;

         default:
            rc = ERR_INV_OPERATION;
            break;
      }
   }
#if DEBUG
   if( font_name )
   	printf("     font_name=%s \n", font_name );
   printf("  truecolor_ok=%d \n", truecolor_ok );
   printf("pseudocolor_ok=%d \n", pseudocolor_ok );
   printf("    Lc.num_dpy=%d \n", Lc.num_dpy );
   printf("    Num_buffer=%d \n", NUM_BUFFER );
#endif

   /* any command line error? Display usage and exit */
   if( rc )
   {
      usage();
      exit(0);
   }

   /*----------------------------------------------
   ** call function to setup application's colors
   */
   if( cm_setup( pseudocolor_ok, truecolor_ok, TRUE ) != ERR_NONE )
   {
      printf("Error initializing colors for application. Exiting..\n");
      exit(0);
   }

   /*------------------------------------------------
   ** call function to create all GTK+ GUI elements
   */
   create_base( font_name );

   /*--------------------------------
   ** Initialize dflib options.
   */
   df_init();
   dfset_divbycoadd( FALSE );
   dfset_origin( DF_ORIGIN_TL );

   /*--------------------------------
   ** Initialize application globals
   */
   initialize_globals();

   /*--------------------------------
   ** Initialize application globals
   */
   {
      FILE *fp;

      expand_pathname( buf, sizeof(buf), "$HOME");
      cat_pathname( buf, buf, ".dv-init", sizeof(buf));
      if( NULL != ( fp = fopen( buf, "rt")) )
      {
         while( NULL != fgets( buf, sizeof(buf), fp))
         {
            unpad( buf, '\n');
            cmd_execute( buf, FALSE );
         }
         fclose( fp );
      }
   }

   /*-------------------------------------------------------
   ** Setup socket & accept Event input on file descriptor.
   */

   Lc.sock_tag = 0;
   if( (Lc.sock_fd = sock_setup_server( dvport )) < 0 )
   {
      printTextOut( CM_RED, "WARNING: dv executing without socket suppport!\n");
   }
   else
   {
      Lc.sock_tag = gdk_input_add( Lc.sock_fd, GDK_INPUT_READ,
         (GdkInputFunction) socket_accept_connection, NULL );
#if DEBUG
      printf("AddInput on sock_fd %d, tag=%d. Using Port %d\n",
         Lc.sock_fd, Lc.sock_tag, dvport);
#endif
      Lc.dvport = dvport;  /* save for label in setup page */

		sprintf( buf, "Dv socket port is %d ", Lc.dvport);
		gtk_label_set_text( GTK_LABEL(Dvport_w), buf );

   }

   /*----------------------------------------------------
   ** This code block creates an RPC the service
   ** DVRPCPROG, which is used by the dspsys dsp software
   ** used by the U of R NIR Lab. It was easier than 
   ** learning forth programming.
   ** 
   ** Richard Emile Sarkis, 4/6/2001
   */

   /* Establish the UDP-transport server daemon. */
   pmap_unset (DVRPCPROG, DVRPCVERS);
   
   transp = svcudp_create(RPC_ANYSOCK);

   /* We are creating a UDP Service. */
   if (transp == NULL) {
     fprintf (stderr, "%s", "Warning: cannot create udp service. RPC communications to DV unavailable.");
   }
   if (!svc_register(transp, DVRPCPROG, DVRPCVERS, dvrpcprog_1, IPPROTO_UDP)) {
     fprintf (stderr, "%s", "Warning: unable to register (DVRPCPROG, DVRPCVERS, udp). RPC communications to DV unavailable.");
   }
   
   /* This call cycles every 200ms, calling "handle_rpc" 
   ** which takes care of any pending RPC requests. 
   */
   gtk_timeout_add(200, (GtkFunction) handle_rpc , NULL);

   /* End U of R NIR Code*/


   /*--------------------------------
   ** GTK main event loop
   */
   gtk_main ();
   return 0;
}

/*-----------------------------------------------------------------------
**  initialize_globals( ) - Initialize the Dpy, Buffer, Stats, and other
**                          DV globals variables.
**-----------------------------------------------------------------------
*/
void initialize_globals( void )
{
   int i;

   /* Initialize DPY structures.  */
   for(i=0; i<Lc.num_dpy; i++)
   {
      Dpy[i].bufinx = (i < NUM_BUFFER ? i : NUM_BUFFER-1 );

      Dpy[i].image_min = 0;
      Dpy[i].image_max = 10000;
      Dpy[i].image_zoom = 1;
      Dpy[i].image_autoscale = 1;

      Dpy[i].hist_bin = 50;

      Dpy[i].lcut_autoscale = 1;
      Dpy[i].lcut_min = 0;
      Dpy[i].lcut_max = 10000;

      Dpy[i].noise_mod = 4;
      Dpy[i].noise_graph_type = 1;
      Dpy[i].noise_autoscale = 1;
      Dpy[i].noise_area = 0;
      Dpy[i].noise_g1_min = 0;
      Dpy[i].noise_g1_max = 65000;
      Dpy[i].noise_g2_min = 0;
      Dpy[i].noise_g2_max = 500;

      Dpy[i].xcut_autoscale = 1;
      Dpy[i].xcut_min = -100;
      Dpy[i].xcut_max =  256;
      Dpy[i].xcut_xbeg = 0;
      Dpy[i].xcut_ybeg = 0;

      Dpy[i].pt_image_size = 11;
   }

   /* Initialize BUFFER structures.  */
   for(i=0; i<NUM_BUFFER; i++)
   {
      Buffer[i].status  = DF_EMPTY;
      Buffer[i].fheader = NULL;
      Buffer[i].fdata   = NULL;

      Stats[i].objx   = Stats[i].skyx   = 0;
      Stats[i].objy   = Stats[i].skyy   = 0;
      Stats[i].objwid = Stats[i].skywid = 1;
      Stats[i].objhgt = Stats[i].skyhgt = 1;
      Stats[i].ln_xbeg = 0;
      Stats[i].ln_ybeg = 0;
      Stats[i].ln_xend = 1;
      Stats[i].ln_yend = 1;
   }

   /* Initialize LC structure.  */
   if( NULL == (Lc.app_home = getenv( APP_HOME_VAR )))
      Lc.app_home = "./";
#if DEBUG
   printf("home_dir = %s\n", Lc.app_home );
#endif

   /* initialize file access structure */
   fad_set_path( &Fad_open, "$HOME" );
   fad_set_path( &Fad_save, "$HOME" );

   /* initialize macro structure */
   cmd_execute("m.filemask *", FALSE);
   cmd_execute("m.path $HOME", FALSE);

   Md.fp = NULL;
   Md.fbutton_index = 0;
   Md.filename = NULL;
   for( i=0; i<NUM_FUN_BUT; i++)
   {
      Md.fb_ok[i] = FALSE;
      Md.fb_path[i][0] = 0;
      Md.fb_fname[i][0] = 0;
   }

   Lc.offset_angle      = COORD_SPEX_ANGLE;
   Lc.offset_platescale = COORD_SPEX_PSCALE;

   sprintf( Lc.tcshostname, "vtcshost" );
   Lc.stack_inx = 0;
   for( i=0; i<NUM_CMD_STACK; i++)
      Lc.cmd_stack[i] = NULL;
}

/*-------------------------------------------------------------------------------
**   usage() - display usage to user.
**-------------------------------------------------------------------------------
*/
void usage( void )
{
   printf( "   usage: dv [OPTION] \n\n"
           "   options: -m       Medium DV - Provides 7 data display drawing areas. Default is 5.\n"
           "            -l       Large  DV - Provides 9 data display drawing areas.\n"
           "            -P       PseudoColor - Runs in 8 bit PseudoColor Visual Mode (default).\n"
           "            -T       TrueColor - Runs in True Color Visual Mode.\n"
           "            -p num   Port Number - Specifies the TCP/IP data port for DV.\n"
           "            -f font  Font - Sets the application font to 'font'\n\n");
}

/*--------------------------------------------------------------
** cal_box_stats_subf() - calculates STD on a box
**--------------------------------------------------------------
*/
void cal_box_stats_subf( bp, type, objx, objy, objwid, objhgt, skyx, skyy,
                         rN, rmin, rmax, rsum, rmean, rstd)
struct df_buf_t *bp;                    /* buffer pointer */
int    type;                            /* 1=box; 2=box-sky */
int    objx, objy, objwid, objhgt;      /* object box location */
int    skyx, skyy;                      /* sky    box location */
double *rN, *rmin, *rmax, *rsum, *rmean, *rstd; /* statistics returned here */
{
   int x, y,
       objinx, skyinx;
   double min, max, mean, Sdd, sum, data, N, stddev;

   Sdd = sum = N = 0;
   min = DF_MAX_SIGNED_LONG;
   max = DF_MIN_SIGNED_LONG;
   skyinx = 0;

   if( bp->status != DF_EMPTY )
      for( x = 0; x < objwid; x++)
         for( y = 0; y < objhgt; y++)
         {
            /*  Determine index to pixel for object & sky */
            if( !INRANGE(0, objx+x, bp->naxis1-1) || !INRANGE(0, objy+y, bp->naxis2-1) )
               goto Lskip;
            objinx = (objy+y) * bp->naxis1 + (objx+x);
            if( type == 2 )
            {
               if( !INRANGE(0, skyx+x, bp->naxis1-1) || !INRANGE(0, skyy+y, bp->naxis2-1) )
                  goto Lskip;
               skyinx = (skyy+y) * bp->naxis1 + (skyx+x);
            }

            /*  Determine value of obj pixel */
            data = dfdatainx(bp, objinx);

            /*  Determine value of sky pixel */
            if( type == 2 )
               data -= dfdatainx(bp, skyinx);

            if( min > data ) min = data;
            if( max < data ) max = data;
            sum += data;
            Sdd += data * data;
            N++;
   Lskip:
            objinx = 0; /* nop */
         }

   if( N < 1 )
      mean = 0;
   else
      mean = sum / N;

   if( N < 2 )
   {
      Sdd = 0;
      stddev = 0;
   }
   else
   {
      Sdd -= N * (mean*mean);
      stddev = sqrt(Sdd / (N-1));
   }

   *rmin  = min;
   *rmax  = max;
   *rN    = N;
   *rsum  = sum;
   *rmean = mean;
   *rstd  = stddev;
   return;
}

/*----------------------------------------------------------------
**  cal_box_stats( ) - Update the box stats variables for
**     the buffer Buffer[bufinx].
**----------------------------------------------------------------
*/
void cal_box_stats( bufinx )
int bufinx;    /* Index to buffer */
{
   double N, min, max, sum, mean, stddev;

   struct df_buf_t *bp;
   struct stats_t *sptr;

   if( !INRANGE( 0, bufinx, NUM_BUFFER ))
      return;

   bp = &Buffer[bufinx];
   sptr = &Stats[bufinx];

   /* Do object             */
   cal_box_stats_subf(  bp, 1,
                        sptr->objx, sptr->objy,
                        sptr->objwid, sptr->objhgt,
                        0, 0, &N, &min, &max, &sum, &mean, &stddev);
   sptr->objmin = min;
   sptr->objmax = max;
   sptr->objsum = sum;
   sptr->objmean= mean;
   sptr->objstd = stddev;
   sptr->objN   = N;

   /* Do sky                */
   cal_box_stats_subf(  bp, 1,
                        sptr->skyx, sptr->skyy,
                        sptr->skywid, sptr->skyhgt,
                        0, 0, &N, &min, &max, &sum, &mean, &stddev);
   sptr->skymin = min;
   sptr->skymax = max;
   sptr->skysum = sum;
   sptr->skymean= mean;
   sptr->skystd = stddev;
   sptr->skyN   = N;
   /* Do object - sky       */
   if( sptr->objwid == sptr->skywid &&
       sptr->objhgt == sptr->skyhgt )
   {
      cal_box_stats_subf(  bp, 2,
                           sptr->objx, sptr->objy,
                           sptr->objwid, sptr->objhgt,
                           sptr->skyx, sptr->skyy,
                           &N, &min, &max, &sum, &mean, &stddev);
      sptr->redmin = min;
      sptr->redmax = max;
      sptr->redsum = sum;
      sptr->redstd = stddev;
      sptr->redN   = N;
   }
   else
   {
      sptr->redmin = 0;
      sptr->redmax = 0;
      sptr->redsum = 0;
      sptr->redstd = 0;
      sptr->redN   = 0;
   }
}

/********************************************************************************/
/*  TCS communciation routines                                                  */
/********************************************************************************/

/*----------------------------------------------------------------------------
**  tcs_com() - basic routine for communicating with TCS.
**----------------------------------------------------------------------------
*/
int tcs_com( command, reply, reply_size, tcshostname )
   char * command;        /* command to send to the tcs */
   char * reply;          /* reply is copied here */
   int    reply_size;     /* size of reply buffer */
   char * tcshostname;    /* hostname of tcs */
{
   int connect_fd, rc;
   char msgbuf[SOCKET_MSG_LEN+1];

   rc = ERR_NONE;
   if( (connect_fd = sock_open( tcshostname, TCS_MSG_PORT)) < 0)
      return ERR_SOCKET_ERR;
    else
    {
       /*  Send command to socket */
#if DEBUG
       printf("tcs_com sending >> [%s]\n", command);
#endif
       rc = (sock_write_msg( connect_fd, command, TRUE, DV_SOCK_TIMEOUT) < 0) ?
             ERR_SOCKET_ERR : ERR_NONE;

       /*  Get reply from socket */
       if( rc == ERR_NONE )
          rc = (sock_read_msg( connect_fd, msgbuf, TRUE, DV_SOCK_TIMEOUT) < 0 ) ?
                ERR_SOCKET_ERR : ERR_NONE;

       /*  Close socket */
       close( connect_fd );

#if DEBUG
       printf("tcs_com rec'd   << [%s]\n", msgbuf);
#endif
       /*  Copy reply to caller */
       if( rc == ERR_NONE )
          strxcpy( reply, msgbuf, reply_size);
    }

    return rc;
}

/********************************************************************************/
/*  Spex support functions                                                      */
/********************************************************************************/

/*----------------------------------------------------------------------------
**  spex_com() - basic routine for communicating with spex. Searches for and
**    post a message to spex's message queue. Dv must be running on the spex
**    computer. No reply from spex is requested.
**    This function copies many definitions from the spex_def.h & spex_struct.h
**    files.
**----------------------------------------------------------------------------
*/
int spex_com( char * command )
{

   struct msgbody_t      /* message structure for sending text commands */
   {
      long from;      /* The reply is posted to this message queue ID. */
      long rc;        /* Return code of text command is place here.    */
      long pcode;     /* permission code of command                    */
      char txt[80];   /* Used for Text command/Return string.          */
   };

   struct msg_t      /* message structure for sending text commands */
   {
      long             mtype;  /* message type field */
      struct msgbody_t m;      /* message body */
   };

   int msgq_command;
   struct msg_t msg;

   /*-------------------------------------------------------
   ** find message queue - spex uses message queue ID 30160
   */
   if( (msgq_command = msgtran( 30160, FALSE )) < 0 )
   {
      printTextOut( CM_RED, "Can't find SPeX's message queue.\n");
      return ERR_MSGQ;
   }

   /*---------------------------------------------
   ** setup message structure  & send command.
   */
   msg.mtype = 1;
   msg.m.from  = -1;  /* no reply  */
   msg.m.pcode = 0;   /* pcode_obs */
   strxcpy( msg.m.txt, command, sizeof(msg.m.txt));

   if( msgsnd( msgq_command, &msg, sizeof(struct msgbody_t), IPC_NOWAIT) < 0 )
   {
      printTextOut( CM_RED, "Error sending command to SPeX's message queue.\n");
      return ERR_MSGQ;
   }
   return ERR_NONE;
}

/*----------------------------------------------------------------------------
**  spex_fix_subarray_dim() -  This function takes a subarray dimension and
**     fixes it so that:
**       - the q2, q3, q4 (on a 1024x1024) device spection are specific in q1
**         (so that the mirroring will include these pixels)
**       - adjust x,y,w,h it fits the limitation of the readout and includes
**         all the pixels.
**----------------------------------------------------------------------------
*/
int spex_fix_subarray_dim( int *ax, int *ay, int *awid, int *ahgt)
{
    int x, y, wid, hgt;
    int ts, te, s, e, w;

    /* copy parameters from caller */
    x = *ax; y = *ay; wid = *awid; hgt = *ahgt;

#if DEBUG
printf("spex_fix_subarray_dim( ):\n" );
printf("-------------------------\n" );
printf("  before: %d,%d  %dx%d \n", x, y, wid, hgt);
#endif
    /*----------------------------------------
    ** do x axis
    */
    if( (x > 512) || (x+wid > 512) )
    {
#if DEBUG
      printf("adjusting X axis. \n" );
#endif
      /* get x,wid in 2 quad */
      ts = MAX(512, x);
      te = (x+wid-1);
#if DEBUG
      printf("  ts=%d te=%d\n", ts, te );
#endif

      /* transpose ts, te to start/end points in 1st quad */
      s = 1023 - te;    /* start pixel */
      e = 1023 - ts;    /* end pixel */
      w = e-s+1;        /* width */
#if DEBUG
      printf("  s=%d e=%d w=%d \n", s, e, w );
#endif

      /* Adust x,wid to include these points */
      x = MIN( x, s);
      wid = MAX( wid, w);
      wid = MIN( 512-x, wid);
#if DEBUG
      printf("  adjusted x=%d wid=%d\n", x, wid );
#endif
   }

   /*----------------------------------------
   ** make adjustment for readout boundaries.
   */

   /* x should be on 16 pixel boundary */
   s = x % 16;
   x -= s;
   wid += s;
#if DEBUG
   printf("  adj. bod. x=%d wid=%d\n", x, wid );
#endif

   /* wid should on 16 pixel boundary, but 32 or greater */
   s    = 16 - (wid % 16);
   wid += s;
   wid = MIN( 512-x, wid);
#if DEBUG
   printf("  adj. bod. x=%d wid=%d\n", x, wid );
#endif

   /*----------------------------------------
   ** do y axis
   */
   if( (y > 512) || (y+hgt > 512) )
   {
#if DEBUG
      printf("adjusting Y axis. \n" );
#endif
      /* get x,wid in 2 quad */
      ts = MAX(512, y);
      te = (y+hgt-1);
#if DEBUG
      printf("  ts=%d te=%d\n", ts, te );
#endif

      /* transpose ts, te to start/end points in 1st quad */
      s = 1023 - te;    /* start pixel */
      e = 1023 - ts;    /* end pixel */
      w = e-s+1;        /* width */
#if DEBUG
      printf("  s=%d e=%d w=%d \n", s, e, w );
#endif

      /* Adust y, hgt to include these points */
      y = MIN( y, s);
      hgt = MAX( hgt, w);
      hgt = MIN( 512-y, hgt);
#if DEBUG
      printf("  adjusted y=%d hgt=%d\n", y, hgt );
#endif
   }

   /*----------------------------------------
   ** make adjustment for readout boundaries.
   */

   /* y should be on 4 pixel boundary */
   s = y % 4;
   y -= s;
   hgt += s;
#if DEBUG
   printf("  adj. bod. y=%d hgt=%d\n", y, hgt );
#endif

   /* hgt should on 4 pixel boundary, but 4 or greater */
   s    = 4 - (wid % 4);
   hgt += s;
   hgt = MIN( 512-y, hgt);
#if DEBUG
   printf("  adj. bod. y=%d hgt=%d\n", y, hgt );
#endif

   /* copy results to caller */
   *ax = x; *ay = y; *awid = wid; *ahgt = hgt;
#if DEBUG
   printf("  after: %d,%d  %dx%d \n", x, y, wid, hgt);
#endif
   return ERR_NONE;
}

/*-------------------------------------------------
**  dvrpcprog_1() - This is the RPC server portion
**  of our code. After initializing our RPC service
**  This code is called by the svc_getreqset() 
**  function in handle_rpc(). When called, 
**  dvrpcprog_1() will look at the incoming request
**  and decided if it is a valid one to process.
**
** Richard Emile Sarkis, 4/6/2001
*/
void dvrpcprog_1(struct svc_req *rqstp, register SVCXPRT *transp)
{
        union {
                char *dv_command_1_arg;
        } argument;
        char *result;
        xdrproc_t _xdr_argument, _xdr_result;
        char *(*local)(char *, struct svc_req *);

        switch (rqstp->rq_proc) {
        case NULLPROC:
                (void) svc_sendreply (transp, (xdrproc_t) xdr_void, (char *)NULL);
                return;

        case DV_COMMAND:
                _xdr_argument = (xdrproc_t) xdr_wrapstring;
                _xdr_result = (xdrproc_t) xdr_int;
                local = (char *(*)(char *, struct svc_req *)) dv_command_1_svc;
                break;

        default:
                svcerr_noproc (transp);
                return;
        }
        memset ((char *)&argument, 0, sizeof (argument));
        if (!svc_getargs (transp, _xdr_argument, (caddr_t) &argument)) {
                svcerr_decode (transp);
                return;
        }
        result = (*local)((char *)&argument, rqstp);
        if (result != NULL && !svc_sendreply(transp, _xdr_result, result)) {
                svcerr_systemerr (transp);
        }
        if (!svc_freeargs (transp, _xdr_argument, (caddr_t) &argument)) {
                fprintf (stderr, "%s", "unable to free arguments");
                exit (1);
        }
        return;
}
/* End U of R NIR Code*/

/****************************************************************************/
/****************************************************************************/
