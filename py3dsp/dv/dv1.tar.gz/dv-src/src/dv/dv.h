/********************************************************************************/
/*  DV.H - application header file                                              */
/*  dv is a FITS Data Viewer written for the NASA IRTF. It is used as the data  */
/*  viewer in irtf instruments such as Spex. It is also Free Software. Please   */
/*  leave this message to credit the author(s) and the IRTF. If you find it     */
/*  useful, please drop me a note indicating what you are using it for.         */
/*  NASA IRTF home page: http://irtf.ifa.hawaii.edu                             */
/*       DV's home page: http://irtf.ifa.hawaii.edu/Facility/DV                 */
/*  Aloha,                                                                      */
/*  Tony Denault  (denault@irtf.ifa.hawaii.edu)                                 */
/********************************************************************************/

/*----------------------------------------------------------------------------
**  defines
**----------------------------------------------------------------------------
*/

#define APP_VERSION   "1.04 4/2001"
#define APP_NAME           "DV"
#define APP_HOME_VAR  "DV_HOME"

#define MAX_DPY               	9       /* max number of display area for data */
#define NUM_BUFFER            	8       /* number of data buffer */
#define NUM_FUN_BUT           	6       /* number of function macro buttons */

#define NUM_PIXEL          	2048       /* maximum size of image (2048x2048) */

#define NUM_DPYTYPE           	8
#define DPYTYPE_IMAGE         	0       /* values for dpyinx */
#define DPYTYPE_HEADER        	1
#define DPYTYPE_HISTOGRAM     	2
#define DPYTYPE_LINECUT       	3
#define DPYTYPE_XLINECUT   	   4
#define DPYTYPE_NOISE         	5
#define DPYTYPE_POINTER       	6	
#define DPYTYPE_STATS         	7

#define NUM_CMD_STACK        	10
#define HIST_NUM_BIN        	100       /* maximum number of histogram bins */
#define NUM_MATH_EQU          	3       /* number of math equation entries  */

#define COORD_CSHELL_ANGLE   	270.0
#define COORD_CSHELL_PSCALE    	0.20
#define COORD_NSFCAM_ANGLE     	0.0
#define COORD_NSFCAM_PSCALE    	0.30
#define COORD_SPEX_ANGLE      	10.0
#define COORD_SPEX_PSCALE      	0.25

#define DV_SOCK_TIMEOUT      	15

/*----------------------------------------------------------------------------
**  structures
**----------------------------------------------------------------------------
*/

/*----------------------------------------------------------------------------
** dpy_t - struct for managing display
*/
struct dpy_t
{
   GtkWidget * title_drawingarea;     /* Drawing area for Text, ie: names */
   GtkWidget * data_drawingarea;      /* Drawing data of data displays */
   GtkAdjustment * vadj;              /* vertical adjustments */
   GtkAdjustment * hadj;              /* horizontial adjustments */

   int      bufinx;                   /* display data in this buffer index */
   int      dpytype;                  /* type of display: image, header, graph.. */

                                      /* HEADER Display Type parameters */
   int      header_row;               /* Starting row & column position */
   int      header_col;               /* 0 indicates first position */

                                      /* IMAGE Display Type parameters */
   int      image_autoscale;          /* Fixed or Auto scaling */
   int      image_zoom;               /* zoom factor */
   float    image_min;                /* min & max range */
   float    image_max;
   int      image_offx;               /* offset variables */
   int      image_offy;

                                      /* HISTOGRAM Display Type parameters */
   int      hist_bin;                 /* Number of bins for histogram */
   int      hist_area;                /* 0 (full array) or 1 (box)    */

                                      /* LINECUT Display Type parameters */
   int      lcut_area;                /* 0 (full array) or 1 (box)    */
   int      lcut_autoscale;           /* Fixed or Auto scaling */
   float    lcut_min;                 /* min & max range */
   float    lcut_max;
   int      lcut_x;                   /* X Axis of line cut */
   int      lcut_y;                   /* Y Axis of line cut */

   int      noise_row;
   int      noise_col;
   int      noise_area;               /* 0 (full array) or 1 (box)    */
   int      noise_mod;                /* noise modular variable       */
   int      noise_graph_type;         /* 0 (text) or 1 (graphics)     */
   int      noise_autoscale;          /* autoscale the graphs         */
   float    noise_g1_min;
   float    noise_g1_max;
   float    noise_g2_min;
   float    noise_g2_max;

   int      xcut_gfit;                /* Output xgfit plot            */
   int      xcut_autoscale;           /* Fixed or Auto scaling        */
   int      xcut_xbeg;                /* Beginning end point          */
   int      xcut_ybeg;
   int      xcut_xend;                /* Ending end point             */
   int      xcut_yend;
   float    xcut_min;                 /* min & max range              */
   float    xcut_max;

   int      pt_image_size;            /* size of image: 11 to 31 */
};

struct stats_t {
   int   objx;                        /* object box x position               */
   int   objy;                        /* object box y position               */
   int   objwid;                      /* object box width                    */
   int   objhgt;                      /* object box height                   */
   float objmin;                      /* object minimum pixel value          */
   float objmax;                      /* object maximum pixel value          */
   float objsum;                      /* object sum of values                */
   float objmean;                     /* object mean of values               */
   float objstd;                      /* object stddev                       */
   int   objN;                        /* obj number of data points           */
   int   skyx;                        /* sky box x position                  */
   int   skyy;                        /* sky box y position                  */
   int   skywid;                      /* sky box width                       */
   int   skyhgt;                      /* sky box height                      */
   float skymin;                      /* sky minimum pixel value             */
   float skymax;                      /* sky maximum pixel value             */
   float skysum;                      /* sky sum of values                   */
   float skymean;                     /* sky mean of values                  */
   float skystd;                      /* sky variance                        */
   int   skyN;                        /* sky number of data points           */
   float redmin;                      /* reduce minimum pixel value          */
   float redmax;                      /* reduce maximum pixel value          */
   float redstd;                      /* reduce variance                     */
   float redsum;                      /* reduce sum of values                */
   int   redN;                        /* reduce num of data points           */

   int   fixedWH;                     /* T/F flag to fixed the wid&hig of objbox */

   int   ln_xbeg;                     /* This is not needed for stats but    */
   int   ln_ybeg;                     /* I will keep the starting and        */
   int   ln_xend;                     /* ending point of the XOR line in     */
   int   ln_yend;                     /* the same struct as the object box   */
};

/*----------------------------------------------------------------------------
** lc_t - application local variables
*/
struct lc_t
{
   char *app_home;                    /* Value of App_home_env_var   */
   int  num_dpy;                      /* number of display area for data  */

   char path[80];                     /* application's default path  */
   char dialog_path[120];             /* dialog box's default path  */
   int  file_read_bufinx;             /* selection for the File_read_buffer option menu */
   int  active;                       /* the active display */
   int  divbydivisor;                 /* divide data by divisor */
   char printer[40];                  /* name of printer */
   int  printertype;                  /* type of printer */
   int  printtofile;                  /* file to prevent sending postscript file to lp */
   char tcshostname[25];              /* Hostname of TCS */
   int  usehex;                       /* display pixel values as hex number in image display */
   int  cminverse;                    /* is the colormap inversed */
   int  dvport;                       /* port number used (for user display only) */

   int  usefitsanglescale;            /* Use FIT position angle & scale for tcs offset calculation */
   float offset_beg_x;                /* Beg (x,y) */
   float offset_beg_y;
   float offset_end_x;                /* End (x,y) */
   float offset_end_y;
   float offset_angle;                /* rotation angle */
   float offset_platescale;           /* plate scale in arcsec/pixel */
   float offset_ra;                   /* offset as a (ra,dec) */
   float offset_dec;

   int  sock_fd;                      /* file description for accepting connections */
   int  connect_fd;                   /* a current socket connections */
   int  sock_tag;                     /* return tag from gtk_input_add(), need tag to remove resource */
   int  rpc_tag;		      /* return tag from gtk_input_add(), need tag to remove resource */

   char *cmd_stack[NUM_CMD_STACK];    /* a command stack */
   int  stack_inx;                    /* index to next free stack element */

};

struct noise_t
{
   float max;
   float min;
   long N;
   double mean;
   double std;
};

struct xcut_buf_t {                    /* Used by draw_xcut() */
   int  x;
   int  y;
   long value;
};

struct hist_info {                     /* Histogram Information */
   long pixel_low;                     /* number of pixel are below bin[0]         */
   long pixel_high;                    /* number of pixel above bin[num_of_bins-1] */
   long pixel_graph;                   /* number of pixel in the graph */
   long pixel_total;                   /* total pixels */
   long max_bin_value;                 /* max value of the bins[] */

   int  num_of_bins;                   /* number of bins */
   long bins[HIST_NUM_BIN];            /* array of bins */
};

struct lcut_info {                     /* Linecut Information */
   int xmin;                           /* beginning and ending pixel for x axis */
   int xmax;
   int ymin;                           /* beginning and ending pixel for y axis */
   int ymax;

   int xaxis;                          /* where the line cut occures */
   int yaxis;

   float range_min;                    /* value scale for graph */
   float range_max;
};

/*----------------------------------------------------------------------------
** macro_t - macro dialog box local variables
*/
struct macro_t            /* Widgets and variables for macro dialog & execution support */
{
   GtkWidget * f_buttons[NUM_FUN_BUT]; /* array of function buttons */
   GtkWidget * hide_w;                 /* button to toggle Expand/Shrink on bottom window */

   GtkWidget * frame_bottom;           /* frame for bottom half of window (toggle hide/unhide) */
   GtkWidget * path_w;                 /* entry line widget to hold directory path */
   GtkWidget * file_mask_w;            /* entry line widget to hold filename mask */
   GtkWidget * file_list_w;            /* clist widget that displays all files in diretory path */
   GtkWidget * file_text_w;            /* non-editable text widget to display file contents */

   char path[80];                      /* current macro path */
   char filemask[30];                  /* filemask of filelist */
   char *filename;                     /* name of currently selected file */

   int  fb_ok[NUM_FUN_BUT];            /* flag to deter if these names/paths were ever set */
   char fb_path[NUM_FUN_BUT][80];      /* paths for function buttons */
   char fb_fname[NUM_FUN_BUT][30];     /* filenames for function buttons */

   int bottom_visible;                 /* tells us if bottom is hidden/visible */
   int fbutton_index;                  /* selection from option menu - fb index.  */
   gint exe_timerid;                   /* Execution timer ID */
   FILE * fp;                          /* file pointer of macro file to execute */
};

/*----------------------------------------------------------------------------
** Widget Globals
**----------------------------------------------------------------------------
*/
GdkFont   * Fixed_font;                /* font for drawing area repaint functions */
int         Fixed_font_wid;            /* wid & hgt of font */
int         Fixed_font_hgt;
GdkGC     * Nor_gc,                    /* Normal GC - an application wide GC */
          * Xor_gc;                    /* Xor    GC - an application wide GC */
GdkPixmap * Icon_pixmap;               /* Pixmap for Icon */

GtkWidget * Colormap_w,                /* drawing_area widget to show colormap */
          * Cmap_option_w;             /* option widget to select colormap definition */

GtkStyle  * Style_Default,             /* applicaton's default style */
          * Style_Blue,                /* default + Blue  foreground */
          * Style_Green,               /* default + Green foreground */
          * Style_Red,                 /* default + Red   foreground */
          * Style_Gray;                /* default + Gray  foreground */

GtkWidget * TextOut_w;                 /* text widget for Text output/status */
GtkWidget * LineText_w;                /* label widget for single line feedback */

GtkWidget * Math_equ_w[NUM_MATH_EQU];  /* entry widget to hold math equations */
int         Math_copy_from_bufinx,     /* Copy %from to %to */
            Math_copy_to_bufinx;
int         Math_clear_bufinx;         /* Clear bufinx */
int         Math_rotate_bufinx,        /* Rotate bufinx and operation */
            Math_rotate_ops;

int         Setup_bufinx;              /* bufinx for setup printer option */
GtkWidget * TCShostname_w;             /* entry widget for entering TCS hostname */

GtkWidget * Offset_angle_w,            /* instrument angle */
          * Offset_platescale_w,       /* instrument plate scale */
          * Use_FITS_Angle_Scale_w,    /* offon for Use_FITS_Angle_Scale_w */
          * Offset_beg_xy_w,           /* Beginning coordinates */
          * Offset_end_xy_w,           /* End coordinates */
          * Offset_radec_w;            /* the TCS offset widget (in RA & Dec) */

GtkWidget * Dpyactive_w[MAX_DPY],
          * Dpytype_w,
          * Dpybuf_w[NUM_BUFFER];
GtkWidget * Notebook_dpy_w;            /* notebook for display parameters  */

GtkWidget * ImageAutoScale_w[2],       /* {fixed|auto} selection for image autoscale */
          * ImageRangeMin_w,           /* Min & Max Image Range */
          * ImageRangeMax_w;
GtkObject * ImageZoom_w;               /* adj reference */

GtkWidget * HistArea_w[2],             /* {all|box} selection for histogram area */
          * HistBin_w,                 /* Number of bins */
          * HistRangeMin_w,            /* Min & Max Histogram Range */
          * HistRangeMax_w;

GtkWidget * LcutAutoScale_w[2],        /* {fixed|auto} selection for line cut autoscale */
          * LcutRangeMin_w,            /* Min & Max line cut Range */
          * LcutRangeMax_w,
          * LcutArea_w[2],             /* {all|box} selection for line cut area */
          * LcutX_w,                   /* X and Y axes entries for line cut */
          * LcutY_w;

GtkWidget * NoiseAutoScale_w[2],       /* {fixed|auto} selection for noise autoscale */
          * NoiseG1RangeMin_w,         /* Min & Max noise graph 1 Range */
          * NoiseG1RangeMax_w,
          * NoiseG2RangeMin_w,         /* Min & Max noise graph 2 Range */
          * NoiseG2RangeMax_w,
          * NoiseArea_w[2],            /* {all|box} selection for noise area */
          * NoiseGraphType_w[2],       /* {text|graph} selection for noise graph type */
          * NoiseMod_w;                /* The number of nodes to be drawn */

GtkWidget * XcutAutoScale_w[2],        /* {fixed|auto} selection for Xline cut autoscale */
          * XcutRangeMin_w,            /* Min & Max Xline cut Range */
          * XcutRangeMax_w,
          * XcutBeg_w,                 /* Beg and End points for line */
          * XcutEnd_w;

GtkWidget * StatsFixedWH_w;            /* Widget of fixed th width & hgt stats box */
GtkWidget * StatsWHentry_w;            /* Entry width to specify/show width & hgt */

GtkWidget * PtImageSize_w;             /* Pointer image size in pixels */

GtkWidget * DivByDivisor_w,            /* offon selection for DivByDivisor_w */
          * Printer_w,                 /* Name of printer */
          * PrinterType_w,             /* Type of ps printer (BW|Color} */
          * PrintToFile_w,             /* offon selection for PrintToFile */
          * Path_w,                    /* default path */
          * Dvport_w;                  /* a label to show the port number */

GtkWidget * Dpy_dialog_window;         /* dialog window for Dpy[]  */
GtkWidget * About_dialog_window;       /* window for about dialog  */
GtkWidget * Macro_dialog_window;       /* window for macro dialog  */
EXTERN struct macro_t Md;              /* Widget handle & other variable needed */
                                       /* for macro dialog */

struct fileAccessDialog_t Fad_open;    /* Widget handle & other variable needed */
                                       /* for file open dialog */
struct fileAccessDialog_t Fad_save;    /* Widget handle & other variable needed */
                                       /* for file save dialog */

struct browseForPath_t Bfp_path;       /* dialog struct for data path's BrowseForPath */
struct browseForPath_t Bfp_m_path;     /* dialog struct for macro path's BrowseForPath */

/*----------------------------------------------------------------------------
** Application Globals
**----------------------------------------------------------------------------
*/

EXTERN struct dpy_t Dpy[MAX_DPY];            /* Variable describing X window display */
EXTERN struct df_buf_t Buffer[NUM_BUFFER];   /* Data buffers */
EXTERN struct stats_t  Stats[NUM_BUFFER];    /* Misc stats on the data in Buffer[] */
EXTERN struct lc_t Lc;                       /* Local variables */
EXTERN struct cm_t CM;                       /* keep track of color related info */

/* define the static colors used the this application */
EXTERN struct cm_colordef_t CM_static_colors_def[CM_NUM_STATIC_COLORS]
#if MAIN
= {
/*       RED  GREEN    BLUE                */
     {     0,     0,      0},   /* Black   */
     {  1.00,     0,      0},   /* Red     */
     {     0,  1.00,      0},   /* Green   */
     {     0,     0,   1.00},   /* Blue    */
     {  0.63,  0.63,   0.63},   /* Gray    */
     {     0,  1.00,   1.00},   /* Cyan    */
     {  1.00,     0,   1.00},   /* Megenta */
     {  1.00,  1.00,      0},   /* Yellow  */
     {  1.00,  1.00,   1.00},   /* White   */
  }
#endif
   ;

EXTERN char * allbox_selection[3]
#ifdef MAIN
   = {  "All", "Box", NULL}
#endif
   ;

EXTERN  char * buffer_selection[NUM_BUFFER+1]
#if MAIN
   = { "A", "B", "C", "D", "E", "F", "G", "H", NULL  }
#endif
   ;

EXTERN char * buffer_status_names[3]
#ifdef MAIN
   = {  "EMPTY", "UNSAVED", "SAVED" }
#endif
   ;

EXTERN  char * CM_color_names[CM_NUM_STATIC_COLORS]
#if MAIN
   = { "Black", "red", "green", "blue", "gray", "cyan", "magenta", "yellow", "white" }
#endif
   ;

EXTERN  char * colormap_selection[8]
#if MAIN
   = { "a.cm", "b.cm", "bb.cm", "c.cm", "gray.cm", "grayRed.cm", "i8.cm", NULL  }
#endif
   ;

EXTERN  char * dpytype_selection[NUM_DPYTYPE+1]
#if MAIN
   = { "Image", "Header", "Histogram", "LineCut", "XLineCut", "Noise", "Pointer", "Stats", NULL  }
#endif
   ;

EXTERN  char * function_button_selection[NUM_FUN_BUT+1]
#if MAIN
   = { "0", "1", "2", "3", "4", "5", NULL  }
#endif
   ;

EXTERN char * imageautoscale_selection[3]
#ifdef MAIN
   = {  "Fixed", "Auto", NULL}
#endif
   ;

EXTERN char * Month_name[12]
#ifdef MAIN
   = { "jan", "feb", "mar", "apr", "may", "jun",
       "jul", "aug", "sep", "oct", "nov", "dec"  }
#endif
   ;

EXTERN char * noisegraphtype_selection[3]
#ifdef MAIN
   = {  "Text", "Graph", NULL}
#endif
   ;

EXTERN  char * offon_selection[3]
#if MAIN
   = { "off", "on", NULL  }
#endif
   ;

EXTERN char * printer_selection[3]
#ifdef MAIN
   = {  "BW_Postscript", "Color_Postscript", NULL }
#endif
   ;

EXTERN  char * rotate_selection[4]
#if MAIN
   = { "-90", "+90", "180", NULL  }
#endif
   ;

EXTERN  char * to_selection[2]  /* a convience list for parsing commands */
#if MAIN
   = { "to", NULL  }
#endif
   ;

EXTERN  char * mathops_selection[6]  /* a convience list for parsing math commands */
#if MAIN
   = { "+", "-", "*", "/", "=", NULL  }
#endif
   ;

/*----------------------------------------------------------------------------
** function prototypes
**----------------------------------------------------------------------------
*/

/*----------------------------------------------------------------------------
** DV.C
*/
int main( int argc, char *argv[] );
void initialize_globals( void );
void usage( void );
void cal_box_stats_subf( struct df_buf_t *bp, int type, int objx, int objy,
   int objwid, int objhgt, int skyx, int skyy, double *rN,
   double *rmin, double *rmax, double *rsum, double *rmean, double *rstd);
void cal_box_stats( int bufinx );
int tcs_com( char *command, char *reply, int reply_size, char *tcshostname );
int spex_com( char * command );
int spex_fix_subarray_dim( int *ax, int *ay, int *awid, int *ahgt);

/*----------------------------------------------------------------------------
** INIT.C
*/
int create_base( char * font_name );

   /*--------- Main Widget Setup Functions ----------*/
void create_menu_hbox( GtkWidget * base_window, GtkWidget ** c );
void create_button_menu( GtkWidget ** c );

void create_main_dpydata( GtkWidget ** c );
void create_dialog_dpydata( GtkWidget ** c );
void create_one_dpydata( GtkWidget ** c, int wid, int hgt, int dpyinx, int resize_it );

void create_notebook_widget( GtkWidget ** c );
void create_display_widgets( GtkWidget ** c );
void create_math_widgets( GtkWidget ** c );
void create_setup_widgets( GtkWidget ** c );
void create_offset_widgets( GtkWidget ** c );
void create_feedback_widgets( GtkWidget ** c );
void create_display_parameters_notebook( GtkWidget ** c );
void create_display_image_widgets( GtkWidget ** c );
void create_display_header_widgets( GtkWidget ** c );
void create_display_histogram_widgets( GtkWidget ** c );
void create_display_linecut_widgets( GtkWidget ** c );
void create_display_xlinecut_widgets( GtkWidget ** c );
void create_display_noise_widgets( GtkWidget ** c );
void create_display_pointer_widgets( GtkWidget ** c );
void create_display_stats_widgets( GtkWidget ** c );
void create_cli_widgets( GtkWidget ** c );
void create_label_widgets( GtkWidget ** c );

void create_about_dialog ( GtkWidget ** c );
void create_macro_dialog ( GtkWidget ** c );

   /*--------- Helper Functions ---------------------*/
GtkWidget * MyCreateGtkCombo( char * selection[], int IsEntryEditable);
GtkWidget * MyCreateMenuFromSelection( char * selection[], int tearoff,
   GtkSignalFunc menuitem_cb, gpointer user_data );
GtkWidget * MyCreateRadioButtons( char * selection[], GtkWidget *radio[],
   int is_hbox, GtkSignalFunc radiobutton_cb );
void MyStyleSetItemColor( GdkColor color, char item, GtkStyle * style);

/*----------------------------------------------------------------------------
** CB.C
*/
int base_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data );
void base_destroy_cb( GtkWidget *widget, gpointer data );

   /*--------- Main Menu bar Callbacks ------------*/
void Open_cb( GtkWidget *widget, gpointer data );
void Save_cb( GtkWidget *widget, gpointer data );
void Quit_cb( GtkWidget *widget, gpointer data );
void Test_cb( GtkWidget *widget, gpointer data );
void Macro_cb( GtkWidget *widget, gpointer data );
void About_cb( GtkWidget *widget, gpointer data );
void cmap_menuitem_cb ( GtkMenuItem * menuitem, gpointer data );

   /*--------- General Purpose Callbacks -----------------*/
void widget_hide_cb( GtkWidget *widget, gpointer data );
void button_cb( GtkWidget *widget, gpointer data );
void button2_cb( GtkWidget *widget, gpointer data );
void adj_cb( GtkAdjustment *adj, gpointer data );
void entry_cb( GtkEntry *w, gpointer data );
void entry_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );

void toggle_button_cb( GtkToggleButton *widget, gpointer data );
void checkbutton_offon_cb( GtkToggleButton *widget, gpointer data );
int  dialog_delete_event( GtkWidget *widget, GdkEvent  *event, gpointer data );

   /*--------- Main P Container Callbacks ---------*/
void dpyactive_cb( GtkToggleButton *widget, gpointer data );
void dpytype_menuitem_cb( GtkMenuItem * menuitem, gpointer data );
void buffer_cb( GtkToggleButton *widget, gpointer data );

void image_autoscale_cb( GtkToggleButton *widget, gpointer data );
void image_zoom_cb( GtkAdjustment *adj, gpointer data );
void image_range_cb( GtkEntry *w, gpointer data );
void image_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );

void hist_area_cb( GtkToggleButton *widget, gpointer data );
void hist_range_cb( GtkEntry *w, gpointer data );
void hist_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );

void lcut_area_cb( GtkToggleButton *widget, gpointer data );
void lcut_autoscale_cb( GtkToggleButton *widget, gpointer data );
void lcut_range_cb( GtkEntry *w, gpointer data );
void lcut_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );
void lcut_xy_cb( GtkEntry *w, gpointer data );
void lcut_xy_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );
void lcut_xarrow( GtkWidget *widget, gpointer data );
void lcut_yarrow( GtkWidget *widget, gpointer data );

void noise_g1range_cb( GtkEntry *w, gpointer data );
void noise_g1range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );
void noise_g2range_cb( GtkEntry *w, gpointer data );
void noise_g2range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );
void noise_autoscale_cb( GtkToggleButton *widget, gpointer data );
void noise_graphtype_cb( GtkToggleButton *widget, gpointer data );
void noise_area_cb( GtkToggleButton *widget, gpointer data );

void xcut_autoscale_cb( GtkToggleButton *widget, gpointer data );
void xcut_range_cb( GtkEntry *w, gpointer data );
void xcut_range_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );
void xcut_set_cb( GtkEntry *w, gpointer data );
void xcut_set_fo_cb( GtkEntry *widget, GdkEventFocus * event, gpointer data );
void xcut_setline_cb( GtkWidget *widget, gpointer data );
void xcut_xgfit_cb( GtkWidget *widget, gpointer data );

void stats_setsky_cb( GtkWidget *widget, gpointer data );
void stats_fixedwh_cb( GtkWidget *widget, gpointer data );
void stats_wh_entry_cb( GtkWidget *w, gpointer data );
void stats_wh_entry_fo_cb( GtkWidget *widget, GdkEventFocus * event, gpointer data );
void spex_subarray_cb( GtkWidget *widget, gpointer data );

   /*------ Macro Dialog Box -------------------*/
void m_edit_cb( GtkWidget *widget, gpointer data );
void m_execute_cb( GtkWidget *widget, gpointer data );
void m_fbutton_cb( GtkWidget *widget, gpointer data );
void m_filelist_cb( GtkWidget *widget, gint row, gint col, gpointer data );
void m_filemask_cb( GtkWidget *widget, gpointer data );
void m_filemask_fo_cb( GtkWidget *widget, GdkEventFocus * event, gpointer data );
void m_hide_cb( GtkWidget *widget, gpointer data );
void m_path_cb( GtkWidget *widget, gpointer data );
void m_path_fo_cb( GtkWidget *widget, GdkEventFocus * event, gpointer data );
void m_refresh_cb( GtkWidget *widget, gpointer data );
void m_option_menu_cb( GtkMenuItem * menuitem, gpointer data );
void m_setbutton_cb( GtkWidget *widget, gpointer data );
void m_stop_cb( GtkWidget *widget, gpointer data );

void m_clear_file( );
gint m_exe_timer_func( );

   /*------ Math Screen Callbacks ----------------*/
void math_equ_cb( GtkWidget *widget, gpointer data );

void math_copy_from_cb( GtkMenuItem * menuitem, gpointer data );
void math_copy_to_cb( GtkMenuItem * menuitem, gpointer data );
void math_copy_button_cb( GtkWidget *widget, gpointer data );

void math_clear_bufinx_cb( GtkMenuItem * menuitem, gpointer data );
void math_clear_button_cb( GtkWidget *widget, gpointer data );

void math_rotate_bufinx_cb( GtkMenuItem * menuitem, gpointer data );
void math_rotate_ops_cb( GtkMenuItem * menuitem, gpointer data );
void math_rotate_button_cb( GtkWidget *widget, gpointer data );

   /*------ Setup Screen Callbacks ----------------*/
void printertype_cb( GtkMenuItem * menuitem, gpointer data );

   /*------ TCS Offset Screen Callbacks ----------------*/
void offset_defaults_cb( GtkWidget *widget, gpointer data );

   /*--------- Cli Widgets Callbacks --------------*/
void command_entry_cb( GtkWidget *widget, gpointer data );
void printTextOut( int fg, char *fmt, ... );

   /*--------- IO event callbacks  ----------------*/
void socket_accept_connection( gpointer data, int fd, GdkInputCondition ic );
int handle_rpc(gpointer data);


   /*--------- Update Functions -------------------*/
void update_display_widgets( void );
void update_displayOptions_widgets( void );
void update_dpytype_image_widgets( struct dpy_t *dp );
void update_dpytype_histogram_widgets( struct dpy_t *dp );
void update_dpytype_linecut_widgets( struct dpy_t *dp );
void update_dpytype_xlinecut_widgets( struct dpy_t *dp );
void update_dpytype_noise_widgets( struct dpy_t *dp );
void update_dpytype_pointer_widgets( struct dpy_t *dp );
void update_dpytype_stats_widgets( struct dpy_t *dp );

   /*--------- setup tab function    -----------------*/
void update_setup_widgets ( void );
void update_offset_widgets( void );

   /*--------- File Access Dialog related -----------------*/
void fad_show( GtkWidget *widget, gpointer data );
void path_fad_ok_cb( GtkWidget *widget, gpointer data );
void open_fad_ok_cb( GtkWidget *widget, gpointer data );
void open_fad_movieread_cb( GtkWidget *widget, gpointer data );
void open_fad_movieshow_cb( GtkWidget *widget, gpointer data );

void save_fad_ok_cb( GtkWidget *widget, gpointer data );
void save_fad_buffer_cb( GtkMenuItem * menuitem, gpointer data );
void save_update_dialog( int bufinx );

   /*--------- Browse for Path related -----------------*/
void bfp_show( GtkWidget *widget, gpointer data );
void path_bfp_ok_cb( GtkWidget *widget, gpointer data );
void m_path_bfp_ok_cb( GtkWidget *widget, gpointer data );

   /*--------- General purpose functions ---------------*/
void MyUpdateComboWidget( GtkWidget *widget, int handler_id, char * text );
void update_directory_menu( char *path, GtkWidget * widget );
int  update_file_list( int isDir, char *cdir, char *fmask, GtkWidget *widget );

/*----------------------------------------------------------------------------
** COMMAND.C
*/
int cmd_execute( char * cmd_buf, int verbose );
int do_active( int index, char * par );
int do_boxcentroid( int index, char * par );
int do_boxcopy( int index, char * par );
int do_boxpeak( int index, char * par );
int do_boxscale( int index, char * par );
int do_boxzoom( int index, char * par );
int do_buffer( int index, char * par );
int do_bufinfo( int index, char * par );
int do_clear( int index, char * par );
int do_cmCenter( int index, char * par );
int do_cmWidth( int index, char * par );
int do_colormap( int index, char * par );
int do_colormap_inverse( int index, char * par );
int do_copy( int index, char * par );
int do_displaytype( int index, char * par );
int do_divbydivisor( int index, char * par );
int do_drawbox( int index, char * par );
int do_drawline( int index, char * par );
int do_echo( int index, char * par );
int do_filter1( int index, char * par );
int my_filter1_fun(  struct df_buf_t *dest, struct df_buf_t *op1 );
int do_filter2( int index, char * par );
int my_filter2_fun(  struct df_buf_t *dest, struct df_buf_t *op1 );
int do_fullimage( int index, char * par );
int do_histarea( int index, char * par );
int do_histbin( int index, char * par );
int do_imageautoscale( int index, char * par );
int do_imagerange( int index, char * par );
int do_imagescale1p( int index, char * par );
int cal_1per( struct df_buf_t *bp, long * Rmin, long * Rmax );
int do_imagezoom( int index, char * par );
int do_lcutarea( int index, char * par );
int do_lcutautoscale( int index, char * par );
int do_lcutrange( int index, char * par );
int do_lcutxy( int index, char * par );
int do_m_edit( int index, char * par );
int do_m_execute( int index, char * par );
int do_m_filemask( int index, char * par );
int do_m_load( int index, char * par );
int do_m_path( int index, char * par );
int do_m_refresh( int index, char * par );
int do_m_setbutton( int index, char * par );
int do_m_stop( int index, char * par );
int do_math( int index, char * par );
int do_noisearea( int index, char * par );
int do_noisemod( int index, char * par );
int do_noisegraphtype( int index, char * par );
int do_noiseautoscale( int index, char * par );
int do_noiseg1range( int index, char * par );
int do_noiseg2range( int index, char * par );
int do_offset_angle( int index, char * par );
int do_offset_begxy( int index, char * par );
int do_offset_endxy( int index, char * par );
int do_offset_platescale( int index, char * par );
int do_offset_tcs( int index, char * par );
int do_offset_tcsab( int index, char * par );
void cal_offset_radec( void );
int do_path( int index, char * par );
int do_print( int index, char * par );
int do_printer( int index, char * par );
int do_printertype( int index, char * par );
int do_printtofile( int index, char * par );
int do_ptimagesize( int index, char * par );
int do_push( int index, char * par );
int do_quit( int index, char * par );
int do_read( int index, char * par );
int do_readfile( int index, char * par );
int do_readmovie( int index, char * par );
int readmovie( int index, char * par );
int do_readsock( int index, char * par );
int do_rotate( int index, char * par );
int do_save( int index, char * par );
int do_savefile( int index, char * par );
int do_showmovie( int index, char * par );
int showmovie_readimage( int fd, struct df_buf_t * bp, int whichframe);
int do_smooth( int index, char * par );
int my_smooth_fun(  struct df_buf_t *dest, struct df_buf_t *op1 );
int do_spexcom( int index, char * par );
int do_sqrt( int index, char * par );
int do_statsobjbox( int index, char * par );
int do_statssetsky( int index, char * par );
int do_statsxorline( int index, char * par );
int do_statsfixedwh( int index, char * par );
int do_tcshostname( int index, char *par);
int do_usehex( int index, char * par );
int do_usefitsanglescale( int index, char * par );
int do_xcutautoscale( int index, char * par );
int do_xcutset( int index, char * par );
int do_xcutrange( int index, char * par );

   /*--------- Helper Functions -------------------*/
int qsort_comp_string( char **i, char **j );
int math_fixstring( char *scr, int scr_size );

/*----------------------------------------------------------------------------
** DRAW.C
*/
   /*--------- Colormap Callbacks -----------------*/
int colormap_expose_event( GtkWidget *widget, GdkEventExpose *event );
int colormap_configure_event( GtkWidget *widget, GdkEventConfigure *event );
void call_colormap_redraw( void );
void colormap_redraw( GtkWidget *da );

   /*--------- Dpytitle DA Callbacks ----------*/
int dpytitle_expose_event( GtkWidget *widget, GdkEventExpose *event );
int dpytitle_configure_event( GtkWidget *widget, GdkEventConfigure *event );
void call_dpytitle_redraw( int dpinx );
void redraw_dpytitle_for_bufinx( int bufinx );
void dpytitle_redraw( GtkWidget *da );

int dpytitle_button_press_event (GtkWidget *da, GdkEventButton *event, gpointer data );

   /*--------- Dpydata DA Callbacks -----------*/
int dpydata_expose_event( GtkWidget *widget, GdkEventExpose *event );
int dpydata_configure_event( GtkWidget *widget, GdkEventConfigure *event );
void call_dpydata_redraw( int dpinx );
void redraw_dpydata_for_bufinx( int bufinx );
void redraw_dpytype_stats_for_bufinx( int bufinx );
void dpydata_redraw( GtkWidget *da );

int dpydata_button_press_event( GtkWidget *widget, GdkEventButton *event, gpointer data );
int dpydata_motion_notify_event( GtkWidget *widget, GdkEventMotion *event, gpointer data );
int dpydata_key_press_event( GtkWidget *da, GdkEventKey *event, gpointer data );
int dpydata_focus_in_event( GtkWidget *da, GdkEventFocus *event, gpointer data );
int dpydata_focus_out_event( GtkWidget *da, GdkEventFocus *event, gpointer data );

void draw_X( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
void draw_image( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
void draw_image_plus_zoom_pseudocolor( struct dpy_t *dp, struct df_buf_t *bp,
     int da_wid, int da_hgt, unsigned char * image_buf);
void draw_image_plus_zoom_truecolor( struct dpy_t *dp, struct df_buf_t *bp,
     int da_wid, int da_hgt, long * image_buf);
void draw_image_minus_zoom( struct dpy_t *dp, struct df_buf_t *bp,
     int da_wid, int da_hgt, unsigned char * image_buf);
void longset( long * buf, long value, long n);
void draw_header( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
int  get_histogram_info( struct dpy_t *dp, struct hist_info *hist );
void draw_histogram( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
int  get_linecut_info( struct dpy_t *dp, struct lcut_info *lcut );
void draw_linecut( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
void draw_noise( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
void calc_noise( struct noise_t *noisep, struct noise_t *fnoise,
     struct dpy_t *dp, struct df_buf_t *bp );
void draw_xcut( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
int  xcut_line( int x0, int y0, int x1, int y1, struct df_buf_t *bp,
     struct xcut_buf_t *destbuf, int num_destbuf );
void draw_pointer( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
void draw_pointer_update( GtkWidget *da, int dpinx, int ax, int ay, int image_dpinx );
void draw_stats( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );
void draw_NA( GtkWidget *da, struct dpy_t *dp, struct df_buf_t *bp );

void dpy_hadj_cb( GtkAdjustment *adj, gpointer data );
void dpy_vadj_cb( GtkAdjustment *adj, gpointer data );
void update_scrollbars( int dpinx );

void draw_xor_box_on_canvas( int dpinx, int x, int y, int wid, int hgt );
void draw_xor_box_on_buffer( int bufinx, int x, int y, int wid, int hgt );
void draw_xor_line_on_canvas( int bufinx, int xbeg, int ybeg, int xend, int yend );
void draw_xor_line_on_buffer( int bufinx, int xbeg, int ybeg, int xend, int yend );

void my_draw_image_string( GdkDrawable *drawable, GdkFont *font, GdkGC *gc, int x, int y,
   int char_wid, int char_hgt, int fg, int bg, const gchar *string, int strlen);

/*-------------------------------------------------------------
** PRINT.c
*/
int print_psheader( FILE *fp );
int print_fitsheader( FILE *fp, struct dpy_t *dp );
int print_gdummy( FILE *fp, struct dpy_t *dp );
int print_image( FILE *fp, struct dpy_t *dp );
int print_color_image( FILE *fp, struct dpy_t *dp);
long color_bgr2rgb( long color );
int print_histogram( FILE *fp, struct dpy_t *dp );
int print_linecut( FILE *fp, struct dpy_t *dp );
int print_noise( FILE *fp, struct dpy_t *dp );
int print_xcut( FILE *fp, struct dpy_t *dp );

/****************************************************************************/
/****************************************************************************/
